﻿import React, { useState } from 'react';
import {
  ArrowLeft,
  BadgeCheck,
  Truck,
  ShoppingBag,
  ArrowUpRight,
  Wallet,
  FileCheck2,
  LockKeyhole,
  Route,
  ScanEye,
  Check,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatMoney, formatINR } from '../mockData';

export const ProductDetailPage: React.FC = () => {
  const { selectedProduct, navigate, addToCart, openModal } = useApp();
  const [quantity, setQuantity] = useState(1);

  const p = selectedProduct;

  const handleBuyNow = () => {
    addToCart(p, quantity);
    navigate('checkout');
  };

  const handleAddToCart = () => {
    addToCart(p, quantity);
  };

  const protectionSteps = [
    'Payment',
    'Escrow locked',
    'Seller ships',
    'Delivery confirmed',
    'Payment released',
    'Cashback',
  ];

  return (
    <div className="animate-rise">
      {/* Detail Section */}
      <section className="max-w-[1200px] mx-auto px-[5%] py-8 sm:py-12">
        {/* Back Button */}
        <button
          onClick={() => navigate('market')}
          className="text-muted hover:text-ink text-xs inline-flex items-center gap-2 mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to marketplace</span>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-[1.05fr_0.95fr] gap-10 lg:gap-14 items-start">
          {/* Gallery */}
          <div className="h-[380px] sm:h-[520px] relative rounded-xl overflow-hidden bg-[#202923] border border-line/60">
            <img
              src={p.image}
              alt={p.name}
              className="w-full h-full object-cover"
            />
            <span className="absolute top-4 left-4 bg-lime text-[#142118] font-mono text-[9px] font-bold py-1.5 px-2.5 rounded shadow">
              {p.tag}
            </span>
          </div>

          {/* Details Info */}
          <div className="pt-2">
            <div className="flex justify-between items-center text-muted font-mono text-[9px] uppercase tracking-wider">
              <span>{p.category}</span>
              <span className="text-coral font-semibold">
                ★ {p.rating} · {p.reviewsCount || 24} verified reviews
              </span>
            </div>

            <h1 className="font-display font-semibold text-3xl sm:text-5xl tracking-tight text-ink mt-3 mb-2">
              {p.name}
            </h1>

            <p className="text-muted text-xs flex items-center gap-1.5 mb-4">
              <span>Sold by</span>
              <b className="text-ink font-semibold">{p.seller}</b>
              <BadgeCheck className="w-3.5 h-3.5 text-lime" />
              <span className="text-lime font-mono text-[9px] uppercase">Verified</span>
            </p>

            {p.description && (
              <p className="text-muted text-xs sm:text-sm leading-relaxed mb-6">
                {p.description}
              </p>
            )}

            {/* Price Box */}
            <div className="border-y border-line py-5 my-6">
              <b className="font-display font-semibold text-3xl sm:text-4xl text-ink block">
                {formatMoney(p.price)}
              </b>
              <span className="text-muted font-mono text-xs block mt-1">
                {formatINR(p.price)} · Locked in escrow during transit
              </span>
            </div>

            {/* Delivery Info */}
            <div className="flex items-center gap-3 bg-[#16211a] border border-line p-3.5 rounded-lg text-lime mb-6">
              <Truck className="w-5 h-5 flex-shrink-0" />
              <div className="text-ink">
                <b className="text-xs font-semibold block">{p.delivery}</b>
                <small className="text-muted text-[10px] block mt-0.5">
                  Free trackable shipping · {p.location || 'Pune'} to your address
                </small>
              </div>
            </div>

            {/* Purchase Row */}
            <div className="flex items-center gap-3 mb-8">
              {/* Quantity */}
              <div className="flex items-center border border-line rounded-[5px] bg-[#141b17]">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-8 h-10 text-muted hover:text-ink font-mono text-sm"
                >
                  −
                </button>
                <span className="font-mono text-xs min-w-[24px] text-center text-ink font-bold">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-8 h-10 text-muted hover:text-ink font-mono text-sm"
                >
                  +
                </button>
              </div>

              {/* Buy Now Button */}
              <button
                onClick={handleBuyNow}
                className="flex-1 bg-lime hover:bg-[#b8df5d] text-[#122016] py-3 px-5 rounded-[5px] font-extrabold text-xs inline-flex items-center justify-center gap-2 transition-colors shadow-lg"
              >
                <span>Buy now</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>

              {/* Add to Basket */}
              <button
                onClick={handleAddToCart}
                className="w-11 h-11 border border-line hover:border-lime rounded-[5px] bg-[#141b17] text-muted hover:text-ink grid place-items-center transition-colors"
                title="Add to basket"
              >
                <ShoppingBag className="w-4 h-4" />
              </button>
            </div>

            {/* Trust & Verification Grid */}
            <div className="border-t border-line pt-6">
              <h3 className="font-display font-semibold text-sm text-ink mb-4">
                Trust & verification
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <span className="flex items-center gap-2 text-lime text-xs">
                  <Wallet className="w-4 h-4 flex-shrink-0" />
                  <b className="text-muted font-normal">Wallet verified</b>
                </span>
                <span className="flex items-center gap-2 text-lime text-xs">
                  <BadgeCheck className="w-4 h-4 flex-shrink-0" />
                  <b className="text-muted font-normal">127 verified transactions</b>
                </span>
                <span className="flex items-center gap-2 text-lime text-xs">
                  <FileCheck2 className="w-4 h-4 flex-shrink-0" />
                  <b className="text-muted font-normal">Authenticity record available</b>
                </span>
                <span className="flex items-center gap-2 text-lime text-xs">
                  <LockKeyhole className="w-4 h-4 flex-shrink-0" />
                  <b className="text-muted font-normal">Escrow protected</b>
                </span>
                <span className="flex items-center gap-2 text-lime text-xs sm:col-span-2">
                  <Route className="w-4 h-4 flex-shrink-0" />
                  <b className="text-muted font-normal">Trackable insured courier delivery</b>
                </span>
              </div>
            </div>

            {/* Proof Modal Trigger */}
            <button
              onClick={() => openModal('proof')}
              className="mt-6 text-lime hover:underline font-medium text-xs inline-flex items-center gap-2"
            >
              <ScanEye className="w-4 h-4" />
              <span>View blockchain settlement proof</span>
            </button>
          </div>
        </div>
      </section>

      {/* Protection Flow Section */}
      <section className="border-t border-line bg-[#141b17] py-16 sm:py-20 px-[5%]">
        <div className="max-w-[1200px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-widest text-lime mb-2">
              Transaction protection
            </p>
            <h2 className="font-display font-semibold text-3xl sm:text-4xl text-ink">
              Your money stays<br />
              <em className="font-serif font-normal text-lime">in your corner.</em>
            </h2>
            <p className="text-muted text-xs sm:text-sm leading-relaxed mt-4 max-w-[420px]">
              Your SHARP payment is locked in transparent escrow and released strictly according to predefined verified delivery conditions.
            </p>
          </div>

          <div className="border-l border-[#40514a] pl-6 grid gap-4">
            {protectionSteps.map((step, idx) => (
              <div
                key={idx}
                className={`flex items-center gap-3.5 text-xs ${
                  idx === 0 ? 'text-ink font-semibold' : 'text-[#63726a]'
                }`}
              >
                <span
                  className={`w-6 h-6 rounded-full grid place-items-center font-mono text-[9px] border ${
                    idx === 0
                      ? 'bg-lime border-lime text-[#18231a] font-bold'
                      : 'border-[#40514a] text-muted'
                  }`}
                >
                  {idx === 0 ? <Check className="w-3.5 h-3.5" /> : `0${idx + 1}`}
                </span>
                <b>{step}</b>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
