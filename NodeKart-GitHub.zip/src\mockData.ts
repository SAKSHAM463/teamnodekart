export interface Product {
  id: string;
  name: string;
  seller: string;
  rating: string;
  price: number;
  category: string;
  delivery: string;
  image: string;
  tag: string;
  blockchain: boolean;
  description?: string;
  location?: string;
  reviewsCount?: number;
  specs?: Record<string, string>;
  billUrl?: string;
  isSecondHand?: boolean;
  sellerWallet?: string;
}

export interface UserProfile {
  name: string;
  avatarText: string;
  memberSince: string;
  walletAddress: string;
  walletAddressShort: string;
  sharpBalance: number;
  ordersCompleted: number;
  reputation: string;
  referralCode: string;
  referralLink: string;
  email?: string;
  phone?: string;
}

export interface WalletTransaction {
  id: string;
  title: string;
  amount: string;
  status: string;
  type: 'debit' | 'credit';
  icon: 'shopping-bag' | 'sparkles' | 'users' | 'check-circle-2' | 'plus';
  timestamp: string;
}

export interface SellerStats {
  totalRevenue: number;
  revenueGrowth: string;
  pendingEscrow: number;
  activeOrdersCount: number;
  releasedFunds: number;
  completedOrdersCount: number;
  averageRating: string;
  verifiedTransactionsCount: number;
}

export interface ProofDetails {
  txHash: string;
  smartContract: string;
  block: string;
  timestamp: string;
  events: { name: string; status: string }[];
  network: string;
}

export interface OrderRecord {
  orderId: string;
  productId: string;
  amount: number;
  seller: string;
  productName: string;
  productImage: string;
  trackingNumber: string;
  date: string;
  address: {
    fullName: string;
    phone: string;
    street: string;
    city: string;
    state: string;
    pincode: string;
  };
}

export const CATEGORIES = [
  'All',
  'Electronics',
  'Fashion',
  'Home',
  'Books',
  'Collectibles',
] as const;

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'electric-guitar',
    name: 'Fender Player II Stratocaster Electric Guitar',
    seller: 'Saksham',
    rating: '4.9',
    price: 34500,
    category: 'Collectibles',
    delivery: 'Arrives by 30 Aug',
    image: 'https://images.unsplash.com/photo-1564186763535-ebb21ef5277f?auto=format&fit=crop&w=900&q=85',
    tag: 'Top rated',
    blockchain: true,
    description: 'Iconic Fender Player II Stratocaster in Sunburst finish. Features Alder body, modern C-shape maple neck, 3 Alnico 5 single-coil pickups, and 2-point synchronized tremolo. Includes original gig bag and authenticated ownership certificate.',
    location: 'Bengaluru',
    reviewsCount: 18,
    specs: {
      'Body Material': 'Alder',
      'Neck Profile': 'Modern C',
      'Pickups': '3x Player Series Alnico 5 Strat',
      'Bridge': '2-Point Synchronized Tremolo',
      'Condition': 'Pristine / Mint',
    },
  },
  {
    id: 'iphone',
    name: 'iPhone 15 · 128GB',
    seller: 'Arjun Mehta',
    rating: '4.8',
    price: 42500,
    category: 'Electronics',
    delivery: 'Arrives by 29 Aug',
    image: 'https://images.unsplash.com/photo-1592286927505-2fd0dcb29f2f?auto=format&fit=crop&w=900&q=85',
    tag: 'Popular',
    blockchain: true,
    description: 'Gently used iPhone 15 in pristine condition. Original battery health 99%, includes original braided USB-C cable and retail box.',
    location: 'Pune',
    reviewsCount: 24,
  },
  {
    id: 'headphones',
    name: 'WH-1000XM5 Headphones',
    seller: 'Mira Kapoor',
    rating: '4.9',
    price: 21800,
    category: 'Electronics',
    delivery: 'Arrives by 30 Aug',
    image: 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?auto=format&fit=crop&w=900&q=85',
    tag: 'Top rated',
    blockchain: true,
    description: 'Industry-leading noise cancellation wireless headphones with original carrying case, 3.5mm cable, and flight adapter.',
    location: 'Mumbai',
    reviewsCount: 19,
  },
  {
    id: 'camera',
    name: 'Fujifilm X100V Camera',
    seller: 'Rohan Studio',
    rating: '4.7',
    price: 89500,
    category: 'Collectibles',
    delivery: 'Arrives by 2 Sep',
    image: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=900&q=85',
    tag: 'Rare find',
    blockchain: true,
    description: 'Silver edition Fujifilm X100V with squarehood lens hood, extra original NP-W126S battery, and B+W UV filter.',
    location: 'Bengaluru',
    reviewsCount: 31,
  },
  {
    id: 'chair',
    name: 'Teak Lounge Chair',
    seller: 'The Woven Room',
    rating: '4.9',
    price: 12400,
    category: 'Home',
    delivery: 'Arrives by 31 Aug',
    image: 'https://images.unsplash.com/photo-1567016432779-094069958ea5?auto=format&fit=crop&w=900&q=85',
    tag: 'Handmade',
    blockchain: false,
    description: 'Solid reclaimed teak wood frame with natural cane weaving. Ergonomic incline for lounge reading.',
    location: 'Kochi',
    reviewsCount: 12,
  },
  {
    id: 'sneakers',
    name: 'New Balance 990v5',
    seller: 'Kicks by Dev',
    rating: '4.8',
    price: 9800,
    category: 'Fashion',
    delivery: 'Arrives by 28 Aug',
    image: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=900&q=85',
    tag: 'Verified pair',
    blockchain: true,
    description: 'Classic Grey New Balance 990v5. Size US 10. Authenticated with NFC provenance tag and original box.',
    location: 'Delhi',
    reviewsCount: 45,
  },
  {
    id: 'kindle',
    name: 'Kindle Paperwhite 11th Gen',
    seller: 'Ananya Reads',
    rating: '5.0',
    price: 7200,
    category: 'Books',
    delivery: 'Arrives by 29 Aug',
    image: 'https://images.unsplash.com/photo-1592496001020-d31bd830651f?auto=format&fit=crop&w=900&q=85',
    tag: 'Like new',
    blockchain: false,
    description: '6.8 inch glare-free display with adjustable warm light. Battery lasts weeks. Comes with genuine leather sleep-wake cover.',
    location: 'Hyderabad',
    reviewsCount: 16,
  },
  {
    id: 'watch',
    name: 'Seiko 5 Sports Watch',
    seller: 'Timekeeper Co.',
    rating: '4.6',
    price: 15600,
    category: 'Collectibles',
    delivery: 'Arrives by 3 Sep',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=85',
    tag: 'Collector',
    blockchain: true,
    description: 'Automatic 4R36 movement with exhibition case back, unidirectional rotating bezel, and stainless steel link bracelet.',
    location: 'Ahmedabad',
    reviewsCount: 28,
  },
  {
    id: 'lamp',
    name: 'Rattan Table Lamp',
    seller: 'The Woven Room',
    rating: '4.9',
    price: 3400,
    category: 'Home',
    delivery: 'Arrives by 30 Aug',
    image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=85',
    tag: 'Small batch',
    blockchain: false,
    description: 'Handwoven natural rattan shade paired with a warm ceramic base. Warm 2700K vintage LED bulb included.',
    location: 'Kochi',
    reviewsCount: 9,
  },
];

export const INITIAL_USER: UserProfile = {
  name: 'Saksham',
  avatarText: 'S',
  memberSince: 'August 2025',
  walletAddress: '0x7a4F923b9d0C1e889F12Aa45B48cE91079c29c21',
  walletAddressShort: '0x7a4F...9c21',
  sharpBalance: 12450,
  ordersCompleted: 12,
  reputation: '4.91 ★',
  referralCode: 'NK7X29',
  referralLink: 'nodekart.com/r/NK7X29',
  email: 'saksham@nodekart.eth',
  phone: '+91 98765 43210',
};

export const INITIAL_TRANSACTIONS: WalletTransaction[] = [
  {
    id: 'tx-1',
    title: 'iPhone 15 purchase',
    amount: '−42,500 SHARP',
    status: 'Escrow',
    type: 'debit',
    icon: 'shopping-bag',
    timestamp: 'Today, 2:15 PM',
  },
  {
    id: 'tx-2',
    title: 'Cashback · #NK48172',
    amount: '+750 SHARP',
    status: 'Confirmed',
    type: 'credit',
    icon: 'sparkles',
    timestamp: 'Yesterday, 6:40 PM',
  },
  {
    id: 'tx-3',
    title: 'Referral reward',
    amount: '+500 SHARP',
    status: 'Confirmed',
    type: 'credit',
    icon: 'users',
    timestamp: '24 Aug 2026',
  },
  {
    id: 'tx-4',
    title: 'Order settlement',
    amount: '+25,000 SHARP',
    status: 'Confirmed',
    type: 'credit',
    icon: 'check-circle-2',
    timestamp: '20 Aug 2026',
  },
];

export const INITIAL_SELLER_STATS: SellerStats = {
  totalRevenue: 128450,
  revenueGrowth: '+12.8% this month',
  pendingEscrow: 24500,
  activeOrdersCount: 2,
  releasedFunds: 103950,
  completedOrdersCount: 41,
  averageRating: '4.8 ★',
  verifiedTransactionsCount: 127,
};

export const INITIAL_PROOF: ProofDetails = {
  txHash: '0x7a3f9d84920fcb12883da01289cf821091fd',
  smartContract: '0x91c49210aa3902187b4588219dfc291872ae',
  block: '18,492,021',
  timestamp: 'Aug 25, 2026 · 12:42 AM',
  events: [
    { name: 'Payment deposited', status: 'Verified event' },
    { name: 'Escrow created', status: 'Verified event' },
    { name: 'Delivery confirmed', status: 'Verified event' },
    { name: 'Escrow released', status: 'Verified event' },
    { name: 'Cashback minted', status: 'Verified event' },
  ],
  network: 'NodeKart Network (Demo)',
};

export const INITIAL_ORDER: OrderRecord = {
  orderId: 'NK48291',
  productId: 'iphone',
  amount: 25000,
  seller: 'Arjun Mehta',
  productName: 'iPhone 15 · 128GB',
  productImage: 'https://images.unsplash.com/photo-1592286927505-2fd0dcb29f2f?auto=format&fit=crop&w=900&q=85',
  trackingNumber: 'NK9271IN',
  date: '25 Aug 2026',
  address: {
    fullName: 'Saksham',
    phone: '+91 98765 43210',
    street: '42, 5th Cross, Indiranagar',
    city: 'Bengaluru',
    state: 'Karnataka',
    pincode: '560038',
  },
};

export const REWARD_LOGS = [
  { id: '1', title: 'Order #NK48291 · +1,250 SHARP', date: 'Today' },
  { id: '2', title: 'Order #NK48172 · +750 SHARP', date: '12 Aug' },
  { id: '3', title: 'Order #NK48003 · +500 SHARP', date: '04 Aug' },
];

export const HOW_REFERRALS_WORK = [
  'Invite a friend with your personal link',
  'They make their first purchase',
  'The transaction completes through escrow',
  'Both users receive bonus SHARP rewards',
];

export const formatMoney = (n: number): string => `${n.toLocaleString('en-IN')} SHARP`;
export const formatINR = (n: number): string => `≈ ₹${Math.round(n * 1.9).toLocaleString('en-IN')}`;
