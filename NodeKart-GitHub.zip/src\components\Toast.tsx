﻿import React from 'react';
import { useApp } from '../context/AppContext';

export const Toast: React.FC = () => {
  const { toastMessage } = useApp();

  if (!toastMessage) return null;

  return (
    <div
      role="status"
      className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-[#1e2a22] border border-lime text-ink px-4 py-2.5 rounded-full font-display text-xs font-semibold shadow-2xl flex items-center gap-2 animate-rise"
    >
      <span className="w-2 h-2 rounded-full bg-lime animate-ping" />
      <span>{toastMessage}</span>
    </div>
  );
};
