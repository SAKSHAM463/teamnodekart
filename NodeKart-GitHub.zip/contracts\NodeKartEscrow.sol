// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "./SHARPToken.sol";
import "./NodeKartReputationSBT.sol";
import "./MockChainlinkOracle.sol";

/**
 * @title NodeKartEscrow
 * @notice Trustless, Dual-Deposit Collateralized Escrow for NodeKart peer-to-peer commerce.
 *
 * Game Theory Architecture (Sub-game Perfect Nash Equilibrium):
 *   - Seller locks Collateral (e.g., 10%)
 *   - Buyer locks Purchase Price + Collateral (e.g., 5%)
 *   - Cooperative settlement guarantees mutual deposit returns, merchant payout, 5% SHARP cashback,
 *     and ERC-5192 Soulbound reputation upgrades.
 *   - Uncooperative bad-faith behavior or fraud triggers reciprocal slashing of collateral.
 *
 * Automated Chainlink Delivery Verification:
 *   - Integrates with Chainlink DONs to query logistics carriers.
 *   - Instant buyer sign-off OR 48-hour automated release fallback following oracle delivery confirmation.
 */
contract NodeKartEscrow is ReentrancyGuard, Ownable, INodeKartEscrowOracleCallback {
    using SafeERC20 for IERC20;

    enum EscrowState {
        AwaitingSellerCollateral, // 0 · Escrow initialized, waiting for seller collateral deposit
        AwaitingBuyerDeposit,     // 1 · Seller collateral locked, waiting for buyer purchase + collateral
        Funded,                   // 2 · Fully funded, seller preparing shipment
        Dispatched,               // 3 · Package dispatched with on-chain carrier tracking
        Delivered,                // 4 · Carrier confirmed physical delivery (48h timelock starts)
        Settled,                  // 5 · Payment released, deposits refunded, cashback & SBT issued
        Disputed,                 // 6 · Dispute raised for resolution / slashing
        Cancelled                 // 7 · Order cancelled before buyer funding
    }

    struct OrderEscrow {
        uint256 id;
        address payable seller;
        address payable buyer;
        uint256 itemPrice;         // In SHARP (18 decimals)
        uint256 sellerCollateral;  // Locked by seller
        uint256 buyerCollateral;   // Locked by buyer
        string  trackingNumber;
        string  carrier;
        uint256 deliveryTimestamp; // Timestamp when carrier confirmed delivery
        uint256 disputeDeadline;   // 48 hours after delivery
        EscrowState state;
        string  productRefId;      // Off-chain catalog reference ID (e.g. "iphone")
    }

    // ─── Immutables & Config ───────────────────────────────────────────────────

    SHARPToken             public immutable sharpToken;
    NodeKartReputationSBT  public immutable reputationSBT;
    MockChainlinkOracle    public oracle;

    /// @notice 48-hour protective timelock window after carrier delivery confirmation
    uint256 public constant AUTOMATED_SETTLEMENT_DELAY = 48 hours;

    /// @notice 5% programmatic cashback percentage (500 basis points / 10000)
    uint256 public constant CASHBACK_BPS = 500;
    uint256 public constant BPS_DENOMINATOR = 10000;

    uint256 private _nextEscrowId = 1;

    /// @notice Mapping from escrowId to OrderEscrow
    mapping(uint256 => OrderEscrow) public escrows;

    /// @notice User active escrows mapping
    mapping(address => uint256[]) private _userEscrows;

    // ─── Events ────────────────────────────────────────────────────────────────

    event EscrowCreated(uint256 indexed escrowId, address indexed seller, address indexed buyer, uint256 itemPrice, string productRefId);
    event SellerCollateralDeposited(uint256 indexed escrowId, address indexed seller, uint256 collateral);
    event BuyerDepositLocked(uint256 indexed escrowId, address indexed buyer, uint256 totalLocked);
    event OrderDispatched(uint256 indexed escrowId, string trackingNumber, string carrier);
    event DeliveryConfirmedByOracle(uint256 indexed escrowId, string trackingNumber, uint256 timestamp, uint256 deadline);
    event EscrowSettled(uint256 indexed escrowId, address indexed seller, address indexed buyer, uint256 payout, uint256 cashback);
    event DisputeRaised(uint256 indexed escrowId, address indexed raisedBy, string reason);
    event DisputeResolvedNash(uint256 indexed escrowId, bool sellerSlashed, bool buyerSlashed);
    event EscrowCancelled(uint256 indexed escrowId);
    event OracleUpdated(address indexed newOracle);

    // ─── Modifiers ─────────────────────────────────────────────────────────────

    modifier onlyBuyer(uint256 escrowId) {
        require(msg.sender == escrows[escrowId].buyer, "NodeKartEscrow: caller is not the buyer");
        _;
    }

    modifier onlySeller(uint256 escrowId) {
        require(msg.sender == escrows[escrowId].seller, "NodeKartEscrow: caller is not the seller");
        _;
    }

    modifier inState(uint256 escrowId, EscrowState expected) {
        require(escrows[escrowId].state == expected, "NodeKartEscrow: invalid state for action");
        _;
    }

    constructor(
        address _sharpToken,
        address _reputationSBT,
        address _oracle,
        address initialOwner
    ) Ownable(initialOwner) {
        require(_sharpToken != address(0), "NodeKartEscrow: invalid token address");
        require(_reputationSBT != address(0), "NodeKartEscrow: invalid SBT address");

        sharpToken = SHARPToken(_sharpToken);
        reputationSBT = NodeKartReputationSBT(_reputationSBT);
        oracle = MockChainlinkOracle(_oracle);
    }

    function setOracle(address _oracle) external onlyOwner {
        require(_oracle != address(0), "NodeKartEscrow: invalid oracle address");
        oracle = MockChainlinkOracle(_oracle);
        emit OracleUpdated(_oracle);
    }

    // ─── Escrow Creation & Funding ─────────────────────────────────────────────

    /**
     * @notice Creates a new dual-deposit escrow for an item.
     * @param seller           Address of the merchant selling the product
     * @param itemPrice        Price in SHARP
     * @param sellerCollateral Collateral required from the seller (e.g., 10%)
     * @param buyerCollateral  Collateral required from the buyer (e.g., 5%)
     * @param productRefId     Off-chain product catalog identifier (e.g., "iphone")
     */
    function createEscrow(
        address payable seller,
        uint256 itemPrice,
        uint256 sellerCollateral,
        uint256 buyerCollateral,
        string calldata productRefId
    ) external nonReentrant returns (uint256 escrowId) {
        require(seller != address(0), "NodeKartEscrow: seller cannot be zero address");
        require(seller != msg.sender, "NodeKartEscrow: buyer and seller cannot be identical");
        require(itemPrice > 0, "NodeKartEscrow: item price must be greater than zero");

        escrowId = _nextEscrowId++;
        OrderEscrow storage order = escrows[escrowId];
        order.id = escrowId;
        order.seller = seller;
        order.buyer = payable(msg.sender);
        order.itemPrice = itemPrice;
        order.sellerCollateral = sellerCollateral;
        order.buyerCollateral = buyerCollateral;
        order.productRefId = productRefId;
        order.state = EscrowState.AwaitingSellerCollateral;

        _userEscrows[msg.sender].push(escrowId);
        _userEscrows[seller].push(escrowId);

        emit EscrowCreated(escrowId, seller, msg.sender, itemPrice, productRefId);

        // If buyer wants to fund directly if seller deposit is pre-funded or 0
        if (sellerCollateral == 0) {
            order.state = EscrowState.AwaitingBuyerDeposit;
        }
    }

    /**
     * @notice Seller locks their collateral deposit in SHARP tokens into the escrow
     */
    function depositSellerCollateral(uint256 escrowId)
        external
        nonReentrant
        onlySeller(escrowId)
        inState(escrowId, EscrowState.AwaitingSellerCollateral)
    {
        OrderEscrow storage order = escrows[escrowId];
        order.state = EscrowState.AwaitingBuyerDeposit;

        if (order.sellerCollateral > 0) {
            IERC20(address(sharpToken)).safeTransferFrom(msg.sender, address(this), order.sellerCollateral);
        }

        emit SellerCollateralDeposited(escrowId, msg.sender, order.sellerCollateral);
    }

    /**
     * @notice Buyer locks the item price + buyer collateral in SHARP tokens
     */
    function depositBuyerFunds(uint256 escrowId)
        external
        nonReentrant
        onlyBuyer(escrowId)
        inState(escrowId, EscrowState.AwaitingBuyerDeposit)
    {
        OrderEscrow storage order = escrows[escrowId];
        uint256 totalRequired = order.itemPrice + order.buyerCollateral;

        order.state = EscrowState.Funded;

        IERC20(address(sharpToken)).safeTransferFrom(msg.sender, address(this), totalRequired);

        emit BuyerDepositLocked(escrowId, msg.sender, totalRequired);
    }

    /**
     * @notice Helper allowing buyer to create and lock funds in a single step if seller pre-funded collateral
     */
    function createAndFundEscrow(
        address payable seller,
        uint256 itemPrice,
        uint256 sellerCollateral,
        uint256 buyerCollateral,
        string calldata productRefId
    ) external nonReentrant returns (uint256 escrowId) {
        require(seller != address(0) && seller != msg.sender, "NodeKartEscrow: invalid seller");
        require(itemPrice > 0, "NodeKartEscrow: item price > 0");

        escrowId = _nextEscrowId++;
        OrderEscrow storage order = escrows[escrowId];
        order.id = escrowId;
        order.seller = seller;
        order.buyer = payable(msg.sender);
        order.itemPrice = itemPrice;
        order.sellerCollateral = sellerCollateral;
        order.buyerCollateral = buyerCollateral;
        order.productRefId = productRefId;
        order.state = EscrowState.Funded;

        _userEscrows[msg.sender].push(escrowId);
        _userEscrows[seller].push(escrowId);

        uint256 totalRequired = itemPrice + buyerCollateral;
        IERC20(address(sharpToken)).safeTransferFrom(msg.sender, address(this), totalRequired);

        emit EscrowCreated(escrowId, seller, msg.sender, itemPrice, productRefId);
        emit BuyerDepositLocked(escrowId, msg.sender, totalRequired);
    }

    // ─── Dispatch & Delivery Verification ──────────────────────────────────────

    /**
     * @notice Merchant dispatches the package and registers the tracking details
     */
    function dispatchOrder(
        uint256 escrowId,
        string calldata trackingNumber,
        string calldata carrier
    ) external nonReentrant onlySeller(escrowId) inState(escrowId, EscrowState.Funded) {
        require(bytes(trackingNumber).length > 0, "NodeKartEscrow: empty tracking number");

        OrderEscrow storage order = escrows[escrowId];
        order.trackingNumber = trackingNumber;
        order.carrier = carrier;
        order.state = EscrowState.Dispatched;

        emit OrderDispatched(escrowId, trackingNumber, carrier);
    }

    /**
     * @notice Chainlink DON Oracle callback fulfilling verified delivery status
     */
    function oracleDeliveryFulfillment(
        uint256 escrowId,
        string calldata trackingNumber
    ) external override nonReentrant {
        require(msg.sender == address(oracle), "NodeKartEscrow: caller is not authorized oracle");

        OrderEscrow storage order = escrows[escrowId];
        require(order.state == EscrowState.Dispatched, "NodeKartEscrow: invalid state for delivery");
        require(
            keccak256(abi.encodePacked(order.trackingNumber)) == keccak256(abi.encodePacked(trackingNumber)),
            "NodeKartEscrow: tracking mismatch"
        );

        order.state = EscrowState.Delivered;
        order.deliveryTimestamp = block.timestamp;
        order.disputeDeadline = block.timestamp + AUTOMATED_SETTLEMENT_DELAY;

        emit DeliveryConfirmedByOracle(escrowId, trackingNumber, block.timestamp, order.disputeDeadline);
    }

    /**
     * @notice Queries oracle and synchronizes delivery state on-chain
     */
    function syncDeliveryWithOracle(uint256 escrowId) external nonReentrant {
        OrderEscrow storage order = escrows[escrowId];
        require(order.state == EscrowState.Dispatched, "NodeKartEscrow: order not dispatched");

        (bool delivered, uint256 deliveredAt) = oracle.isDelivered(order.trackingNumber);
        require(delivered, "NodeKartEscrow: carrier has not reported delivery yet");

        order.state = EscrowState.Delivered;
        order.deliveryTimestamp = deliveredAt > 0 ? deliveredAt : block.timestamp;
        order.disputeDeadline = order.deliveryTimestamp + AUTOMATED_SETTLEMENT_DELAY;

        emit DeliveryConfirmedByOracle(escrowId, order.trackingNumber, order.deliveryTimestamp, order.disputeDeadline);
    }

    // ─── Settlement & Fund Release ─────────────────────────────────────────────

    /**
     * @notice Manual settlement (Happy Path): Buyer confirms delivery receipt in the UI.
     * Releases item price + seller collateral to seller, refunds buyer collateral,
     * programmatically mints 5% SHARP cashback to buyer, and updates ERC-5192 SBT reputation.
     */
    function confirmDeliveryAndSettle(uint256 escrowId)
        external
        nonReentrant
        onlyBuyer(escrowId)
    {
        OrderEscrow storage order = escrows[escrowId];
        require(
            order.state == EscrowState.Dispatched || order.state == EscrowState.Delivered,
            "NodeKartEscrow: cannot settle in current state"
        );

        _executeSettlement(order);
    }

    /**
     * @notice Automated Fallback: If carrier confirmed delivery via Chainlink DON and the buyer
     * is unresponsive for 48 hours, anyone can trigger automated settlement to release merchant funds.
     */
    function claimAutomatedSettlement(uint256 escrowId) external nonReentrant {
        OrderEscrow storage order = escrows[escrowId];
        require(order.state == EscrowState.Delivered, "NodeKartEscrow: order not delivered");
        require(block.timestamp >= order.disputeDeadline, "NodeKartEscrow: 48h dispute deadline not passed");

        _executeSettlement(order);
    }

    /**
     * @dev Internal settlement logic executing Nash equilibrium payouts and rewards
     */
    function _executeSettlement(OrderEscrow storage order) internal {
        order.state = EscrowState.Settled;

        uint256 sellerPayout = order.itemPrice + order.sellerCollateral;
        uint256 buyerRefund  = order.buyerCollateral;
        uint256 cashbackAmt  = (order.itemPrice * CASHBACK_BPS) / BPS_DENOMINATOR;

        // Payout to seller (Item price + Seller Collateral returned)
        if (sellerPayout > 0) {
            IERC20(address(sharpToken)).safeTransfer(order.seller, sellerPayout);
        }

        // Refund buyer collateral
        if (buyerRefund > 0) {
            IERC20(address(sharpToken)).safeTransfer(order.buyer, buyerRefund);
        }

        // Programmatically mint 5% SHARP cashback reward to buyer
        if (cashbackAmt > 0) {
            try sharpToken.mintCashback(order.buyer, cashbackAmt) {} catch {}
        }

        // Record on-chain ERC-5192 Soulbound reputation for both parties
        try reputationSBT.recordSettlement(order.seller, order.itemPrice, 50) {} catch {}
        try reputationSBT.recordSettlement(order.buyer, order.itemPrice, 50) {} catch {}

        emit EscrowSettled(order.id, order.seller, order.buyer, sellerPayout, cashbackAmt);
    }

    // ─── Disputes & Dual-Deposit Nash Equilibrium Slashing ──────────────────────

    /**
     * @notice Buyer raises a dispute within the 48-hour window, halting automated settlement
     */
    function raiseDispute(uint256 escrowId, string calldata reason)
        external
        nonReentrant
        onlyBuyer(escrowId)
    {
        OrderEscrow storage order = escrows[escrowId];
        require(
            order.state == EscrowState.Dispatched || order.state == EscrowState.Delivered,
            "NodeKartEscrow: cannot dispute in current state"
        );

        order.state = EscrowState.Disputed;
        emit DisputeRaised(escrowId, msg.sender, reason);
    }

    /**
     * @notice Resolves dispute via Nash Equilibrium rules:
     * - If Seller at fault (e.g., fraud/counterfeit/fake tracking):
     *     Buyer receives full refund (price + buyer deposit) + seller collateral as compensation.
     *     Seller collateral is slashed. Seller SBT reputation penalized.
     * - If Buyer at fault (e.g., false dispute after verified delivery):
     *     Seller receives item price + seller collateral + buyer collateral as compensation.
     *     Buyer deposit is slashed. Buyer SBT reputation penalized.
     */
    function resolveDisputeNash(
        uint256 escrowId,
        bool sellerAtFault,
        bool buyerAtFault
    ) external onlyOwner nonReentrant inState(escrowId, EscrowState.Disputed) {
        OrderEscrow storage order = escrows[escrowId];
        order.state = EscrowState.Settled;

        if (sellerAtFault && !buyerAtFault) {
            // Seller slashed: Buyer gets itemPrice + buyerCollateral + sellerCollateral
            uint256 buyerTotal = order.itemPrice + order.buyerCollateral + order.sellerCollateral;
            IERC20(address(sharpToken)).safeTransfer(order.buyer, buyerTotal);
            try reputationSBT.recordDisputePenalty(order.seller) {} catch {}
        } else if (buyerAtFault && !sellerAtFault) {
            // Buyer slashed: Seller gets itemPrice + sellerCollateral + buyerCollateral
            uint256 sellerTotal = order.itemPrice + order.sellerCollateral + order.buyerCollateral;
            IERC20(address(sharpToken)).safeTransfer(order.seller, sellerTotal);
            try reputationSBT.recordDisputePenalty(order.buyer) {} catch {}
        } else {
            // Split / mutual refund
            uint256 sellerTotal = order.sellerCollateral;
            uint256 buyerTotal = order.itemPrice + order.buyerCollateral;
            if (sellerTotal > 0) IERC20(address(sharpToken)).safeTransfer(order.seller, sellerTotal);
            if (buyerTotal > 0)  IERC20(address(sharpToken)).safeTransfer(order.buyer, buyerTotal);
        }

        emit DisputeResolvedNash(escrowId, sellerAtFault, buyerAtFault);
    }

    // ─── View Helpers ──────────────────────────────────────────────────────────

    function getEscrow(uint256 escrowId) external view returns (OrderEscrow memory) {
        return escrows[escrowId];
    }

    function getUserEscrows(address user) external view returns (uint256[] memory) {
        return _userEscrows[user];
    }

    function totalEscrowCount() external view returns (uint256) {
        return _nextEscrowId - 1;
    }
}
