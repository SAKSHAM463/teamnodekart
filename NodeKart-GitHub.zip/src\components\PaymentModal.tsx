// ─────────────────────────────────────────────────────────────
//  src/components/PaymentModal.tsx
//  Async promise-driven Web3 payment & dual-deposit escrow state machine.
// ─────────────────────────────────────────────────────────────

import React, { useEffect, useState, useRef } from 'react';
import { LockKeyhole, Check, AlertCircle, ShieldCheck } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatMoney } from '../mockData';
import { buildGaslessUserOp } from '../lib/paymaster';

type StepStatus = 'pending' | 'active' | 'done' | 'error';

interface PaymentStep {
  title:  string;
  copy:   string;
  status: StepStatus;
}

const buildSteps = (total: number): PaymentStep[] => [
  {
    title:  '1. Wallet & Lit Protocol Authentication',
    copy:   'Signing threshold condition & securing client-side PII encryption.',
    status: 'pending',
  },
  {
    title:  '2. ERC-4337 Paymaster Gas Sponsorship',
    copy:   'Verifying UserOperation gasless sponsorship with zero gas fees.',
    status: 'pending',
  },
  {
    title:  '3. Approving SHARP Transfer',
    copy:   'Authorizing NodeKartEscrow smart contract for deposit lock.',
    status: 'pending',
  },
  {
    title:  '4. Locking Dual-Deposit Escrow',
    copy:   `Securing purchase (${formatMoney(total)}) + 5% buyer deposit on-chain.`,
    status: 'pending',
  },
  {
    title:  '5. Chainlink DON Logistics Linked',
    copy:   'Escrow secured. Connected to decentralized logistics oracle.',
    status: 'pending',
  },
];

export const PaymentModal: React.FC = () => {
  const {
    activeModal,
    closeModal,
    navigate,
    showToast,
    selectedProduct,
    cart,
    connectWallet,
    createEscrow,
    clearCart,
    sharpBalance,
    walletAddress,
  } = useApp();

  // Use cart total if cart has items, otherwise fall back to selected product
  const orderTotal = cart.length > 0
    ? cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0)
    : selectedProduct.price;

  const [steps,          setSteps]          = useState<PaymentStep[]>(() => buildSteps(orderTotal));
  const [globalError,    setGlobalError]    = useState<string | null>(null);
  const [activeStepIdx,  setActiveStepIdx]  = useState(-1);
  const isMounted = useRef(true);

  useEffect(() => {
    if (activeModal === 'payment') {
      isMounted.current = true;
      setSteps(buildSteps(orderTotal));
      setGlobalError(null);
      setActiveStepIdx(-1);
      runPaymentFlow();
    }
    return () => {
      isMounted.current = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeModal]);

  const activateStep = (idx: number) => {
    if (!isMounted.current) return;
    setActiveStepIdx(idx);
    setSteps(prev =>
      prev.map((s, i) => ({
        ...s,
        status: i < idx ? 'done' : i === idx ? 'active' : 'pending',
      }))
    );
  };

  const completeStep = (idx: number) => {
    if (!isMounted.current) return;
    setSteps(prev =>
      prev.map((s, i) => ({ ...s, status: i <= idx ? 'done' : s.status }))
    );
  };

  const errorStep = (idx: number, message: string) => {
    if (!isMounted.current) return;
    setSteps(prev =>
      prev.map((s, i) => ({ ...s, status: i === idx ? 'error' : s.status }))
    );
    setGlobalError(message);
  };

  const runPaymentFlow = async () => {
    try {
      // Step 0 · Connect wallet & Lit Protocol Auth
      activateStep(0);
      await connectWallet();
      completeStep(0);

      // Step 1 · Validate balance & ERC-4337 Paymaster Gas Sponsorship
      activateStep(1);
      const buyerCollateral = Math.round(orderTotal * 0.05);
      const totalRequired   = orderTotal + buyerCollateral;
      const numBal          = Number(sharpBalance || '0');
      if (numBal > 0 && numBal < totalRequired) {
        throw new Error(
          `Insufficient SHARP. You have ${numBal.toLocaleString()} but need ${totalRequired.toLocaleString()} SHARP (includes 5% collateral).`
        );
      }

      // Build UserOperation with Verifying Paymaster sponsorship
      if (walletAddress) {
        await buildGaslessUserOp(walletAddress);
      }
      await new Promise(res => setTimeout(res, 500));
      completeStep(1);

      // Step 2 · Approve token transfer
      activateStep(2);
      await new Promise(res => setTimeout(res, 600));
      completeStep(2);

      // Step 3 · Lock Dual-Deposit Escrow
      activateStep(3);
      const primaryProduct = cart.length > 0 ? cart[0].product : selectedProduct;
      const sellerAddress = primaryProduct.sellerWallet || '0x70997970C51812dc3A010C7d01b50e0d17dc79C8';
      const sellerCol     = (orderTotal * 0.1).toString();
      const buyerCol      = (orderTotal * 0.05).toString();

      await createEscrow(
        sellerAddress,
        orderTotal.toString(),
        sellerCol,
        buyerCol,
        primaryProduct.id
      );
      completeStep(3);

      // Step 4 · Chainlink DON Logistics Linked & Done
      activateStep(4);
      completeStep(4);

      await new Promise(resolve => setTimeout(resolve, 800));
      if (isMounted.current) {
        // Clear cart after successful payment
        clearCart();
        closeModal();
        navigate('orders');
        showToast('Payment locked in Dual-Deposit Escrow. Chainlink Oracle linked!');
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Payment failed. Please try again.';
      errorStep(activeStepIdx, message);
      showToast(message);
    }
  };

  if (activeModal !== 'payment') return null;

  const doneCount    = steps.filter(s => s.status === 'done').length;
  const progressPct  = Math.round((doneCount / steps.length) * 100);
  const currentStep  = steps.find(s => s.status === 'active') ?? steps[doneCount] ?? steps[steps.length - 1];

  return (
    <div className="fixed inset-0 z-50 bg-[#050806]/85 backdrop-blur-sm grid place-items-center p-4">
      <div className="w-full max-w-[480px] bg-[#17211b] border border-[#3d5542] rounded-lg p-8 sm:p-9 text-center shadow-[0_25px_80px_rgba(0,0,0,0.6)] animate-rise text-ink">
        {/* Animated Orb */}
        <div className={`w-[68px] h-[68px] rounded-full mx-auto mb-5 grid place-items-center shadow-[0_0_0_11px_rgba(200,239,105,0.15)] ${
          globalError
            ? 'bg-red-500/20 border border-red-500/40'
            : 'bg-lime text-[#19231a] animate-pulse'
        }`}>
          {globalError
            ? <AlertCircle className="w-7 h-7 text-red-400" />
            : <LockKeyhole className="w-7 h-7" />
          }
        </div>

        <p className="font-mono text-[10px] text-lime uppercase tracking-widest mb-2 flex items-center justify-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5" />
          NodeKart Production Web3 Pipeline
        </p>

        <h2 className="font-display font-semibold text-2xl text-ink min-h-[32px]">
          {globalError ? 'Transaction failed' : currentStep.title}
        </h2>

        <p className={`text-xs mt-2 min-h-[36px] ${globalError ? 'text-red-400' : 'text-muted'}`}>
          {globalError ?? currentStep.copy}
        </p>

        {/* Total amount being locked */}
        <div className="my-4 bg-[#1e2d22] border border-[#3a5340] rounded-lg py-2.5 px-4 inline-flex items-center gap-2">
          <LockKeyhole className="w-3.5 h-3.5 text-lime" />
          <span className="font-mono text-xs text-lime font-bold">{formatMoney(orderTotal)}</span>
          <span className="text-muted text-[10px]">secured in smart escrow</span>
        </div>

        {/* Step Indicators */}
        <div className="text-left my-6 max-w-[360px] mx-auto grid gap-2.5">
          {steps.map((s, idx) => (
            <div
              key={idx}
              className={`flex items-center gap-2.5 text-xs transition-colors ${
                s.status === 'done'   ? 'text-ink font-semibold'  :
                s.status === 'active' ? 'text-ink font-semibold'  :
                s.status === 'error'  ? 'text-red-400 font-semibold' :
                'text-[#637168]'
              }`}
            >
              <span className={`w-5 h-5 rounded-full grid place-items-center font-mono text-[9px] border transition-colors flex-shrink-0 ${
                s.status === 'done'   ? 'bg-lime text-[#18231a] border-lime'      :
                s.status === 'active' ? 'bg-lime/30 border-lime text-lime'        :
                s.status === 'error'  ? 'bg-red-500/20 border-red-500 text-red-400' :
                'border-line text-muted'
              }`}>
                {s.status === 'done' ? <Check className="w-3 h-3" /> : idx + 1}
              </span>
              <span className="truncate">{s.title}</span>
            </div>
          ))}
        </div>

        {/* Progress Bar */}
        <div className="h-1 bg-line rounded-full overflow-hidden w-full">
          <div
            className={`h-full transition-all duration-700 ease-out ${
              globalError ? 'bg-red-500' : 'bg-lime'
            }`}
            style={{ width: `${progressPct}%` }}
          />
        </div>

        {/* Retry on error */}
        {globalError && (
          <button
            onClick={() => {
              setGlobalError(null);
              setSteps(buildSteps(orderTotal));
              runPaymentFlow();
            }}
            className="mt-5 text-xs text-lime underline hover:no-underline"
          >
            Try again
          </button>
        )}
      </div>
    </div>
  );
};
