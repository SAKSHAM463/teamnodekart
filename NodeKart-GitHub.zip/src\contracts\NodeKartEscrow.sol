// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title  NodeKartEscrow
 * @notice Trustless peer-to-peer escrow for NodeKart marketplace transactions.
 *
 * State machine lifecycle:
 *
 *   [AwaitingPayment]
 *         │  buyer calls deposit()
 *         ▼
 *   [AwaitingDelivery]
 *         │  buyer calls confirmDelivery()     buyer calls dispute()
 *         ▼                                          ▼
 *     [Complete]                               [Disputed]
 *                                                    │  arbiter calls resolveDispute()
 *                                                    ▼
 *                                        funds → seller OR buyer
 *
 * Timeout safety valve:
 *   If buyer never calls confirmDelivery() within TIMEOUT_PERIOD days,
 *   the seller can call claimTimeout() to recover funds.
 *
 * Security patterns applied:
 *   - Check-Effects-Interactions (CEI) throughout all state-changing functions
 *   - Role-based access modifiers (onlyBuyer, onlySeller, onlyArbiter)
 *   - No external calls before state updates
 */
contract NodeKartEscrow {

    // ─── State Machine ────────────────────────────────────────────────────────

    enum State {
        AwaitingPayment,   // 0 · Contract deployed, no funds locked yet
        AwaitingDelivery,  // 1 · Buyer has deposited; seller must dispatch
        Complete,          // 2 · Buyer confirmed delivery; seller paid out
        Disputed           // 3 · Buyer raised a dispute; arbiter to resolve
    }

    // ─── Storage ──────────────────────────────────────────────────────────────

    address payable public immutable buyer;
    address payable public immutable seller;
    address public immutable arbiter;

    uint256 public amount;
    uint256 public deadline;
    State   public state;

    /// @dev 7 days in seconds. Seller can claim funds if buyer goes silent.
    uint256 public constant TIMEOUT_PERIOD = 7 days;

    // ─── Events ───────────────────────────────────────────────────────────────

    event FundsDeposited(address indexed buyer,     uint256 amount);
    event EscrowReleased(address indexed seller,    uint256 amount);
    event DisputeRaised (address indexed raisedBy);
    event DisputeResolved(bool releasedToSeller);
    event TimeoutClaimed(address indexed claimedBy);

    // ─── Modifiers ────────────────────────────────────────────────────────────

    modifier onlyBuyer()   { require(msg.sender == buyer,   "NodeKartEscrow: caller is not the buyer");   _; }
    modifier onlySeller()  { require(msg.sender == seller,  "NodeKartEscrow: caller is not the seller");  _; }
    modifier onlyArbiter() { require(msg.sender == arbiter, "NodeKartEscrow: caller is not the arbiter"); _; }

    modifier inState(State expected) {
        require(state == expected, "NodeKartEscrow: invalid state for this action");
        _;
    }

    // ─── Constructor ──────────────────────────────────────────────────────────

    /**
     * @param _seller  Address of the seller who will receive funds on settlement.
     * @param _arbiter Address of the trusted arbiter for dispute resolution
     *                 (e.g. NodeKart's multisig or DAO contract).
     *
     * The deploying address becomes the buyer automatically.
     */
    constructor(address payable _seller, address _arbiter) {
        require(_seller  != address(0), "NodeKartEscrow: seller is zero address");
        require(_arbiter != address(0), "NodeKartEscrow: arbiter is zero address");
        require(_seller  != msg.sender, "NodeKartEscrow: buyer and seller cannot be the same");

        buyer   = payable(msg.sender);
        seller  = _seller;
        arbiter = _arbiter;
        state   = State.AwaitingPayment;
    }

    // ─── Core Functions ───────────────────────────────────────────────────────

    /**
     * @notice Buyer locks funds in escrow.
     *         Transitions: AwaitingPayment → AwaitingDelivery.
     *
     * CEI pattern:
     *   Check  — state guard via inState modifier
     *   Effect — update state and storage before any transfer
     *   Interact — emit event (no external call)
     */
    function deposit()
        external
        payable
        onlyBuyer
        inState(State.AwaitingPayment)
    {
        require(msg.value > 0, "NodeKartEscrow: deposit must be greater than zero");

        // Effects
        amount   = msg.value;
        deadline = block.timestamp + TIMEOUT_PERIOD;
        state    = State.AwaitingDelivery;

        // Interact (event only — no external call)
        emit FundsDeposited(msg.sender, msg.value);
    }

    /**
     * @notice Buyer confirms receipt of goods; releases payment to seller.
     *         Transitions: AwaitingDelivery → Complete.
     */
    function confirmDelivery()
        external
        onlyBuyer
        inState(State.AwaitingDelivery)
    {
        uint256 payout = amount;

        // Effects first
        state  = State.Complete;
        amount = 0;

        // Interact — transfer after state update (CEI)
        (bool success, ) = seller.call{value: payout}("");
        require(success, "NodeKartEscrow: seller payout failed");

        emit EscrowReleased(seller, payout);
    }

    /**
     * @notice Buyer raises a dispute; halts automatic settlement.
     *         Transitions: AwaitingDelivery → Disputed.
     */
    function dispute()
        external
        onlyBuyer
        inState(State.AwaitingDelivery)
    {
        state = State.Disputed;
        emit DisputeRaised(msg.sender);
    }

    /**
     * @notice Arbiter resolves a dispute, directing funds to either party.
     * @param releaseToSeller If true, seller is paid; if false, buyer is refunded.
     *
     * Can only be called while state == Disputed.
     */
    function resolveDispute(bool releaseToSeller)
        external
        onlyArbiter
        inState(State.Disputed)
    {
        uint256 payout = amount;
        address payable recipient = releaseToSeller ? seller : buyer;

        // Effects first
        state  = State.Complete;
        amount = 0;

        // Interact
        (bool success, ) = recipient.call{value: payout}("");
        require(success, "NodeKartEscrow: dispute payout failed");

        emit DisputeResolved(releaseToSeller);
    }

    /**
     * @notice Seller reclaims funds if buyer never confirms delivery within TIMEOUT_PERIOD.
     *         Prevents funds from being permanently frozen.
     *         Transitions: AwaitingDelivery → Complete.
     */
    function claimTimeout()
        external
        onlySeller
        inState(State.AwaitingDelivery)
    {
        require(block.timestamp >= deadline, "NodeKartEscrow: timeout period has not elapsed");

        uint256 payout = amount;

        // Effects first
        state  = State.Complete;
        amount = 0;

        // Interact
        (bool success, ) = seller.call{value: payout}("");
        require(success, "NodeKartEscrow: timeout payout failed");

        emit TimeoutClaimed(msg.sender);
    }

    // ─── View Helpers ─────────────────────────────────────────────────────────

    /// @notice Returns the current escrow state as a uint8 (mirrors the State enum).
    function getState() external view returns (State) {
        return state;
    }

    /// @notice Convenience helper: returns true if the timeout window has passed.
    function isTimedOut() external view returns (bool) {
        return state == State.AwaitingDelivery && block.timestamp >= deadline;
    }
}
