// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

/**
 * @title IERC5192
 * @notice Minimal Non-Transferable (Soulbound) Token standard interface (EIP-5192)
 */
interface IERC5192 {
    /// @notice Emitted when a token's locked status is set to true.
    event Locked(uint256 tokenId);

    /// @notice Emitted when a token's locked status is set to false.
    event Unlocked(uint256 tokenId);

    /// @notice Returns true if the token is locked (non-transferable).
    function locked(uint256 tokenId) external view returns (bool);
}

/**
 * @title NodeKartReputationSBT
 * @notice ERC-5192 compliant Soulbound Token representing verified commercial reputation,
 * trade history, and trust metrics for NodeKart buyers and merchants.
 */
contract NodeKartReputationSBT is ERC721, IERC5192, Ownable {

    struct ReputationScore {
        uint256 completedTrades;
        uint256 totalVolume;      // Total SHARP transacted
        uint256 disputeFreeStreak;
        uint256 totalRatingPoints;// Cumulative rating points (e.g., 50 = 5.0 * 10)
        uint256 ratingCount;
        uint256 slashedCount;
        uint256 lastUpdated;
    }

    uint256 private _nextTokenId = 1;

    /// @notice Mapping from user address to their Soulbound Token ID
    mapping(address => uint256) public userToTokenId;

    /// @notice Mapping from Token ID to user reputation metrics
    mapping(uint256 => ReputationScore) public reputations;

    /// @notice Contracts authorized to update reputation (e.g. NodeKartEscrow)
    mapping(address => bool) public isAuthorizedUpdater;

    // Interface ID for ERC-5192: bytes4(keccak256("locked(uint256)")) == 0xb45a3c0e
    bytes4 private constant _INTERFACE_ID_ERC5192 = 0xb45a3c0e;

    event ReputationUpdated(address indexed user, uint256 tokenId, uint256 completedTrades, uint256 totalVolume);
    event ReputationSlashed(address indexed user, uint256 tokenId, uint256 newSlashedCount);
    event UpdaterStatusChanged(address indexed updater, bool authorized);

    modifier onlyAuthorized() {
        require(isAuthorizedUpdater[msg.sender] || msg.sender == owner(), "NodeKartReputationSBT: unauthorized caller");
        _;
    }

    constructor(address initialOwner) ERC721("NodeKart Soulbound Reputation", "NK-REP") Ownable(initialOwner) {}

    /**
     * @notice Grants or revokes permission for a contract (NodeKartEscrow) to record reputation
     */
    function setAuthorizedUpdater(address updater, bool authorized) external onlyOwner {
        require(updater != address(0), "NodeKartReputationSBT: zero address");
        isAuthorizedUpdater[updater] = authorized;
        emit UpdaterStatusChanged(updater, authorized);
    }

    /**
     * @notice All tokens are permanently locked as Soulbound credentials
     */
    function locked(uint256 tokenId) external view override returns (bool) {
        _requireOwned(tokenId);
        return true;
    }

    /**
     * @notice Records a completed trade settlement for a user. Mints an SBT if the user does not yet have one.
     */
    function recordSettlement(
        address user,
        uint256 volume,
        uint256 ratingPoints // e.g. 50 for 5.0 rating
    ) external onlyAuthorized returns (uint256 tokenId) {
        require(user != address(0), "NodeKartReputationSBT: zero address");

        tokenId = userToTokenId[user];
        if (tokenId == 0) {
            tokenId = _nextTokenId++;
            userToTokenId[user] = tokenId;
            _safeMint(user, tokenId);
            emit Locked(tokenId);
        }

        ReputationScore storage rep = reputations[tokenId];
        rep.completedTrades += 1;
        rep.totalVolume += volume;
        rep.disputeFreeStreak += 1;
        if (ratingPoints > 0) {
            rep.totalRatingPoints += ratingPoints;
            rep.ratingCount += 1;
        }
        rep.lastUpdated = block.timestamp;

        emit ReputationUpdated(user, tokenId, rep.completedTrades, rep.totalVolume);
    }

    /**
     * @notice Records a dispute penalty / slashing event
     */
    function recordDisputePenalty(address user) external onlyAuthorized returns (uint256 tokenId) {
        require(user != address(0), "NodeKartReputationSBT: zero address");
        tokenId = userToTokenId[user];
        if (tokenId == 0) {
            tokenId = _nextTokenId++;
            userToTokenId[user] = tokenId;
            _safeMint(user, tokenId);
            emit Locked(tokenId);
        }

        ReputationScore storage rep = reputations[tokenId];
        rep.slashedCount += 1;
        rep.disputeFreeStreak = 0;
        rep.lastUpdated = block.timestamp;

        emit ReputationSlashed(user, tokenId, rep.slashedCount);
    }

    /**
     * @notice Reads reputation metrics for a given user
     */
    function getReputationByUser(address user) external view returns (
        uint256 tokenId,
        uint256 completedTrades,
        uint256 totalVolume,
        uint256 disputeFreeStreak,
        uint256 averageRatingX10,
        uint256 slashedCount
    ) {
        tokenId = userToTokenId[user];
        if (tokenId == 0) {
            return (0, 0, 0, 0, 0, 0);
        }
        ReputationScore memory rep = reputations[tokenId];
        uint256 avgRating = rep.ratingCount > 0 ? (rep.totalRatingPoints / rep.ratingCount) : 50;
        return (
            tokenId,
            rep.completedTrades,
            rep.totalVolume,
            rep.disputeFreeStreak,
            avgRating,
            rep.slashedCount
        );
    }

    /**
     * @dev Prevents any token transfer (Soulbound enforcement) except minting/burning
     */
    function _update(address to, uint256 tokenId, address auth) internal virtual override returns (address) {
        address from = _ownerOf(tokenId);
        // Allow minting (from == 0) and burning (to == 0), but prohibit any peer-to-peer transfer
        if (from != address(0) && to != address(0)) {
            revert("ERC5192: Token is Soulbound and non-transferable");
        }
        return super._update(to, tokenId, auth);
    }

    /**
     * @dev Supports standard ERC165 and ERC5192 interface
     */
    function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
        return interfaceId == _INTERFACE_ID_ERC5192 || super.supportsInterface(interfaceId);
    }
}
