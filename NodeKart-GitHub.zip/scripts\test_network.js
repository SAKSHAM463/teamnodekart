import hardhat from "hardhat";

async function main() {
  console.log("hardhat.network keys:", Object.keys(hardhat.network));
  console.log("hardhat.network.provider:", hardhat.network.provider);
}

main().catch(console.error);
