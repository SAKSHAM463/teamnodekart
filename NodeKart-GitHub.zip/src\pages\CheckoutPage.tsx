// ─────────────────────────────────────────────────────────────
//  src/pages/CheckoutPage.tsx
// ─────────────────────────────────────────────────────────────

import React, { useState } from 'react';
import {
  ArrowLeft,
  CheckCircle2,
  LockKeyhole,
  ShieldCheck,
  ArrowUpRight,
  WalletCards,
  KeyRound,
  Zap,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatMoney, INITIAL_USER } from '../mockData';
import { encryptShippingAddress } from '../services/privacy';

export const CheckoutPage: React.FC = () => {
  const {
    cart,
    selectedProduct,
    navigate,
    openModal,
    walletBalance,
    walletAddress,
    isWalletConnected,
    isWalletLoading,
    connectWallet,
    truncateAddress,
    showToast,
  } = useApp();

  const [formData, setFormData] = useState({
    fullName: INITIAL_USER.name,
    phone:    '+91 98765 43210',
    address:  '42, 5th Cross, Indiranagar',
    city:     'Bengaluru',
    state:    'Karnataka',
    pincode:  '560038',
  });

  const [isEncrypting, setIsEncrypting] = useState(false);

  // If cart has items, use cart total; otherwise fall back to selected product
  const hasCartItems  = cart.length > 0;
  const subtotal      = hasCartItems
    ? cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0)
    : selectedProduct.price;
  const cashback      = Math.round(subtotal * 0.05);
  const totalItems    = hasCartItems
    ? cart.reduce((sum, item) => sum + item.quantity, 0)
    : 1;

  const primaryProduct = hasCartItems ? cart[0].product : selectedProduct;
  const sellerWallet = primaryProduct.sellerWallet || '0x70997970C51812dc3A010C7d01b50e0d17dc79C8';

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handlePay = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsEncrypting(true);
    try {
      // Module 1: Encrypt buyer's PII shipping address client-side with Lit Protocol
      const encrypted = await encryptShippingAddress(formData, sellerWallet, 1);
      sessionStorage.setItem('nodekart_encrypted_shipping', JSON.stringify(encrypted));
      showToast('🔒 Shipping PII encrypted with Lit Protocol threshold guard');
      openModal('payment');
    } catch {
      openModal('payment');
    } finally {
      setIsEncrypting(false);
    }
  };

  // Display address — real wallet address when connected, mock otherwise
  const displayAddress = walletAddress
    ? truncateAddress(walletAddress)
    : INITIAL_USER.walletAddressShort;

  // Items to display in the order summary
  const orderItems = hasCartItems
    ? cart
    : [{ product: selectedProduct, quantity: 1 }];

  return (
    <div className="max-w-[1200px] mx-auto px-[5%] py-8 sm:py-12 animate-rise">
      {/* Back Button */}
      <button
        onClick={() => hasCartItems ? navigate('cart') : navigate('product', selectedProduct)}
        className="text-muted hover:text-ink text-xs inline-flex items-center gap-2 mb-6 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>{hasCartItems ? 'Back to basket' : 'Back to product'}</span>
      </button>

      <form onSubmit={handlePay} className="grid grid-cols-1 lg:grid-cols-[1.3fr_0.8fr] gap-10 lg:gap-14 items-start">
        {/* Left Form Content */}
        <div>
          <div className="mb-6">
            <p className="font-mono text-[10px] uppercase tracking-widest text-lime mb-1">
              Secure checkout · 4-Tier Web3 Architecture
            </p>
            <h1 className="font-display font-semibold text-3xl sm:text-5xl text-ink">
              Almost <em className="font-serif font-normal text-lime">yours.</em>
            </h1>
          </div>

          {/* Lit Protocol Cryptographic Privacy Banner */}
          <div className="bg-[#17221b] border border-[#3b533f] rounded-lg p-4 mb-6 flex items-start gap-3">
            <KeyRound className="w-5 h-5 text-lime flex-shrink-0 mt-0.5" />
            <div>
              <b className="text-xs font-semibold text-ink block">
                Lit Protocol Cryptographic Privacy Guard
              </b>
              <p className="text-[#b4c3b2] text-[11px] leading-relaxed mt-1">
                Your shipping address is encrypted client-side using threshold cryptography. No plaintext PII is ever stored on-chain. Only the designated seller key for this Escrow ID can decrypt your delivery details.
              </p>
            </div>
          </div>

          {/* Delivery Details */}
          <div className="border-t border-line pt-6 mt-4">
            <div className="flex justify-between items-center mb-5">
              <h2 className="font-display font-semibold text-lg text-ink">
                Delivery details
              </h2>
              <span className="font-mono text-[10px] text-lime bg-lime/10 border border-lime/20 rounded px-2 py-0.5 flex items-center gap-1">
                <LockKeyhole className="w-3 h-3" />
                Zero-Knowledge Encrypted
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] text-muted uppercase font-mono mb-1.5">
                  Full name
                </label>
                <input
                  type="text"
                  name="fullName"
                  value={formData.fullName}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-[#151d18] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime transition-colors"
                />
              </div>

              <div>
                <label className="block text-[10px] text-muted uppercase font-mono mb-1.5">
                  Phone number
                </label>
                <input
                  type="text"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-[#151d18] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime transition-colors"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[10px] text-muted uppercase font-mono mb-1.5">
                  Delivery address
                </label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-[#151d18] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime transition-colors"
                />
              </div>

              <div>
                <label className="block text-[10px] text-muted uppercase font-mono mb-1.5">
                  City
                </label>
                <input
                  type="text"
                  name="city"
                  value={formData.city}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-[#151d18] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime transition-colors"
                />
              </div>

              <div>
                <label className="block text-[10px] text-muted uppercase font-mono mb-1.5">
                  State
                </label>
                <input
                  type="text"
                  name="state"
                  value={formData.state}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-[#151d18] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime transition-colors"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[10px] text-muted uppercase font-mono mb-1.5">
                  PIN code
                </label>
                <input
                  type="text"
                  name="pincode"
                  value={formData.pincode}
                  onChange={handleInputChange}
                  required
                  className="w-full bg-[#151d18] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime transition-colors"
                />
              </div>
            </div>
          </div>

          {/* Payment Section */}
          <div className="border-t border-line pt-6 mt-8">
            <h2 className="font-display font-semibold text-lg text-ink mb-4">
              Payment method
            </h2>

            <div className="flex justify-between items-center text-xs text-muted mb-3">
              <span>Your SHARP balance</span>
              <b className="font-mono text-lime font-bold">
                {formatMoney(walletBalance)}
              </b>
            </div>

            {/* Wallet Connection Card */}
            {isWalletConnected ? (
              /* Connected state */
              <div className="flex items-center gap-3 bg-[#202c25] border border-line p-3.5 rounded-lg text-lime">
                <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <b className="text-xs font-semibold text-ink block">Wallet connected</b>
                  <small className="font-mono text-[10px] text-muted block truncate mt-0.5">
                    {displayAddress} · NodeKart Network
                  </small>
                </div>
                <button
                  type="button"
                  onClick={connectWallet}
                  className="text-lime hover:text-ink text-xs font-semibold underline"
                >
                  Change
                </button>
              </div>
            ) : (
              /* Not connected — prompt to connect */
              <div className="flex items-center gap-3 bg-[#1e2820] border border-[#4a5e44] p-3.5 rounded-lg">
                <WalletCards className="w-5 h-5 text-lime flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <b className="text-xs font-semibold text-ink block">No wallet connected</b>
                  <small className="font-mono text-[10px] text-muted block mt-0.5">
                    Connect your wallet to pay with SHARP
                  </small>
                </div>
                <button
                  type="button"
                  onClick={connectWallet}
                  disabled={isWalletLoading}
                  className="bg-lime hover:bg-[#b8df5d] text-[#122016] text-[10px] font-extrabold py-1.5 px-3 rounded transition-colors disabled:opacity-60"
                >
                  {isWalletLoading ? 'Connecting…' : 'Connect'}
                </button>
              </div>
            )}

            {/* ERC-4337 Gasless Paymaster Badge */}
            <div className="flex items-center gap-3 p-3.5 bg-[#18231a] border border-[#3b533e] rounded-lg mt-4">
              <Zap className="w-4 h-4 text-lime flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <b className="text-xs text-ink font-semibold flex items-center gap-1.5">
                  ERC-4337 Verifying Paymaster Active
                  <span className="font-mono text-[9px] text-lime bg-lime/15 px-1.5 py-0.5 rounded">0 Gas Fee</span>
                </b>
                <p className="text-muted text-[11px] mt-0.5">
                  NodeKart Paymaster automatically sponsors Ethereum gas execution for your checkout.
                </p>
              </div>
            </div>

            {/* Escrow Info Card */}
            <div className="flex items-start gap-3 p-4 bg-[#253727] border border-[#4b643e] rounded-lg mt-4 text-lime">
              <LockKeyhole className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <div>
                <b className="text-xs font-semibold text-ink block">
                  Dual-Deposit Escrow Protection Active
                </b>
                <p className="text-[#b4c3b2] text-[11px] leading-relaxed my-1.5">
                  Your {formatMoney(subtotal)} payment will remain securely locked
                  until the agreed courier delivery condition is verified by the Chainlink DON Logistics Oracle.
                </p>
                <span className="font-mono text-[9px] text-lime flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  Transparent settlement · Zero extra fee
                </span>
              </div>
            </div>

            {/* Confirm Button */}
            <button
              type="submit"
              disabled={isEncrypting}
              className="w-full bg-lime hover:bg-[#b8df5d] text-[#122016] py-3.5 px-4 rounded-[5px] font-extrabold text-xs inline-flex items-center justify-center gap-2 transition-colors mt-6 shadow-lg disabled:opacity-60"
            >
              <span>{isEncrypting ? 'Encrypting with Lit Protocol…' : 'Confirm & lock payment'}</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right Summary Sidebar */}
        <aside className="bg-panel border border-line rounded-lg p-6 sticky top-24 shadow-xl">
          <h3 className="font-display font-semibold text-lg text-ink mb-5">
            Order summary
          </h3>

          {/* Items list */}
          <div className="space-y-3 pb-5 border-b border-line">
            {orderItems.map(({ product, quantity }) => (
              <div key={product.id} className="flex items-center gap-3.5">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-12 h-12 object-cover rounded bg-[#202923] border border-line flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <span className="text-xs font-medium text-ink block truncate">{product.name}</span>
                  <small className="text-[10px] text-muted block mt-0.5">
                    {product.seller}{quantity > 1 ? ` × ${quantity}` : ''}
                  </small>
                </div>
                <b className="font-mono text-xs text-lime flex-shrink-0">
                  {formatMoney(product.price * quantity)}
                </b>
              </div>
            ))}
          </div>

          <div className="space-y-3 text-xs text-muted mt-5">
            <div className="flex justify-between items-center">
              <span>Subtotal ({totalItems} {totalItems === 1 ? 'item' : 'items'})</span>
              <b className="font-mono text-ink">{formatMoney(subtotal)}</b>
            </div>

            <div className="flex justify-between items-center">
              <span>Shipping</span>
              <b className="text-lime font-mono">Free</b>
            </div>

            <div className="flex justify-between items-center">
              <span>Gas Network Fee (Paymaster)</span>
              <b className="text-lime font-mono">0.000 ETH (Sponsored)</b>
            </div>

            <div className="flex justify-between items-center">
              <span>Cashback after delivery</span>
              <b className="text-lime font-mono">+{formatMoney(cashback)}</b>
            </div>

            <hr className="border-line my-4" />

            <div className="flex justify-between items-center text-ink font-semibold">
              <span>Total due</span>
              <b className="font-mono text-base text-ink">{formatMoney(subtotal)}</b>
            </div>
          </div>
        </aside>
      </form>
    </div>
  );
};
