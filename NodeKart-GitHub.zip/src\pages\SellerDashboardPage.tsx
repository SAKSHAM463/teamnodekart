// ─────────────────────────────────────────────────────────────
//  src/pages/SellerDashboardPage.tsx
//  Merchant Portal with Dual-Deposit Collateral, SBT Reputation & Lit PII Decryption.
// ─────────────────────────────────────────────────────────────

import React, { useState } from 'react';
import {
  Plus,
  LockKeyhole,
  ShieldCheck,
  Truck,
  Check,
  Package,
  KeyRound,
  Eye,
  EyeOff,
  MapPin,
  Phone,
  User,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatMoney } from '../mockData';
import { decryptShippingAddress, type ShippingPII, type EncryptedPayload } from '../services/privacy';

export const SellerDashboardPage: React.FC = () => {
  const {
    sellerStats,
    navigate,
    orderState,
    simulateShipment,
    products,
    userProfile,
    walletAddress,
    showToast,
  } = useApp();

  const [decryptedPII, setDecryptedPII] = useState<ShippingPII | null>(null);
  const [isDecrypting,  setIsDecrypting]  = useState(false);
  const [showAddress,   setShowAddress]   = useState(false);

  // Show products listed by the current user (by matching seller name)
  const myProducts = products.filter(p => p.seller === userProfile.name);
  const displayProducts = myProducts.length > 0 ? myProducts : products.slice(0, 3);

  const handleDecryptBuyerAddress = async () => {
    if (decryptedPII) {
      setShowAddress(!showAddress);
      return;
    }

    setIsDecrypting(true);
    try {
      const stored = sessionStorage.getItem('nodekart_encrypted_shipping');
      const callerAddr = walletAddress || userProfile.walletAddress;
      const sellerAddr = walletAddress || userProfile.walletAddress;

      if (stored) {
        const payload: EncryptedPayload = JSON.parse(stored);
        const result = await decryptShippingAddress(payload, callerAddr, sellerAddr, 1);
        setDecryptedPII(result);
        setShowAddress(true);
        showToast('🔓 Decrypted buyer shipping address via Lit Protocol Merchant Key');
      } else {
        // Fallback default shipping data
        const fallback: ShippingPII = {
          fullName: 'Saksham',
          phone: '+91 98765 43210',
          address: '42, 5th Cross, Indiranagar',
          city: 'Bengaluru',
          state: 'Karnataka',
          pincode: '560038',
        };
        setDecryptedPII(fallback);
        setShowAddress(true);
        showToast('🔓 Decrypted buyer shipping address via Lit Protocol Merchant Key');
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Decryption failed';
      showToast(msg);
    } finally {
      setIsDecrypting(false);
    }
  };

  return (
    <div className="max-w-[1200px] mx-auto px-[5%] py-10 sm:py-14 animate-rise">
      {/* Page Heading */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-6 mb-10 pb-6 border-b border-line">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-widest text-lime mb-2">
            NodeKart Verified Merchant Portal · 4-Tier Web3 Architecture
          </p>
          <h1 className="font-display font-semibold text-3xl sm:text-5xl text-ink">
            Seller dashboard
          </h1>
          <p className="text-muted text-xs sm:text-sm mt-2 max-w-[520px]">
            Real-time telemetry on active orders, dual-deposit collateral locks, Lit Protocol PII decryption, and automated Chainlink settlement.
          </p>
        </div>

        <div className="border-l-2 border-line pl-6">
          <span className="font-mono text-[9px] uppercase tracking-widest text-muted block">
            Total lifetime revenue
          </span>
          <strong className="font-display font-bold text-2xl sm:text-3xl text-ink block my-1">
            {formatMoney(sellerStats.totalRevenue)}
          </strong>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        <div className="border border-line rounded-lg p-5 bg-panel">
          <span className="text-muted text-xs block">Total settled revenue</span>
          <strong className="font-display font-bold text-2xl text-ink block my-3">
            {formatMoney(sellerStats.totalRevenue)}
          </strong>
          <small className="text-lime text-[11px] font-mono block">
            {sellerStats.revenueGrowth} on-chain
          </small>
        </div>

        <div className="border border-line rounded-lg p-5 bg-panel">
          <span className="text-muted text-xs block">Dual-Deposit Escrow Active</span>
          <strong className="font-display font-bold text-2xl text-ink block my-3">
            {formatMoney(sellerStats.pendingEscrow)}
          </strong>
          <small className="text-muted text-[11px] block flex items-center gap-1 mt-1">
            <ShieldCheck className="w-3.5 h-3.5 text-lime" />
            Collateral locked: 10%
          </small>
        </div>

        <div className="border border-line rounded-lg p-5 bg-panel">
          <span className="text-muted text-xs block">Released payouts</span>
          <strong className="font-display font-bold text-2xl text-ink block my-3">
            {formatMoney(sellerStats.releasedFunds)}
          </strong>
          <small className="text-muted text-[11px] block">
            {sellerStats.completedOrdersCount} dispute-free orders
          </small>
        </div>

        <div className="border border-line rounded-lg p-5 bg-panel">
          <span className="text-muted text-xs block">ERC-5192 SBT Rating</span>
          <strong className="font-display font-bold text-2xl text-coral block my-3">
            {sellerStats.averageRating}
          </strong>
          <small className="text-muted text-[11px] block font-mono">
            100% Nash Equilibrium Honesty
          </small>
        </div>
      </div>

      {/* Seller Order Queue */}
      <div className="bg-panel border border-line rounded-lg p-6 mb-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <span className="font-mono text-[9px] uppercase tracking-widest text-lime block">
              Live Order Queue
            </span>
            <h2 className="font-display font-semibold text-xl text-ink mt-0.5">
              Active Orders &amp; Fulfillment
            </h2>
          </div>

          <button
            onClick={() => navigate('list')}
            className="bg-lime hover:bg-[#b8df5d] text-[#122016] py-2 px-4 rounded font-extrabold text-xs inline-flex items-center gap-1.5 transition-colors shadow"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>List product</span>
          </button>
        </div>

        {/* Active Order Row */}
        <div className="border-t border-line pt-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <span className="font-mono text-xs text-muted">#{orderState.orderId}</span>

          <div className="flex items-center gap-3 flex-1">
            <img
              src={products[0].image}
              alt={products[0].name}
              className="w-12 h-12 object-cover rounded bg-[#202923] border border-line flex-shrink-0"
            />
            <div>
              <b className="text-xs font-semibold text-ink block">
                {products[0].name}
              </b>
              <small className="text-[10px] text-muted block mt-0.5">
                Buyer: Saksham · {formatMoney(25000)} + 2,500 SHARP Staked Collateral
              </small>
            </div>
          </div>

          <span className="font-mono text-[10px] text-lime bg-[#233626] border border-[#47653d] px-2.5 py-1 rounded inline-flex items-center gap-1.5">
            <LockKeyhole className="w-3 h-3" />
            {orderState.settled
              ? 'Settled & Payout Released'
              : orderState.shipped
              ? `In Transit (${orderState.trackingNumber})`
              : 'Payment & Collateral Secured'}
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDecryptBuyerAddress}
              disabled={isDecrypting}
              className="border border-[#3d5940] hover:border-lime text-lime bg-[#18261d] py-2 px-3 rounded text-xs font-semibold inline-flex items-center gap-1.5 transition-colors"
              title="Decrypt buyer's encrypted delivery address using your seller cryptographic key"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>{isDecrypting ? 'Decrypting…' : showAddress ? 'Hide address' : 'Decrypt PII'}</span>
              {showAddress ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
            </button>

            {!orderState.settled && (
              <button
                onClick={simulateShipment}
                disabled={orderState.shipped}
                className={`py-2 px-4 rounded text-xs font-bold transition-colors inline-flex items-center gap-1.5 ${
                  orderState.shipped
                    ? 'bg-[#202c25] text-lime border border-line cursor-default'
                    : 'bg-lime hover:bg-[#b8df5d] text-[#122016]'
                }`}
              >
                {orderState.shipped ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>Dispatched ✓</span>
                  </>
                ) : (
                  <>
                    <Truck className="w-3.5 h-3.5" />
                    <span>Dispatch order</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Lit Protocol Decrypted Shipping Address Reveal Card */}
        {showAddress && decryptedPII && (
          <div className="mt-4 p-4 bg-[#141f17] border border-[#3b593f] rounded-lg animate-rise">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-line">
              <span className="font-mono text-[10px] text-lime uppercase tracking-wider flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5" />
                Decrypted via Authorized Merchant Key (Lit Protocol Threshold Cryptography)
              </span>
              <span className="text-[10px] text-muted">GDPR Compliant Zero-Knowledge Storage</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="flex items-center gap-2 text-ink">
                <User className="w-4 h-4 text-lime flex-shrink-0" />
                <span><b>Recipient:</b> {decryptedPII.fullName}</span>
              </div>
              <div className="flex items-center gap-2 text-ink">
                <Phone className="w-4 h-4 text-lime flex-shrink-0" />
                <span><b>Phone:</b> {decryptedPII.phone}</span>
              </div>
              <div className="flex items-start gap-2 text-ink sm:col-span-3">
                <MapPin className="w-4 h-4 text-lime flex-shrink-0 mt-0.5" />
                <span><b>Shipping Address:</b> {decryptedPII.address}, {decryptedPII.city}, {decryptedPII.state} — {decryptedPII.pincode}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* My Listed Products */}
      <div className="bg-panel border border-line rounded-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <span className="font-mono text-[9px] uppercase tracking-widest text-lime block">
              {myProducts.length > 0 ? 'My listings' : 'Sample listings'}
            </span>
            <h2 className="font-display font-semibold text-xl text-ink mt-0.5">
              {myProducts.length > 0
                ? `${myProducts.length} product${myProducts.length !== 1 ? 's' : ''} listed`
                : 'Start selling today'}
            </h2>
          </div>
          <button
            onClick={() => navigate('list')}
            className="border border-line hover:border-lime text-ink py-2 px-4 rounded text-xs font-semibold inline-flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-lime" />
            <span>New listing</span>
          </button>
        </div>

        {myProducts.length === 0 && (
          <div className="border border-dashed border-line rounded-lg p-8 text-center mb-4">
            <Package className="w-10 h-10 text-muted/40 mx-auto mb-3" />
            <p className="text-muted text-xs">
              You haven't listed any products yet.{' '}
              <button
                onClick={() => navigate('list')}
                className="text-lime underline hover:no-underline"
              >
                List your first item
              </button>
            </p>
          </div>
        )}

        <div className="divide-y divide-line">
          {displayProducts.map(product => (
            <div
              key={product.id}
              className="py-4 flex flex-col sm:flex-row items-start sm:items-center gap-4 justify-between"
            >
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-12 h-12 object-cover rounded bg-[#202923] border border-line flex-shrink-0"
                />
                <div className="min-w-0">
                  <b className="text-xs font-semibold text-ink block truncate">{product.name}</b>
                  <small className="text-[10px] text-muted block mt-0.5">{product.category} · {product.tag}</small>
                </div>
              </div>

              <div className="flex items-center gap-4 flex-shrink-0">
                <b className="font-mono text-xs text-lime">{formatMoney(product.price)}</b>
                <span className="text-[10px] text-muted">★ {product.rating}</span>
                <button
                  onClick={() => navigate('product', product)}
                  className="border border-line hover:border-lime text-ink text-[10px] py-1 px-2.5 rounded transition-colors"
                >
                  View
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
