import hardhat from "hardhat";
import { ethers } from "ethers";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export async function deployContracts() {
  console.log("══════════════════════════════════════════════════════════");
  console.log("🚀 Starting NodeKart Smart Contract Deployment");
  console.log("══════════════════════════════════════════════════════════");

  const connection = await hardhat.network.connect();
  const provider = new ethers.BrowserProvider(connection.provider);
  const signer = await provider.getSigner(0);
  const deployerAddress = await signer.getAddress();
  const network = await provider.getNetwork();
  const chainId = Number(network.chainId);

  console.log(`📡 Network Chain ID: ${chainId}`);
  console.log(`👤 Deployer Account: ${deployerAddress}`);

  // 1. Deploy SHARPToken
  console.log("\n1️⃣  Deploying SHARPToken (ERC-20)...");
  const sharpArtifact = await hardhat.artifacts.readArtifact("SHARPToken");
  const sharpFactory = new ethers.ContractFactory(sharpArtifact.abi, sharpArtifact.bytecode, signer);
  const sharpToken = await sharpFactory.deploy(deployerAddress);
  await sharpToken.waitForDeployment();
  const sharpAddress = await sharpToken.getAddress();
  console.log(`   ✅ SHARPToken deployed at: ${sharpAddress}`);

  // 2. Deploy NodeKartReputationSBT (ERC-5192)
  console.log("\n2️⃣  Deploying NodeKartReputationSBT (ERC-5192 Soulbound)...");
  const sbtArtifact = await hardhat.artifacts.readArtifact("NodeKartReputationSBT");
  const sbtFactory = new ethers.ContractFactory(sbtArtifact.abi, sbtArtifact.bytecode, signer);
  const reputationSBT = await sbtFactory.deploy(deployerAddress);
  await reputationSBT.waitForDeployment();
  const sbtAddress = await reputationSBT.getAddress();
  console.log(`   ✅ NodeKartReputationSBT deployed at: ${sbtAddress}`);

  // 3. Deploy MockChainlinkOracle
  console.log("\n3️⃣  Deploying MockChainlinkOracle (Logistics DON)...");
  const oracleArtifact = await hardhat.artifacts.readArtifact("MockChainlinkOracle");
  const oracleFactory = new ethers.ContractFactory(oracleArtifact.abi, oracleArtifact.bytecode, signer);
  const oracle = await oracleFactory.deploy(deployerAddress);
  await oracle.waitForDeployment();
  const oracleAddress = await oracle.getAddress();
  console.log(`   ✅ MockChainlinkOracle deployed at: ${oracleAddress}`);

  // 4. Deploy NodeKartEscrow
  console.log("\n4️⃣  Deploying NodeKartEscrow (Dual-Deposit Nash Equilibrium)...");
  const escrowArtifact = await hardhat.artifacts.readArtifact("NodeKartEscrow");
  const escrowFactory = new ethers.ContractFactory(escrowArtifact.abi, escrowArtifact.bytecode, signer);
  const escrow = await escrowFactory.deploy(sharpAddress, sbtAddress, oracleAddress, deployerAddress);
  await escrow.waitForDeployment();
  const escrowAddress = await escrow.getAddress();
  console.log(`   ✅ NodeKartEscrow deployed at: ${escrowAddress}`);

  // 5. Deploy NodeKartPaymaster (ERC-4337)
  console.log("\n5️⃣  Deploying NodeKartPaymaster (ERC-4337 Gasless)...");
  const paymasterArtifact = await hardhat.artifacts.readArtifact("NodeKartPaymaster");
  const paymasterFactory = new ethers.ContractFactory(paymasterArtifact.abi, paymasterArtifact.bytecode, signer);
  const paymaster = await paymasterFactory.deploy(deployerAddress, escrowAddress, deployerAddress);
  await paymaster.waitForDeployment();
  const paymasterAddress = await paymaster.getAddress();
  console.log(`   ✅ NodeKartPaymaster deployed at: ${paymasterAddress}`);

  // 6. Grant Permissions & Link Roles
  console.log("\n⚙️  Configuring contract roles & permissions...");
  const tx1 = await sharpToken.setMinter(escrowAddress, true);
  await tx1.wait();
  console.log("   🔑 Granted SHARP Cashback Minter role to NodeKartEscrow");

  const tx2 = await reputationSBT.setAuthorizedUpdater(escrowAddress, true);
  await tx2.wait();
  console.log("   🔑 Granted SBT Reputation Updater role to NodeKartEscrow");

  // 7. Export Deployment Artifacts to Frontend
  console.log("\n📦 Exporting addresses and ABIs to src/contracts/deployed.json...");
  const deploymentData = {
    chainId,
    deployer: deployerAddress,
    deployedAt: new Date().toISOString(),
    contracts: {
      SHARPToken: {
        address: sharpAddress,
        abi: sharpArtifact.abi,
      },
      NodeKartReputationSBT: {
        address: sbtAddress,
        abi: sbtArtifact.abi,
      },
      MockChainlinkOracle: {
        address: oracleAddress,
        abi: oracleArtifact.abi,
      },
      NodeKartEscrow: {
        address: escrowAddress,
        abi: escrowArtifact.abi,
      },
      NodeKartPaymaster: {
        address: paymasterAddress,
        abi: paymasterArtifact.abi,
      },
    },
  };

  const contractsDir = path.join(__dirname, "..", "src", "contracts");
  if (!fs.existsSync(contractsDir)) {
    fs.mkdirSync(contractsDir, { recursive: true });
  }

  const outputPath = path.join(contractsDir, "deployed.json");
  fs.writeFileSync(outputPath, JSON.stringify(deploymentData, null, 2));

  // Also generate typed constants helper
  const tsOutput = `// Auto-generated by scripts/deploy.js at ${new Date().toISOString()}
import deployment from './deployed.json';

export const DEPLOYED_CHAIN_ID = ${chainId};
export const CONTRACTS = {
  SHARPToken: {
    address: "${sharpAddress}",
    abi: deployment.contracts.SHARPToken.abi,
  },
  NodeKartReputationSBT: {
    address: "${sbtAddress}",
    abi: deployment.contracts.NodeKartReputationSBT.abi,
  },
  MockChainlinkOracle: {
    address: "${oracleAddress}",
    abi: deployment.contracts.MockChainlinkOracle.abi,
  },
  NodeKartEscrow: {
    address: "${escrowAddress}",
    abi: deployment.contracts.NodeKartEscrow.abi,
  },
  NodeKartPaymaster: {
    address: "${paymasterAddress}",
    abi: deployment.contracts.NodeKartPaymaster.abi,
  },
} as const;
`;

  fs.writeFileSync(path.join(contractsDir, "deployed.ts"), tsOutput);
  console.log("   ✅ Saved to src/contracts/deployed.json and src/contracts/deployed.ts");
  console.log("══════════════════════════════════════════════════════════\n");

  return {
    deployerAddress,
    sharpToken,
    reputationSBT,
    oracle,
    escrow,
    paymaster,
    addresses: {
      sharpAddress,
      sbtAddress,
      oracleAddress,
      escrowAddress,
      paymasterAddress,
    },
  };
}

deployContracts().catch(console.error);
