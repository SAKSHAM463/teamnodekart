﻿import React, { useState, useMemo } from 'react';
import { Search, Plus, SlidersHorizontal, ChevronDown, SearchX } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CATEGORIES } from '../mockData';
import { ProductCard } from '../components/ProductCard';

export const MarketplacePage: React.FC = () => {
  const {
    products,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    navigate,
  } = useApp();

  const [sortBy, setSortBy] = useState<'recommended' | 'price-low' | 'price-high' | 'rating'>('recommended');
  const [isSortOpen, setIsSortOpen] = useState(false);

  const filteredProducts = useMemo(() => {
    let list = products.filter(p => {
      const matchCategory = selectedCategory === 'All' || p.category === selectedCategory;
      const matchSearch =
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.seller.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCategory && matchSearch;
    });

    if (sortBy === 'price-low') {
      list = [...list].sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-high') {
      list = [...list].sort((a, b) => b.price - a.price);
    } else if (sortBy === 'rating') {
      list = [...list].sort((a, b) => parseFloat(b.rating) - parseFloat(a.rating));
    }

    return list;
  }, [products, searchQuery, selectedCategory, sortBy]);

  const uniqueSellersCount = useMemo(() => {
    return new Set(products.map(p => p.seller)).size;
  }, [products]);

  const handleReset = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSortBy('recommended');
  };

  const sortLabels: Record<string, string> = {
    recommended: 'Recommended',
    'price-low': 'Price: Low to High',
    'price-high': 'Price: High to Low',
    rating: 'Highest Rated',
  };

  return (
    <div className="max-w-[1200px] mx-auto px-[5%] py-10 sm:py-14 animate-rise">
      {/* Page Heading */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-6 mb-10 pb-4">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-widest text-lime mb-2">
            Community marketplace
          </p>
          <h1 className="font-display font-semibold text-4xl sm:text-5xl lg:text-6xl tracking-tight text-ink">
            Find something <em className="font-serif font-normal text-lime">worth keeping.</em>
          </h1>
          <p className="text-muted text-xs sm:text-sm mt-3 max-w-[500px]">
            Real products from verified people, settled with protected SHARP payments.
          </p>
        </div>

        <button
          onClick={() => navigate('list')}
          className="border border-line hover:border-lime bg-[#141b17] text-ink text-xs font-semibold py-2.5 px-4 rounded-[5px] inline-flex items-center gap-2 transition-colors whitespace-nowrap"
        >
          <Plus className="w-3.5 h-3.5 text-lime" />
          <span>Sell an item</span>
        </button>
      </div>

      {/* Market Tools */}
      <div className="mb-8">
        {/* Search Box */}
        <div className="flex items-center gap-3 border border-line rounded-md px-4 py-1.5 max-w-[520px] bg-[#141b17] focus-within:border-lime transition-colors">
          <Search className="w-4 h-4 text-muted flex-shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search products, brands, or verified sellers..."
            className="bg-transparent border-0 outline-none text-ink text-xs sm:text-sm w-full py-2 placeholder:text-muted/60"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="text-muted hover:text-ink text-xs px-1"
            >
              ×
            </button>
          )}
        </div>

        {/* Categories & Sort */}
        <div className="border-b border-line flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mt-6 pb-2">
          {/* Filter Tabs */}
          <div className="flex gap-6 overflow-x-auto w-full sm:w-auto pb-2 sm:pb-0 scrollbar-none">
            {CATEGORIES.map(category => {
              const isActive = selectedCategory === category;
              return (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`text-xs font-medium pb-2 whitespace-nowrap transition-colors relative ${
                    isActive ? 'text-lime font-bold' : 'text-muted hover:text-ink'
                  }`}
                >
                  {category}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-lime" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Sort Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsSortOpen(!isSortOpen)}
              className="text-muted hover:text-ink text-xs font-medium inline-flex items-center gap-2 py-1 px-2.5 rounded border border-line bg-[#141b17]"
            >
              <span>{sortLabels[sortBy]}</span>
              <ChevronDown className="w-3.5 h-3.5 text-muted" />
            </button>

            {isSortOpen && (
              <div className="absolute right-0 top-full mt-1.5 w-44 bg-panel border border-line rounded shadow-xl z-20 py-1 text-xs">
                {(['recommended', 'price-low', 'price-high', 'rating'] as const).map(option => (
                  <button
                    key={option}
                    onClick={() => {
                      setSortBy(option);
                      setIsSortOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 hover:bg-[#202b25] transition-colors ${
                      sortBy === option ? 'text-lime font-bold' : 'text-muted'
                    }`}
                  >
                    {sortLabels[option]}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Results Header */}
      <div className="flex justify-between items-center text-muted font-mono text-[9px] uppercase tracking-wider mb-6">
        <span>
          {filteredProducts.length} products from {uniqueSellersCount} verified sellers
        </span>
        <span className="text-lime flex items-center gap-1">
          <SlidersHorizontal className="w-3 h-3" />
          Curated for you
        </span>
      </div>

      {/* Product Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="border border-dashed border-line rounded-lg p-16 text-center text-muted my-8">
          <SearchX className="w-10 h-10 text-muted/60 mx-auto mb-3" />
          <h3 className="font-display font-semibold text-lg text-ink mb-1">
            No products found
          </h3>
          <p className="text-xs text-muted max-w-sm mx-auto mb-5">
            We couldn't find any products matching "{searchQuery}" in {selectedCategory}. Try another category or clear your search query.
          </p>
          <button
            onClick={handleReset}
            className="border border-line hover:border-lime text-ink text-xs font-semibold py-2 px-4 rounded transition-colors"
          >
            Clear filters
          </button>
        </div>
      )}
    </div>
  );
};
