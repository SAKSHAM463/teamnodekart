// ─────────────────────────────────────────────────────────────
//  src/pages/OrdersPage.tsx
//  Verifiable dual-deposit escrow tracking with Chainlink DON verification.
// ─────────────────────────────────────────────────────────────

import React, { useState } from 'react';
import {
  LockKeyhole,
  CheckCircle2,
  ScanEye,
  Wallet,
  Truck,
  Sparkles,
  CircleDashed,
  Check,
  ArrowUpRight,
  ShieldCheck,
  Radio,
  KeyRound,
  Award,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { INITIAL_ORDER, formatMoney } from '../mockData';
import { computeReputationTier } from '../lib/sbt';

export const OrdersPage: React.FC = () => {
  const {
    orderState,
    simulateShipment,
    simulateDelivery,
    confirmSettlement,
    openModal,
    products,
    showToast,
    reputation,
  } = useApp();

  const [isOracleSyncing, setIsOracleSyncing] = useState(false);
  const [isDisputeOpen, setIsDisputeOpen] = useState(false);

  const product = products.find(p => p.id === INITIAL_ORDER.productId) || products[0];
  const { shipped, delivered, settled, trackingNumber, carrier, sellerCollateral, buyerCollateral } = orderState;
  const repTier = computeReputationTier(reputation);

  const handleOracleDeliveryTrigger = async () => {
    setIsOracleSyncing(true);
    try {
      await simulateDelivery();
    } finally {
      setIsOracleSyncing(false);
    }
  };

  const handleRaiseDispute = () => {
    setIsDisputeOpen(true);
    showToast('Dispute logged on-chain. Automated release halted.');
  };

  const timelineSteps = [
    {
      title: 'Payment & Dual-Deposit (ERC-4337 Sponsored)',
      desc: `25,000 SHARP + ${buyerCollateral.toLocaleString()} SHARP Buyer Deposit locked · 0 Gas Fee`,
      isDone: true,
      icon: <Wallet className="w-4 h-4" />,
    },
    {
      title: 'Seller Collateral Staked',
      desc: `${sellerCollateral.toLocaleString()} SHARP (10%) locked by merchant · Nash Equilibrium active`,
      isDone: true,
      icon: <LockKeyhole className="w-4 h-4" />,
    },
    {
      title: 'Lit Protocol PII Encryption & Dispatch',
      desc: shipped
        ? `Dispatched via ${carrier} · Tracking: ${trackingNumber} · Buyer PII encrypted`
        : 'Merchant preparing shipment with encrypted delivery label',
      isDone: shipped,
      icon: <Truck className="w-4 h-4" />,
    },
    {
      title: 'Chainlink DON Consensus Delivery Check',
      desc: delivered
        ? 'Physical delivery verified by 4-of-5 Chainlink DON Oracle nodes consensus'
        : 'Awaiting courier transit updates via Chainlink Functions bridge',
      isDone: delivered,
      icon: delivered ? (
        <CheckCircle2 className="w-4 h-4" />
      ) : (
        <Radio className="w-4 h-4" />
      ),
    },
    {
      title: 'Settlement & Mutual Deposit Release',
      desc: settled
        ? 'Payment & collateral released · Deposits refunded to both parties'
        : '48h timelock active (or instant manual sign-off)',
      isDone: settled,
      icon: settled ? (
        <CheckCircle2 className="w-4 h-4" />
      ) : (
        <CircleDashed className="w-4 h-4" />
      ),
    },
    {
      title: '5% Cashback & ERC-5192 SBT Minting',
      desc: settled
        ? `+1,250 SHARP cashback minted · Soulbound Token #${reputation?.tokenId || 1042} upgraded`
        : 'Pending settlement',
      isDone: settled,
      icon: settled ? (
        <Sparkles className="w-4 h-4" />
      ) : (
        <CircleDashed className="w-4 h-4" />
      ),
    },
  ];

  return (
    <div className="max-w-[1200px] mx-auto px-[5%] py-10 sm:py-14 animate-rise">
      {/* Page Heading */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 mb-8 pb-4 border-b border-line">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-widest text-lime mb-1">
            Protected Escrow Order · 4-Tier Web3 Architecture
          </p>
          <h1 className="font-display font-semibold text-3xl sm:text-5xl text-ink">
            Order <em className="font-serif font-normal text-lime">#{INITIAL_ORDER.orderId}</em>
          </h1>
          <p className="text-muted text-xs sm:text-sm mt-2 max-w-[540px]">
            {settled
              ? 'This transaction has settled via Sub-game Perfect Nash Equilibrium. Funds and deposits released.'
              : 'Secured by Lit Protocol PII guard, Dual-Deposit Escrow & Chainlink DON verification.'}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="font-mono text-[10px] text-lime bg-[#1b2820] border border-[#3d5940] px-2.5 py-1.5 rounded inline-flex items-center gap-1.5">
            <KeyRound className="w-3 h-3" />
            Lit Privacy Guard Active
          </span>
          <span
            className={`font-mono text-xs px-3 py-1.5 rounded border inline-flex items-center gap-2 ${
              settled
                ? 'bg-[#203021] text-lime border-[#47653d]'
                : 'bg-[#322a1c] text-[#efd5a2] border-[#735d37]'
            }`}
          >
            {settled ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-lime" />
                <span>Settled &amp; Verified</span>
              </>
            ) : (
              <>
                <LockKeyhole className="w-3.5 h-3.5" />
                <span>In Escrow</span>
              </>
            )}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1.3fr_0.8fr] gap-10 lg:gap-14 items-start">
        {/* Main Section */}
        <div>
          {/* Order Product Card */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 bg-panel border border-line p-4 rounded-lg mb-8">
            <img
              src={product.image}
              alt={product.name}
              className="w-16 h-16 object-cover rounded bg-[#202923] border border-line flex-shrink-0"
            />
            <div className="flex-1 min-w-0">
              <span className="text-[10px] text-muted block">
                Purchased from {product.seller}
              </span>
              <h2 className="font-display font-semibold text-base text-ink truncate mt-0.5">
                {product.name}
              </h2>
              <b className="font-mono text-xs text-lime block mt-1">
                {formatMoney(INITIAL_ORDER.amount)}
              </b>
            </div>
            <button
              onClick={() => openModal('proof')}
              className="border border-line hover:border-lime text-ink text-xs font-semibold py-2 px-3.5 rounded inline-flex items-center gap-1.5 transition-colors"
            >
              <ScanEye className="w-3.5 h-3.5 text-lime" />
              <span>Proof</span>
            </button>
          </div>

          {/* Timeline */}
          <div className="relative border-l border-[#3b4c41] ml-4 pl-6 space-y-7 my-6">
            {timelineSteps.map((step, idx) => (
              <div key={idx} className="relative flex items-start justify-between">
                <div
                  className={`absolute -left-[37px] w-6 h-6 rounded-full grid place-items-center border transition-colors ${
                    step.isDone
                      ? 'bg-lime border-lime text-[#18231a]'
                      : 'bg-bg border-[#405148] text-muted'
                  }`}
                >
                  {step.icon}
                </div>

                <div>
                  <b
                    className={`text-xs font-semibold block ${
                      step.isDone ? 'text-ink' : 'text-muted'
                    }`}
                  >
                    {step.title}
                  </b>
                  <p className="text-muted text-[11px] mt-0.5">
                    {step.desc}
                  </p>
                </div>

                {step.isDone && (
                  <span className="text-lime text-xs font-mono">
                    <Check className="w-4 h-4" />
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Sidebar Controls */}
        <aside className="space-y-4">
          {/* Dual-Deposit Breakdown Card */}
          <div className="bg-[#1b2820] border border-[#3d5940] rounded-lg p-6 space-y-4">
            <span className="font-mono text-[9px] uppercase tracking-widest text-lime block">
              Dual-Deposit Escrow Pool
            </span>
            <b className="font-display font-bold text-3xl text-ink block">
              {(INITIAL_ORDER.amount + sellerCollateral + buyerCollateral).toLocaleString()} <small className="text-xs font-mono text-muted">SHARP</small>
            </b>

            <div className="space-y-2 text-xs border-t border-[#405148] pt-3 text-muted">
              <div className="flex justify-between">
                <span>Item Purchase Amount</span>
                <b className="font-mono text-ink">{INITIAL_ORDER.amount.toLocaleString()} SHARP</b>
              </div>
              <div className="flex justify-between">
                <span>Seller Collateral (10%)</span>
                <b className="font-mono text-lime">+{sellerCollateral.toLocaleString()} SHARP</b>
              </div>
              <div className="flex justify-between">
                <span>Buyer Collateral (5%)</span>
                <b className="font-mono text-lime">+{buyerCollateral.toLocaleString()} SHARP</b>
              </div>
            </div>

            <div className="border-t border-[#405148] pt-3 flex items-center gap-2 text-lime text-xs">
              <ShieldCheck className="w-4 h-4 flex-shrink-0" />
              <span>Sub-game Perfect Nash Equilibrium Protected</span>
            </div>
          </div>

          {/* Interactive Actions */}
          <div className="space-y-3 pt-2">
            {!shipped && (
              <button
                onClick={simulateShipment}
                className="w-full bg-[#202c25] hover:bg-[#283830] border border-line hover:border-lime text-ink py-3 px-4 rounded text-xs font-semibold transition-colors"
              >
                1. Simulate Seller Dispatch ({trackingNumber})
              </button>
            )}

            {shipped && !delivered && (
              <button
                onClick={handleOracleDeliveryTrigger}
                disabled={isOracleSyncing}
                className="w-full bg-[#1e2d23] hover:bg-[#263a2d] border border-lime text-lime py-3 px-4 rounded text-xs font-semibold transition-colors inline-flex items-center justify-center gap-2"
              >
                <Radio className="w-4 h-4 animate-pulse" />
                <span>{isOracleSyncing ? 'Chainlink DON Verifying Consensus (4/5 Nodes)…' : '2. Simulate Chainlink DON Delivery Check'}</span>
              </button>
            )}

            {delivered && !settled && (
              <button
                onClick={() => confirmSettlement()}
                className="w-full bg-lime hover:bg-[#b8df5d] text-[#122016] py-3.5 px-4 rounded font-extrabold text-xs inline-flex items-center justify-center gap-2 transition-colors shadow-lg animate-pulse"
              >
                <Check className="w-4 h-4" />
                <span>3. Confirm Receipt &amp; Release Escrow</span>
              </button>
            )}

            {!settled && (
              <button
                onClick={handleRaiseDispute}
                className="w-full bg-transparent hover:bg-red-500/10 border border-line hover:border-red-500/40 text-muted hover:text-red-400 py-2.5 px-4 rounded text-[11px] font-medium transition-colors"
              >
                {isDisputeOpen ? 'Dispute Recorded' : 'Raise Escrow Dispute'}
              </button>
            )}

            <button
              onClick={() => openModal('proof')}
              className="w-full border border-line hover:border-lime text-ink py-3 px-4 rounded text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors"
            >
              <ScanEye className="w-4 h-4 text-lime" />
              <span>View On-Chain Settlement Proof</span>
            </button>
          </div>
        </aside>
      </div>

      {/* Settled Celebration Banner */}
      {settled && (
        <section className="mt-12 bg-[#233626] border border-[#507544] p-6 sm:p-8 rounded-lg flex flex-col sm:flex-row items-start sm:items-center gap-5 animate-rise">
          <div className="w-10 h-10 rounded-full bg-lime text-[#172219] grid place-items-center flex-shrink-0">
            <Award className="w-6 h-6" />
          </div>

          <div className="flex-1">
            <p className="font-mono text-[9px] uppercase tracking-widest text-lime">
              Settlement complete · {repTier.badge}
            </p>
            <h2 className="font-display font-semibold text-2xl text-ink my-1">
              Escrow &amp; Deposits Released <em className="font-serif font-normal text-lime">successfully.</em>
            </h2>
            <p className="text-[#b3c3ac] text-xs leading-relaxed">
              Seller received <b className="text-ink">25,000 SHARP + 2,500 deposit refund</b>. You received{' '}
              <b className="text-ink">1,250 deposit refund</b> +{' '}
              <b className="text-lime font-bold">+1,250 SHARP (5% cashback)</b> +{' '}
              <b className="text-lime font-bold">ERC-5192 Soulbound Token (#{reputation?.tokenId || 1042}) upgrade</b>.
            </p>
          </div>

          <button
            onClick={() => openModal('proof')}
            className="bg-[#f0f4e8] hover:bg-white text-[#172219] font-bold text-xs py-2.5 px-4 rounded inline-flex items-center gap-1.5 transition-colors flex-shrink-0"
          >
            <span>View proof</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </section>
      )}
    </div>
  );
};
