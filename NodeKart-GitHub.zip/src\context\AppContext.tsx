// ─────────────────────────────────────────────────────────────
//  src/context/AppContext.tsx
//  Central state coordinator for NodeKart Web3 dApp.
// ─────────────────────────────────────────────────────────────

import React, { createContext, useContext, useState, ReactNode } from 'react';
import {
  Product,
  INITIAL_PRODUCTS,
  INITIAL_SELLER_STATS,
  UserProfile,
  WalletTransaction,
  SellerStats,
} from '../mockData';
import { useMetaMask } from '../hooks/useMetaMask';
import { truncateAddress } from '../lib/wallet';
import { getExplorerUrl } from '../lib/escrow';
import type { EscrowState, ReputationData, TxResult } from '../contracts/escrow.types';

import { DBService } from '../services/dbService';

// ─── Page & Cart Types ────────────────────────────────────────

export type PageType =
  | 'home'
  | 'market'
  | 'product'
  | 'cart'
  | 'checkout'
  | 'orders'
  | 'wallet'
  | 'rewards'
  | 'referrals'
  | 'seller'
  | 'profile'
  | 'list';

export interface CartItem {
  product: Product;
  quantity: number;
}

// ─── Order State ──────────────────────────────────────────────

export interface OrderState {
  escrowId:     number;
  shipped:      boolean;
  delivered:    boolean;
  settled:      boolean;
  orderId:      string;
  trackingNumber: string;
  carrier:      string;
  sellerCollateral: number;
  buyerCollateral:  number;
  escrowTxHash: string | null;
  escrowPhase:  EscrowState;
}

// ─── Context Interface ────────────────────────────────────────

interface AppContextType {
  // Navigation
  page:              PageType;
  navigate:          (newPage: PageType, product?: Product) => void;

  // Products & Cart
  selectedProduct:   Product;
  products:          Product[];
  cart:              CartItem[];
  searchQuery:       string;
  selectedCategory:  string;
  setSearchQuery:    (query: string) => void;
  setSelectedCategory: (category: string) => void;
  addToCart:         (product: Product, quantity?: number) => void;
  updateCartQuantity:(productId: string, delta: number) => void;
  removeFromCart:    (productId: string) => void;
  clearCart:         () => void;
  publishProduct:    (newProduct: Omit<Product, 'id'>) => void;

  // Orders & Escrow
  orderState:        OrderState;
  simulateShipment:  () => void;
  simulateDelivery:  () => Promise<void>;
  confirmSettlement: (txResult?: TxResult) => Promise<void>;
  setEscrowTxHash:   (hash: string) => void;

  // Web3 Wallet & Contracts
  walletAddress:     string | null;
  isWalletConnected: boolean;
  isWalletLoading:   boolean;
  walletError:       string | null;
  sharpBalance:      string;
  walletBalance:     number;
  reputation:        ReputationData | null;
  transactions:      WalletTransaction[];
  connectWallet:     () => Promise<void>;
  claimTokens:       (amount?: string) => Promise<void>;
  createEscrow:      (seller: string, price: string, sellerCol: string, buyerCol: string, prodId: string) => Promise<{ escrowId: number; txResult: TxResult }>;

  // Seller & Profile
  sellerStats:       SellerStats;
  userProfile:       UserProfile;
  updateUserProfile: (updates: Partial<UserProfile>) => void;

  // UI Helpers
  toastMessage:      string | null;
  activeModal:       'proof' | 'payment' | 'mobileMenu' | null;
  showToast:         (msg: string) => void;
  openModal:         (modal: 'proof' | 'payment' | 'mobileMenu') => void;
  closeModal:        () => void;

  // Address & Explorer Utilities
  truncateAddress:   (address: string) => string;
  getExplorerUrl:    (txHash: string) => string;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [page,             setPage]             = useState<PageType>('home');
  const [products,         setProducts]         = useState<Product[]>(() => DBService.getProducts());
  const [selectedProduct,  setSelectedProduct]  = useState<Product>(() => DBService.getProducts()[0] || INITIAL_PRODUCTS[0]);
  const [cart,             setCart]             = useState<CartItem[]>(() => [
    { product: DBService.getProducts()[0] || INITIAL_PRODUCTS[0], quantity: 1 },
  ]);
  const [searchQuery,      setSearchQuery]      = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [orderState,       setOrderState]       = useState<OrderState>({
    escrowId:     1,
    shipped:      false,
    delivered:    false,
    settled:      false,
    orderId:      'NK48291',
    trackingNumber: 'NK9271IN',
    carrier:      'BlueDart Logistics',
    sellerCollateral: 2500, // 10%
    buyerCollateral:  1250, // 5%
    escrowTxHash: '0x7a3f9d82e1c94b2a8d4f019b8417c8e92d71fa9109b837e24817a8e291fd01bc',
    escrowPhase:  'Funded',
  });
  const [transactions,   setTransactions]   = useState<WalletTransaction[]>(() => DBService.getTransactions());
  const [sellerStats]                        = useState<SellerStats>(INITIAL_SELLER_STATS);
  const [userProfile,    setUserProfile]    = useState<UserProfile>(() => DBService.getUserProfile());
  const [toastMessage,   setToastMessage]   = useState<string | null>(null);
  const [activeModal,    setActiveModal]    = useState<'proof' | 'payment' | 'mobileMenu' | null>(null);

  // MetaMask & Web3 Contracts Hook
  const {
    walletAddress,
    isConnected:    isWalletConnected,
    isLoading:      isWalletLoading,
    error:          walletError,
    sharpBalance,
    reputation,
    connectWallet:  mmConnect,
    claimTestnetTokens,
    createEscrowDeposit,
    confirmDelivery: mmConfirmDelivery,
    syncOracle:      mmSyncOracle,
    refreshBalances,
  } = useMetaMask();

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(prev => (prev === msg ? null : prev));
    }, 2800);
  };

  const navigate = (newPage: PageType, product?: Product) => {
    if (product) setSelectedProduct(product);
    setPage(newPage);
    if (activeModal === 'mobileMenu') setActiveModal(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const addToCart = (product: Product, quantity = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    showToast(`Added ${product.name} to basket`);
  };

  const updateCartQuantity = (productId: string, delta: number) => {
    setCart(prev =>
      prev
        .map(item => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
    showToast('Item removed from basket');
  };

  const clearCart = () => setCart([]);

  const simulateShipment = () => {
    setOrderState(prev => ({
      ...prev,
      shipped: true,
      escrowPhase: 'Dispatched',
    }));
    showToast('Shipment verified · On-chain tracking active: NK9271IN');
  };

  const simulateDelivery = async () => {
    try {
      await mmSyncOracle(orderState.escrowId);
    } catch {}
    setOrderState(prev => ({
      ...prev,
      shipped: true,
      delivered: true,
      escrowPhase: 'Delivered',
    }));
    showToast('Chainlink DON Oracle confirmed delivery · 48h timelock initiated');
  };

  const confirmSettlement = async (txResult?: TxResult) => {
    try {
      if (isWalletConnected) {
        await mmConfirmDelivery(orderState.escrowId);
      }
    } catch (err) {
      console.warn('On-chain confirm fallback:', err);
    }

    const cashback = 1250;
    setOrderState(prev => ({
      ...prev,
      settled:      true,
      escrowPhase:  'Settled',
      escrowTxHash: txResult?.txHash ?? prev.escrowTxHash,
    }));

    setTransactions(prev => [
      {
        id:        `tx-${Date.now()}`,
        title:     '5% SHARP Cashback Minted · #NK48291',
        amount:    `+${cashback.toLocaleString()} SHARP`,
        status:    'Confirmed',
        type:      'credit',
        icon:      'sparkles',
        timestamp: 'Just now',
      },
      ...prev,
    ]);
    showToast('Escrow released · 1,250 SHARP cashback minted · SBT reputation upgraded ✓');
    await refreshBalances();
  };

  const setEscrowTxHash = (hash: string) => {
    setOrderState(prev => ({
      ...prev,
      escrowTxHash: hash,
      escrowPhase:  'Funded',
    }));
  };

  const updateUserProfile = (updates: Partial<UserProfile>) => {
    setUserProfile(prev => {
      const updated = { ...prev, ...updates };
      if (updates.walletAddress) {
        updated.walletAddressShort = truncateAddress(updates.walletAddress);
      }
      DBService.saveUserProfile(updated);
      return updated;
    });
    showToast('Profile credentials saved to database ✓');
  };

  const connectWallet = async (): Promise<void> => {
    try {
      const address = await mmConnect();
      updateUserProfile({ walletAddress: address });
      showToast(`Wallet connected · ${truncateAddress(address)}`);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Could not connect wallet';
      showToast(message);
    }
  };

  const claimTokens = async (amount = '10000'): Promise<void> => {
    try {
      await claimTestnetTokens(amount);
      showToast(`Received ${Number(amount).toLocaleString()} SHARP from faucet!`);
      const newTx: WalletTransaction = {
        id: `tx-${Date.now()}`,
        title: 'SHARP Testnet Faucet',
        amount: `+${Number(amount).toLocaleString()} SHARP`,
        status: 'Confirmed',
        type: 'credit',
        icon: 'plus',
        timestamp: 'Just now',
      };
      setTransactions(prev => {
        const next = [newTx, ...prev];
        DBService.saveTransactions(next);
        return next;
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Faucet request failed';
      showToast(message);
    }
  };

  const createEscrow = async (
    seller: string,
    price: string,
    sellerCol: string,
    buyerCol: string,
    prodId: string
  ) => {
    const res = await createEscrowDeposit(seller, price, sellerCol, buyerCol, prodId);
    setOrderState(prev => ({
      ...prev,
      escrowId: res.escrowId,
      escrowTxHash: res.txResult.txHash,
      escrowPhase: 'Funded',
      shipped: false,
      delivered: false,
      settled: false,
    }));
    return res;
  };

  const publishProduct = (newProductData: Omit<Product, 'id'>) => {
    const id = `item-${Date.now()}`;
    const newProduct: Product = { ...newProductData, id, reviewsCount: 0 };
    const updated = DBService.saveProduct(newProduct);
    setProducts(updated);
    setSelectedProduct(newProduct);
    showToast('Product listed & saved to persistent database ✓');
    navigate('home');
  };

  const openModal  = (modal: 'proof' | 'payment' | 'mobileMenu') => setActiveModal(modal);
  const closeModal = () => setActiveModal(null);

  const walletBalance = Number(sharpBalance) || 0;

  return (
    <AppContext.Provider
      value={{
        page,
        navigate,
        selectedProduct,
        products,
        cart,
        searchQuery,
        selectedCategory,
        setSearchQuery,
        setSelectedCategory,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        publishProduct,
        orderState,
        simulateShipment,
        simulateDelivery,
        confirmSettlement,
        setEscrowTxHash,
        walletAddress,
        isWalletConnected,
        isWalletLoading,
        walletError,
        sharpBalance,
        walletBalance,
        reputation,
        transactions,
        connectWallet,
        claimTokens,
        createEscrow,
        sellerStats,
        userProfile,
        updateUserProfile,
        toastMessage,
        activeModal,
        showToast,
        openModal,
        closeModal,
        truncateAddress,
        getExplorerUrl,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
