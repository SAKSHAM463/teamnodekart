import hardhat from "hardhat";
import { ethers } from "ethers";

async function main() {
  const provider = new ethers.BrowserProvider(hardhat.network.provider);
  const signer = await provider.getSigner(0);
  const address = await signer.getAddress();
  console.log("Account 0 address:", address);
  const balance = await provider.getBalance(address);
  console.log("Account 0 balance:", ethers.formatEther(balance), "ETH");
}

main().catch(console.error);
