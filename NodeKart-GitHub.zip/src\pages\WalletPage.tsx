// ─────────────────────────────────────────────────────────────
//  src/pages/WalletPage.tsx
//  SHARP Token Wallet, Testnet Faucet & Transaction History.
// ─────────────────────────────────────────────────────────────

import React, { useState } from 'react';
import {
  ArrowUpRight,
  ArrowDownLeft,
  ShoppingBag,
  Sparkles,
  Users,
  CheckCircle2,
  Coins,
  X,
  Copy,
  Send,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatINR } from '../mockData';

type WalletDialog = 'send' | 'receive' | null;

export const WalletPage: React.FC = () => {
  const {
    sharpBalance,
    transactions,
    showToast,
    claimTokens,
    isWalletLoading,
    walletAddress,
    truncateAddress,
  } = useApp();

  const [isMinting,   setIsMinting]   = useState(false);
  const [dialog,      setDialog]      = useState<WalletDialog>(null);
  const [sendAddr,    setSendAddr]    = useState('');
  const [sendAmount,  setSendAmount]  = useState('');

  const numBalance = Number(sharpBalance || '0');
  const displayAddr = walletAddress ? truncateAddress(walletAddress) : '0x7a4F...9c21';

  const handleClaimFaucet = async () => {
    setIsMinting(true);
    try {
      await claimTokens('10000');
    } finally {
      setIsMinting(false);
    }
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sendAddr.trim() || !sendAmount) {
      showToast('Please enter a valid address and amount');
      return;
    }
    showToast(`Send initiated: ${Number(sendAmount).toLocaleString()} SHARP → ${truncateAddress(sendAddr)}`);
    setSendAddr('');
    setSendAmount('');
    setDialog(null);
  };

  const handleCopyAddress = () => {
    navigator.clipboard?.writeText(walletAddress || '0x7a4F298b42Ce9c1b72a91Eb409F3d21A56e09c21');
    showToast('Wallet address copied!');
  };

  const getTransactionIcon = (icon: string) => {
    switch (icon) {
      case 'shopping-bag':   return <ShoppingBag className="w-3.5 h-3.5 text-lime" />;
      case 'sparkles':       return <Sparkles   className="w-3.5 h-3.5 text-lime" />;
      case 'users':          return <Users      className="w-3.5 h-3.5 text-lime" />;
      case 'plus':           return <Coins      className="w-3.5 h-3.5 text-lime" />;
      default:               return <CheckCircle2 className="w-3.5 h-3.5 text-lime" />;
    }
  };

  return (
    <div className="animate-rise">
      {/* Wallet Hero */}
      <section className="py-12 sm:py-16 px-[6%] sm:px-[8%] bg-gradient-to-r from-[#17231b] to-[#101512] border-b border-line flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-widest text-lime mb-2">
            NodeKart Web3 Wallet
          </p>
          <h1 className="font-display font-semibold text-4xl sm:text-6xl text-ink leading-tight">
            Your SHARP,<br />
            <em className="font-serif font-normal text-lime">in one place.</em>
          </h1>
          <p className="text-muted text-xs mt-3 max-w-[340px]">
            Manage your SHARP balance, send tokens, and track every on-chain transaction.
          </p>
        </div>

        {/* Balance Card */}
        <div className="bg-[#1d2c20] border border-[#4d6d43] rounded-lg p-6 min-w-[290px] sm:min-w-[340px] shadow-xl">
          <span className="font-mono text-[9px] uppercase tracking-wider text-muted block">
            On-Chain SHARP Balance
          </span>
          <b className="font-display font-bold text-3xl sm:text-4xl text-ink block my-2">
            {numBalance.toLocaleString('en-IN')}{' '}
            <small className="font-mono text-xs text-lime">SHARP</small>
          </b>
          <p className="font-mono text-xs text-muted mb-5">
            {formatINR(numBalance)}
          </p>

          <div className="flex flex-col gap-2">
            <button
              onClick={handleClaimFaucet}
              disabled={isMinting || isWalletLoading}
              className="w-full bg-lime hover:bg-[#b8df5d] text-[#122016] py-2 px-3 text-xs font-bold rounded inline-flex items-center justify-center gap-1.5 transition-colors disabled:opacity-60 shadow-md"
            >
              <Coins className="w-3.5 h-3.5" />
              <span>{isMinting ? 'Minting on-chain…' : 'Claim 10,000 Testnet SHARP'}</span>
            </button>

            <div className="flex gap-2 mt-1">
              <button
                onClick={() => setDialog('send')}
                className="flex-1 bg-[#27382a] hover:bg-[#334b37] border border-[#3f553c] text-ink py-2 px-2 text-[10px] font-semibold rounded inline-flex items-center justify-center gap-1 transition-colors"
              >
                <ArrowUpRight className="w-3 h-3 text-lime" />
                <span>Send</span>
              </button>

              <button
                onClick={() => setDialog('receive')}
                className="flex-1 bg-[#27382a] hover:bg-[#334b37] border border-[#3f553c] text-ink py-2 px-2 text-[10px] font-semibold rounded inline-flex items-center justify-center gap-1 transition-colors"
              >
                <ArrowDownLeft className="w-3 h-3 text-lime" />
                <span>Receive</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Wallet Content */}
      <section className="max-w-[1200px] mx-auto px-[5%] py-12 sm:py-16 grid grid-cols-1 lg:grid-cols-[1.1fr_0.9fr] gap-6">
        {/* Chart Card */}
        <div className="bg-panel border border-line rounded-lg p-6">
          <span className="font-mono text-[9px] uppercase tracking-widest text-lime block">
            Balance history
          </span>
          <h2 className="font-display font-semibold text-2xl text-ink mt-1 mb-6">
            {numBalance.toLocaleString('en-IN')} SHARP
          </h2>

          <div className="w-full mt-4">
            <svg viewBox="0 0 700 190" preserveAspectRatio="none" className="w-full h-44">
              <defs>
                <linearGradient id="sharpGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%"   stopColor="#c8ef69" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#c8ef69" stopOpacity="0.0"  />
                </linearGradient>
              </defs>
              <path
                d="M0 150 C80 145 85 125 150 138 S220 84 280 105 S340 118 390 74 S460 96 510 54 S590 68 700 22 V190 H0Z"
                fill="url(#sharpGradient)"
              />
              <path
                d="M0 150 C80 145 85 125 150 138 S220 84 280 105 S340 118 390 74 S460 96 510 54 S590 68 700 22"
                fill="none"
                stroke="#c8ef69"
                strokeWidth="3.5"
              />
            </svg>
          </div>
        </div>

        {/* Transaction History Card */}
        <div className="bg-panel border border-line rounded-lg p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-display font-semibold text-lg text-ink">
              Transaction history
            </h2>
            <button
              onClick={() => showToast('Showing all on-chain event logs')}
              className="text-lime hover:underline font-bold text-xs inline-flex items-center gap-1"
            >
              <span>View all</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-line">
            {transactions.map(t => (
              <div key={t.id} className="py-3.5 flex items-center gap-3">
                <div className="w-7 h-7 rounded-full bg-[#28372b] grid place-items-center flex-shrink-0">
                  {getTransactionIcon(t.icon)}
                </div>

                <div className="flex-1 min-w-0">
                  <b className="text-xs font-semibold text-ink block truncate">
                    {t.title}
                  </b>
                  <small className="text-[10px] text-muted block mt-0.5">
                    {t.status} · {t.timestamp}
                  </small>
                </div>

                <strong
                  className={`font-mono text-xs font-semibold flex-shrink-0 ${
                    t.type === 'credit' ? 'text-lime' : 'text-ink'
                  }`}
                >
                  {t.amount}
                </strong>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Send Dialog ── */}
      {dialog === 'send' && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm grid place-items-center p-4">
          <div className="w-full max-w-[420px] bg-[#17211b] border border-[#3d5542] rounded-lg p-7 animate-rise shadow-2xl">
            <div className="flex justify-between items-center mb-6">
              <h2 className="font-display font-semibold text-xl text-ink flex items-center gap-2">
                <Send className="w-4 h-4 text-lime" />
                Send SHARP
              </h2>
              <button onClick={() => setDialog(null)} className="text-muted hover:text-ink p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSend} className="space-y-4">
              <div>
                <label className="block text-[10px] text-muted uppercase font-mono mb-1.5">
                  Recipient address
                </label>
                <input
                  type="text"
                  value={sendAddr}
                  onChange={e => setSendAddr(e.target.value)}
                  placeholder="0x..."
                  required
                  className="w-full bg-[#151d18] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime transition-colors font-mono"
                />
              </div>

              <div>
                <label className="block text-[10px] text-muted uppercase font-mono mb-1.5">
                  Amount (SHARP)
                </label>
                <input
                  type="number"
                  value={sendAmount}
                  onChange={e => setSendAmount(e.target.value)}
                  placeholder="e.g. 500"
                  min="1"
                  max={numBalance}
                  required
                  className="w-full bg-[#151d18] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime transition-colors"
                />
                <p className="text-[10px] text-muted mt-1">
                  Available: {numBalance.toLocaleString('en-IN')} SHARP
                </p>
              </div>

              <button
                type="submit"
                className="w-full bg-lime hover:bg-[#b8df5d] text-[#122016] py-3 px-4 rounded font-extrabold text-xs inline-flex items-center justify-center gap-2 transition-colors mt-2"
              >
                <Send className="w-4 h-4" />
                <span>Send tokens</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ── Receive Dialog ── */}
      {dialog === 'receive' && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm grid place-items-center p-4">
          <div className="w-full max-w-[400px] bg-[#17211b] border border-[#3d5542] rounded-lg p-7 animate-rise shadow-2xl text-center">
            <div className="flex justify-between items-center mb-6">
              <h2 className="font-display font-semibold text-xl text-ink flex items-center gap-2">
                <ArrowDownLeft className="w-4 h-4 text-lime" />
                Receive SHARP
              </h2>
              <button onClick={() => setDialog(null)} className="text-muted hover:text-ink p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* QR placeholder */}
            <div className="w-40 h-40 mx-auto bg-white rounded-lg grid place-items-center mb-5 border-4 border-lime">
              <div className="grid grid-cols-7 gap-0.5 p-2 w-full h-full">
                {Array.from({ length: 49 }).map((_, i) => (
                  <div
                    key={i}
                    className={`rounded-[1px] ${Math.random() > 0.4 ? 'bg-[#101512]' : 'bg-white'}`}
                  />
                ))}
              </div>
            </div>

            <p className="text-muted text-[10px] mb-2">Your wallet address</p>
            <div className="flex items-center gap-2 bg-[#151d18] border border-line rounded px-3 py-2.5 text-left">
              <span className="font-mono text-[10px] text-lime truncate flex-1">
                {walletAddress || '0x7a4F298b42Ce9c1b72a91Eb409F3d21A56e09c21'}
              </span>
              <button
                onClick={handleCopyAddress}
                className="text-lime hover:text-ink transition-colors flex-shrink-0"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
            </div>

            <p className="text-muted text-[10px] mt-3 leading-relaxed">
              Share this address to receive SHARP tokens from any compatible wallet.
            </p>

            <div className="flex items-center gap-1 justify-center mt-3">
              <span className="font-mono text-[8px] text-lime bg-lime/10 border border-lime/20 rounded px-2 py-0.5">
                {displayAddr}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
