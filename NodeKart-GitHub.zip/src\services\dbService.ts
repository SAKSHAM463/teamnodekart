// ─────────────────────────────────────────────────────────────
//  src/services/dbService.ts
//  Persistent Database Service Layer for NodeKart.
//  Syncs app state with browser storage so listings, credentials,
//  and wallet details remain live across page refreshes.
// ─────────────────────────────────────────────────────────────

import {
  Product,
  INITIAL_PRODUCTS,
  UserProfile,
  INITIAL_USER,
  WalletTransaction,
  INITIAL_TRANSACTIONS,
} from '../mockData';

const STORAGE_KEYS = {
  PRODUCTS: 'nodekart_db_products_v1',
  USER_PROFILE: 'nodekart_db_user_profile_v1',
  TRANSACTIONS: 'nodekart_db_transactions_v1',
} as const;

export class DBService {
  /**
   * Fetch all marketplace products.
   * If none are saved, initializes DB with default products (including Electric Guitar).
   */
  static getProducts(): Product[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      if (!data) {
        this.saveProducts(INITIAL_PRODUCTS);
        return INITIAL_PRODUCTS;
      }
      const parsed: Product[] = JSON.parse(data);

      // Verify default electric guitar is present in case user previously loaded an older version
      const hasGuitar = parsed.some(p => p.id === 'electric-guitar' || p.name.includes('Guitar'));
      if (!hasGuitar) {
        const guitar = INITIAL_PRODUCTS.find(p => p.id === 'electric-guitar');
        if (guitar) {
          parsed.unshift(guitar);
          this.saveProducts(parsed);
        }
      }

      return parsed;
    } catch (err) {
      console.warn('Failed to parse products from local DB:', err);
      return INITIAL_PRODUCTS;
    }
  }

  /**
   * Save entire products array to persistent storage.
   */
  static saveProducts(products: Product[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    } catch (err) {
      console.error('Failed to save products to DB:', err);
    }
  }

  /**
   * Add a single new product listing to the persistent database.
   */
  static saveProduct(product: Product): Product[] {
    const products = this.getProducts();
    const updated = [product, ...products];
    this.saveProducts(updated);
    return updated;
  }

  /**
   * Fetch user profile & stored credentials.
   */
  static getUserProfile(): UserProfile {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
      if (!data) {
        this.saveUserProfile(INITIAL_USER);
        return INITIAL_USER;
      }
      return JSON.parse(data);
    } catch (err) {
      console.warn('Failed to load user profile from DB:', err);
      return INITIAL_USER;
    }
  }

  /**
   * Save updated user profile & credentials.
   */
  static saveUserProfile(profile: UserProfile): void {
    try {
      localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
    } catch (err) {
      console.error('Failed to save user profile to DB:', err);
    }
  }

  /**
   * Fetch saved wallet transactions.
   */
  static getTransactions(): WalletTransaction[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
      if (!data) {
        this.saveTransactions(INITIAL_TRANSACTIONS);
        return INITIAL_TRANSACTIONS;
      }
      return JSON.parse(data);
    } catch (err) {
      console.warn('Failed to load transactions from DB:', err);
      return INITIAL_TRANSACTIONS;
    }
  }

  /**
   * Save transactions to persistent storage.
   */
  static saveTransactions(transactions: WalletTransaction[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
    } catch (err) {
      console.error('Failed to save transactions to DB:', err);
    }
  }

  /**
   * Reset database back to factory seeds (for debugging or testing).
   */
  static resetToDefaults(): void {
    localStorage.removeItem(STORAGE_KEYS.PRODUCTS);
    localStorage.removeItem(STORAGE_KEYS.USER_PROFILE);
    localStorage.removeItem(STORAGE_KEYS.TRANSACTIONS);
  }
}
