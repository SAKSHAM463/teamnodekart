import React, { useState, useRef, useCallback } from 'react';
import {
  ImagePlus,
  ArrowUpRight,
  ShieldCheck,
  X,
  FileText,
  Upload,
  AlertTriangle,
  Wallet,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ProductCard } from '../components/ProductCard';
import { Product } from '../mockData';

const FALLBACK_IMAGE =
  'https://images.unsplash.com/photo-1592286927505-2fd0dcb29f2f?auto=format&fit=crop&w=900&q=85';

export const SellProductPage: React.FC = () => {
  const { publishProduct, showToast, userProfile, walletAddress, isWalletConnected, connectWallet } = useApp();

  /* ── Product photo state ── */
  const [productImages, setProductImages] = useState<string[]>([]);
  const [photoDragging, setPhotoDragging] = useState(false);
  const photoInputRef = useRef<HTMLInputElement>(null);

  /* ── Bill upload state ── */
  const [isSecondHand, setIsSecondHand] = useState(false);
  const [billUrl, setBillUrl] = useState<string | null>(null);
  const [billFileName, setBillFileName] = useState<string | null>(null);
  const [billDragging, setBillDragging] = useState(false);
  const billInputRef = useRef<HTMLInputElement>(null);

  /* ── Form fields ── */
  const [formData, setFormData] = useState({
    name: '',
    category: 'Electronics',
    price: '' as number | '',
    seller: userProfile.name,
    delivery: '',
    tag: 'Like new',
    description: '',
    hasAuthCert: false,
    hasQR: false,
    hasProvenance: false,
  });

  /* ══════════════════════════════
     Photo helpers
  ══════════════════════════════ */
  const addPhotos = useCallback((files: FileList | null) => {
    if (!files) return;
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    const urls: string[] = [];
    Array.from(files).forEach(file => {
      if (!validTypes.includes(file.type)) return;
      urls.push(URL.createObjectURL(file));
    });
    setProductImages(prev => [...prev, ...urls].slice(0, 8)); // max 8 photos
  }, []);

  const removePhoto = (idx: number) => {
    setProductImages(prev => {
      const next = [...prev];
      URL.revokeObjectURL(next[idx]);
      next.splice(idx, 1);
      return next;
    });
  };

  const onPhotoDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setPhotoDragging(false);
    addPhotos(e.dataTransfer.files);
  };

  /* ══════════════════════════════
     Bill helpers
  ══════════════════════════════ */
  const addBill = useCallback((files: FileList | null) => {
    if (!files || files.length === 0) return;
    const file = files[0];
    const valid = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
    if (!valid.includes(file.type)) {
      showToast('Please upload a JPG, PNG, or PDF file');
      return;
    }
    if (billUrl) URL.revokeObjectURL(billUrl);
    setBillUrl(URL.createObjectURL(file));
    setBillFileName(file.name);
  }, [billUrl, showToast]);

  const removeBill = () => {
    if (billUrl) URL.revokeObjectURL(billUrl);
    setBillUrl(null);
    setBillFileName(null);
    if (billInputRef.current) billInputRef.current.value = '';
  };

  const onBillDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setBillDragging(false);
    addBill(e.dataTransfer.files);
  };

  /* ══════════════════════════════
     Preview product
  ══════════════════════════════ */
  const previewProduct: Product = {
    id: 'preview',
    name: formData.name || 'Untitled Listing',
    seller: formData.seller,
    rating: '5.0',
    price: Number(formData.price) || 0,
    category: formData.category,
    delivery: formData.delivery || 'Ships in 2–5 days',
    image: productImages[0] ?? FALLBACK_IMAGE,
    tag: formData.tag,
    blockchain: formData.hasProvenance || formData.hasAuthCert,
    description: formData.description,
    isSecondHand,
    billUrl: billUrl ?? undefined,
  };

  /* ══════════════════════════════
     Submit
  ══════════════════════════════ */
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (isSecondHand && !billUrl) {
      showToast('⚠ Please upload a purchase bill for second-hand items');
      return;
    }

    if (!formData.name.trim()) {
      showToast('⚠ Please enter a product name');
      return;
    }

    publishProduct({
      name: formData.name,
      seller: formData.seller,
      rating: '5.0',
      price: Number(formData.price) || 0,
      category: formData.category,
      delivery: formData.delivery,
      image: productImages[0] ?? FALLBACK_IMAGE,
      tag: formData.tag,
      blockchain: formData.hasProvenance || formData.hasAuthCert,
      description: formData.description,
      location: 'India',
      isSecondHand,
      billUrl: billUrl ?? undefined,
      sellerWallet: walletAddress || userProfile.walletAddress,
    });
  };

  /* ══════════════════════════════
     Render
  ══════════════════════════════ */
  return (
    <div className="max-w-[1200px] mx-auto px-[5%] py-10 sm:py-14 animate-rise">
      {/* Page Heading */}
      <div className="mb-8 pb-4 border-b border-line">
        <p className="font-mono text-[10px] uppercase tracking-widest text-lime mb-1">
          Seller studio
        </p>
        <h1 className="font-display font-semibold text-3xl sm:text-5xl text-ink">
          List a <em className="font-serif font-normal text-lime">good thing.</em>
        </h1>
        <p className="text-muted text-xs sm:text-sm mt-2 max-w-[500px]">
          Give it a new home with a listing that is clear, honest, and easy to verify via smart escrow.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1.2fr_0.8fr] gap-10 lg:gap-14 items-start">
        {/* ── Listing Form ── */}
        <form onSubmit={handleSubmit} className="space-y-5">

          {/* ── Photo Upload ── */}
          <div>
            <label className="block text-[10px] text-muted uppercase font-mono mb-2">
              Product photos <span className="text-[#617068]">(up to 8 · JPG, PNG, WebP)</span>
            </label>

            {/* Drop zone */}
            <div
              className={`h-32 border border-dashed rounded-lg flex flex-col items-center justify-center gap-1.5 bg-[#141b17] cursor-pointer transition-colors p-4 text-center ${
                photoDragging
                  ? 'border-lime bg-[#1b2a1f]'
                  : 'border-[#4b5d51] hover:border-lime'
              }`}
              onClick={() => photoInputRef.current?.click()}
              onDragOver={e => { e.preventDefault(); setPhotoDragging(true); }}
              onDragLeave={() => setPhotoDragging(false)}
              onDrop={onPhotoDrop}
            >
              <ImagePlus className="w-6 h-6 text-lime" />
              <b className="text-ink text-xs font-semibold">Drop photos here</b>
              <span className="text-muted text-[10px]">or click to choose from your device</span>
            </div>

            {/* Hidden file input */}
            <input
              ref={photoInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              multiple
              className="hidden"
              onChange={e => addPhotos(e.target.files)}
            />

            {/* Thumbnail strip */}
            {productImages.length > 0 && (
              <div className="flex gap-2 mt-3 flex-wrap">
                {productImages.map((src, idx) => (
                  <div key={idx} className="relative w-16 h-16 rounded overflow-hidden border border-line group flex-shrink-0">
                    <img src={src} alt={`photo-${idx}`} className="w-full h-full object-cover" />
                    {idx === 0 && (
                      <span className="absolute bottom-0 left-0 right-0 bg-lime text-[#122016] text-[8px] font-bold text-center py-0.5">
                        MAIN
                      </span>
                    )}
                    <button
                      type="button"
                      onClick={() => removePhoto(idx)}
                      className="absolute top-0.5 right-0.5 bg-black/70 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
                {productImages.length < 8 && (
                  <button
                    type="button"
                    onClick={() => photoInputRef.current?.click()}
                    className="w-16 h-16 rounded border border-dashed border-[#4b5d51] hover:border-lime flex items-center justify-center text-lime transition-colors flex-shrink-0"
                  >
                    <ImagePlus className="w-5 h-5" />
                  </button>
                )}
              </div>
            )}
          </div>

          {/* ── Product Name ── */}
          <div>
            <label className="block text-[10px] text-muted uppercase font-mono mb-1.5">
              Product name
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={e => setFormData({ ...formData, name: e.target.value })}
              required
              placeholder="e.g. Fujifilm X100V Camera"
              className="w-full bg-[#151d18] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime transition-colors"
            />
          </div>

          {/* ── Category + Price ── */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] text-muted uppercase font-mono mb-1.5">
                Category
              </label>
              <select
                value={formData.category}
                onChange={e => setFormData({ ...formData, category: e.target.value })}
                className="w-full bg-[#151d18] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime transition-colors cursor-pointer"
              >
                <option value="Electronics">Electronics</option>
                <option value="Fashion">Fashion</option>
                <option value="Home">Home</option>
                <option value="Books">Books</option>
                <option value="Collectibles">Collectibles</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-muted uppercase font-mono mb-1.5">
                Price in SHARP
              </label>
              <input
                type="number"
                value={formData.price}
                onChange={e => setFormData({ ...formData, price: e.target.value === '' ? '' : Number(e.target.value) })}
                required
                min="100"
                placeholder="e.g. 12500"
                className="w-full bg-[#151d18] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime transition-colors"
              />
            </div>
          </div>

          {/* ── Condition Tag ── */}
          <div>
            <label className="block text-[10px] text-muted uppercase font-mono mb-1.5">
              Condition
            </label>
            <select
              value={formData.tag}
              onChange={e => setFormData({ ...formData, tag: e.target.value })}
              className="w-full bg-[#151d18] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime transition-colors cursor-pointer"
            >
              <option value="Brand new">Brand new</option>
              <option value="Like new">Like new</option>
              <option value="Gently used">Gently used</option>
              <option value="Good condition">Good condition</option>
              <option value="Fair condition">Fair condition</option>
            </select>
          </div>

          {/* ── Description ── */}
          <div>
            <label className="block text-[10px] text-muted uppercase font-mono mb-1.5">
              Description
            </label>
            <textarea
              value={formData.description}
              onChange={e => setFormData({ ...formData, description: e.target.value })}
              rows={3}
              placeholder="Describe condition, accessories included, and provenance..."
              className="w-full bg-[#151d18] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime transition-colors resize-y"
            />
          </div>

          {/* ── Second-hand toggle + Bill upload ── */}
          <div className="border border-line rounded-lg p-4 bg-[#141b17]">
            <label className="flex items-center gap-3 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isSecondHand}
                onChange={e => {
                  setIsSecondHand(e.target.checked);
                  if (!e.target.checked) removeBill();
                }}
                className="accent-lime w-4 h-4 rounded"
              />
              <span className="text-xs text-ink font-semibold">
                This is a second-hand / pre-owned item
              </span>
            </label>

            {isSecondHand && (
              <div className="mt-4">
                <label className="block text-[10px] text-muted uppercase font-mono mb-2 flex items-center gap-1.5">
                  <FileText className="w-3 h-3 text-lime" />
                  Upload purchase bill or receipt
                  <span className="text-coral font-bold">*</span>
                </label>

                {!billUrl ? (
                  <div
                    className={`h-24 border border-dashed rounded-lg flex flex-col items-center justify-center gap-1 bg-[#121a15] cursor-pointer transition-colors ${
                      billDragging
                        ? 'border-lime bg-[#1a2b1e]'
                        : 'border-[#4b5d51] hover:border-lime'
                    }`}
                    onClick={() => billInputRef.current?.click()}
                    onDragOver={e => { e.preventDefault(); setBillDragging(true); }}
                    onDragLeave={() => setBillDragging(false)}
                    onDrop={onBillDrop}
                  >
                    <Upload className="w-5 h-5 text-lime" />
                    <span className="text-ink text-[11px] font-semibold">Drop bill here or click to upload</span>
                    <span className="text-muted text-[10px]">PDF, JPG, PNG accepted</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-3 bg-[#1b2820] border border-line rounded-lg px-3 py-2.5">
                    <FileText className="w-4 h-4 text-lime flex-shrink-0" />
                    <span className="text-xs text-ink truncate flex-1">{billFileName}</span>
                    <span className="text-[9px] font-mono text-lime bg-lime/10 px-2 py-0.5 rounded flex-shrink-0">
                      Attached
                    </span>
                    <button
                      type="button"
                      onClick={removeBill}
                      className="text-muted hover:text-coral transition-colors flex-shrink-0"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                )}

                <input
                  ref={billInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp,application/pdf"
                  className="hidden"
                  onChange={e => addBill(e.target.files)}
                />

                {!billUrl && (
                  <p className="flex items-center gap-1.5 text-[10px] text-amber-400 mt-2">
                    <AlertTriangle className="w-3 h-3 flex-shrink-0" />
                    A purchase bill is required for second-hand listings
                  </p>
                )}
              </div>
            )}
          </div>

          {/* ── Shipping ── */}
          <div>
            <label className="block text-[10px] text-muted uppercase font-mono mb-1.5">
              Shipping information
            </label>
            <input
              type="text"
              value={formData.delivery}
              onChange={e => setFormData({ ...formData, delivery: e.target.value })}
              required
              placeholder="e.g. Ships from Bengaluru · 2-4 days"
              className="w-full bg-[#151d18] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime transition-colors"
            />
          </div>

          {/* ── Authenticity & Verification ── */}
          <div className="border-t border-line pt-5 mt-2">
            <h3 className="font-display font-semibold text-sm text-ink mb-3 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-lime" />
              Authenticity & verification
            </h3>

            <div className="space-y-2.5 text-xs text-muted">
              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.hasAuthCert}
                  onChange={e => setFormData({ ...formData, hasAuthCert: e.target.checked })}
                  className="accent-lime rounded"
                />
                <span>Add cryptographic authenticity certificate</span>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.hasQR}
                  onChange={e => setFormData({ ...formData, hasQR: e.target.checked })}
                  className="accent-lime rounded"
                />
                <span>Generate tamper-proof physical product QR</span>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.hasProvenance}
                  onChange={e => setFormData({ ...formData, hasProvenance: e.target.checked })}
                  className="accent-lime rounded"
                />
                <span>Attach on-chain provenance transfer record</span>
              </label>
            </div>
          </div>

          {/* ── Seller Payout Wallet Notice ── */}
          <div className="border border-[#3d5542] rounded-lg p-4 bg-[#17231b] flex items-start gap-3 mt-4">
            <Wallet className="w-5 h-5 text-lime flex-shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <b className="text-xs font-semibold text-ink block">Seller Payout Destination</b>
              <p className="text-muted text-[11px] mt-0.5 leading-relaxed">
                When a buyer purchases this item, payments and collateral releases will automatically be transferred to your on-chain wallet address:
              </p>
              <div className="font-mono text-[11px] text-lime mt-2 flex items-center justify-between gap-2 bg-[#121a14] px-3 py-1.5 rounded border border-line">
                <div className="flex items-center gap-1.5 truncate">
                  <span className={`w-2 h-2 rounded-full ${isWalletConnected ? 'bg-lime animate-pulse' : 'bg-amber-400'}`} />
                  <span className="truncate">{walletAddress || userProfile.walletAddress}</span>
                </div>
                {!isWalletConnected && (
                  <button
                    type="button"
                    onClick={connectWallet}
                    className="text-[10px] font-bold text-lime hover:underline flex-shrink-0"
                  >
                    Connect
                  </button>
                )}
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-lime hover:bg-[#b8df5d] text-[#122016] py-3.5 px-4 rounded-[5px] font-extrabold text-xs inline-flex items-center justify-center gap-2 transition-colors mt-6 shadow-lg"
          >
            <span>Publish product</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </form>

        {/* ── Live Preview Sidebar ── */}
        <aside className="bg-[#141b17] border border-line rounded-lg p-6 sticky top-24">
          <span className="font-mono text-[9px] uppercase tracking-widest text-lime block mb-4">
            Live preview
          </span>
          <div className="max-w-[280px] mx-auto">
            <ProductCard product={previewProduct} />
          </div>
          {isSecondHand && billUrl && (
            <div className="mt-4 flex items-center gap-2 text-[10px] text-lime bg-lime/10 border border-lime/20 rounded px-3 py-2">
              <FileText className="w-3.5 h-3.5 flex-shrink-0" />
              <span>Purchase bill attached · visible to buyer</span>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
};
