import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import type { PageType } from '../context/AppContext';

export const Footer: React.FC = () => {
  const { navigate } = useApp();

  const navLinks: { label: string; page: PageType }[] = [
    { label: 'Marketplace',      page: 'market'   },
    { label: 'Sell an item',     page: 'list'     },
    { label: 'Orders & Escrow',  page: 'orders'   },
    { label: 'Wallet',           page: 'wallet'   },
    { label: 'Rewards',          page: 'rewards'  },
    { label: 'Referrals',        page: 'referrals'},
  ];

  return (
    <footer className="border-t border-line bg-bg">
      {/* Main footer grid */}
      <div className="max-w-[1200px] mx-auto px-[5%] py-12 grid grid-cols-1 md:grid-cols-[1.4fr_1fr_1fr] gap-10">
        {/* Brand Block */}
        <div>
          <button
            onClick={() => navigate('home')}
            className="flex items-center gap-2 font-display font-bold text-[18px] tracking-tight text-ink hover:opacity-90 transition-opacity mb-4"
          >
            <span className="grid place-items-center w-[27px] h-[27px] rounded-[8px] bg-lime text-[#102016] font-serif font-bold text-[16px]">
              N
            </span>
            <span>node<span className="text-lime">.</span>kart</span>
          </button>
          <p className="text-muted text-xs leading-relaxed max-w-[280px]">
            A peer-to-peer marketplace with transparent SHARP escrow payments.
            Every transaction verifiable on-chain — no middlemen, no scams.
          </p>
          <div className="flex items-center gap-2 mt-5">
            <span className="font-mono text-[9px] uppercase tracking-widest text-lime bg-[#172219] border border-[#2c3d31] px-2 py-1 rounded">
              SHARP Network
            </span>
            <span className="font-mono text-[9px] uppercase tracking-widest text-muted bg-panel border border-line px-2 py-1 rounded">
              ERC-4337 Gasless
            </span>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <span className="font-mono text-[9px] uppercase tracking-widest text-lime block mb-4">
            Navigate
          </span>
          <ul className="space-y-2.5">
            {navLinks.map(({ label, page }) => (
              <li key={page}>
                <button
                  onClick={() => navigate(page)}
                  className="text-muted hover:text-ink text-xs transition-colors text-left"
                >
                  {label}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Trust & Tech */}
        <div>
          <span className="font-mono text-[9px] uppercase tracking-widest text-lime block mb-4">
            Technology
          </span>
          <ul className="space-y-2.5 text-xs text-muted">
            <li>Dual-Deposit Escrow</li>
            <li>Chainlink DON Oracle</li>
            <li>ERC-5192 Soulbound Reputation</li>
            <li>ERC-4337 Gasless Checkout</li>
            <li>Sub-game Perfect Nash Equilibrium</li>
          </ul>
          <a
            href="https://github.com/SAKSHAM463/NodeKart"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-lime hover:text-ink text-[11px] font-semibold mt-5 transition-colors"
          >
            <span>View on GitHub</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-line px-[5%] py-4 flex flex-col sm:flex-row justify-between items-center gap-3 text-muted text-[10px]">
        <span>© {new Date().getFullYear()} NodeKart · Buy directly. Pay securely. Own your transaction.</span>
        <span className="font-mono text-[9px] text-lime/70">
          Demo Network · Smart Contract Testnet
        </span>
      </div>
    </footer>
  );
};
