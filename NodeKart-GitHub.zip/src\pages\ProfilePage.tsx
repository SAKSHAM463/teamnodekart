import React, { useState } from 'react';
import { Wallet, Copy, CheckCircle2, ShieldCheck, Award, Lock, Edit3, Save, X, Mail, Phone, UserCheck } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CONTRACTS } from '../contracts/deployed';

export const ProfilePage: React.FC = () => {
  const { userProfile, updateUserProfile, sharpBalance, walletAddress, truncateAddress, reputation, showToast } = useApp();

  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: userProfile.name,
    email: userProfile.email || 'saksham@nodekart.eth',
    phone: userProfile.phone || '+91 98765 43210',
    walletAddress: userProfile.walletAddress,
  });

  const handleCopy = () => {
    navigator.clipboard?.writeText(walletAddress || userProfile.walletAddress);
    showToast('Wallet address copied to clipboard');
  };

  const handleSaveCredentials = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      showToast('Name cannot be empty');
      return;
    }

    const initials = formData.name
      .split(' ')
      .map(part => part[0])
      .join('')
      .substring(0, 2)
      .toUpperCase() || 'NK';

    updateUserProfile({
      name: formData.name,
      email: formData.email,
      phone: formData.phone,
      walletAddress: formData.walletAddress,
      avatarText: initials,
    });
    setIsEditing(false);
  };

  const numBalance = Number(sharpBalance || '0');
  const displayAddress = walletAddress ? truncateAddress(walletAddress) : userProfile.walletAddressShort;

  return (
    <div className="max-w-[1000px] mx-auto px-[5%] py-10 sm:py-14 animate-rise">
      {/* Page Heading */}
      <div className="mb-10 pb-6 border-b border-line flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-widest text-lime mb-2">
            NodeKart Web3 Account
          </p>
          <h1 className="font-display font-semibold text-3xl sm:text-5xl text-ink">
            Your profile &amp; security
          </h1>
          <p className="text-muted text-xs sm:text-sm mt-2">
            Manage your verified wallet identity, saved credentials, and ERC-5192 Soulbound reputation record.
          </p>
        </div>

        <button
          onClick={() => setIsEditing(true)}
          className="self-start sm:self-auto bg-panel hover:bg-[#202d24] border border-line hover:border-lime text-lime px-4 py-2.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
        >
          <Edit3 className="w-4 h-4" />
          <span>Edit Saved Credentials</span>
        </button>
      </div>

      {/* Edit Credentials Modal */}
      {isEditing && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#141d17] border border-line rounded-xl max-w-[500px] w-full p-6 sm:p-7 shadow-2xl relative animate-rise">
            <button
              onClick={() => setIsEditing(false)}
              className="absolute top-4 right-4 text-muted hover:text-ink p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2.5 mb-5 pb-3 border-b border-line">
              <UserCheck className="w-5 h-5 text-lime" />
              <h3 className="font-display font-semibold text-xl text-ink">
                Edit Saved Profile &amp; Credentials
              </h3>
            </div>

            <form onSubmit={handleSaveCredentials} className="space-y-4">
              <div>
                <label className="block text-[10px] text-muted uppercase font-mono mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-[#1c2720] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] text-muted uppercase font-mono mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-[#1c2720] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime"
                  placeholder="name@example.com"
                />
              </div>

              <div>
                <label className="block text-[10px] text-muted uppercase font-mono mb-1">
                  Phone Number
                </label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-[#1c2720] border border-line rounded p-3 text-xs text-ink outline-none focus:border-lime"
                  placeholder="+91 98765 43210"
                />
              </div>

              <div>
                <label className="block text-[10px] text-muted uppercase font-mono mb-1">
                  Wallet Address
                </label>
                <input
                  type="text"
                  value={formData.walletAddress}
                  onChange={e => setFormData({ ...formData, walletAddress: e.target.value })}
                  className="w-full bg-[#1c2720] border border-line rounded p-3 text-xs font-mono text-lime outline-none focus:border-lime"
                  placeholder="0x..."
                />
              </div>

              <div className="flex justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2.5 rounded text-xs text-muted hover:text-ink"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-lime hover:bg-[#b8df5d] text-[#122016] font-bold text-xs px-5 py-2.5 rounded flex items-center gap-2 transition-colors"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Credentials</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-[0.85fr_1.15fr] gap-6">
        {/* Profile Identity & SBT Badge Card */}
        <div className="bg-panel border border-line rounded-lg p-6 sm:p-7 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-5">
              <div className="w-16 h-16 rounded-full bg-[#d8c5a8] text-[#28251f] text-xl font-extrabold grid place-items-center">
                {userProfile.avatarText}
              </div>
              <span className="flex items-center gap-1.5 text-lime bg-[#213524] border border-[#486b40] px-3 py-1.5 rounded-full text-[10px] font-mono font-bold">
                <Lock className="w-3 h-3" /> ERC-5192 Soulbound
              </span>
            </div>

            <h2 className="font-display font-semibold text-2xl text-ink">
              {userProfile.name}
            </h2>
            <p className="text-muted text-xs mt-1">
              Member since {userProfile.memberSince} · Verified Merchant &amp; Buyer
            </p>

            {/* Contact details pill */}
            <div className="mt-4 space-y-1.5 text-xs text-muted border-t border-line/60 pt-3">
              {userProfile.email && (
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-lime" />
                  <span>{userProfile.email}</span>
                </div>
              )}
              {userProfile.phone && (
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-lime" />
                  <span>{userProfile.phone}</span>
                </div>
              )}
            </div>

            {/* SBT Stats Pill */}
            <div className="bg-[#18241d] border border-[#3b553f] p-4 rounded-lg mt-5 space-y-2 text-xs">
              <div className="flex items-center justify-between text-ink">
                <span className="text-muted flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-lime" /> SBT Token ID
                </span>
                <b className="font-mono text-lime">#{reputation?.tokenId || 1} (Locked)</b>
              </div>
              <div className="flex items-center justify-between text-ink">
                <span className="text-muted">Dispute-Free Streak</span>
                <b className="font-mono text-ink">{reputation?.disputeFreeStreak || 12} Consecutive Trades</b>
              </div>
              <div className="flex items-center justify-between text-ink">
                <span className="text-muted">Slashed Collateral Events</span>
                <b className="font-mono text-lime">{reputation?.slashedCount || 0} (0% Fraud)</b>
              </div>
            </div>
          </div>

          {/* Wallet Address Line */}
          <div className="border-t border-line pt-5 mt-6">
            <span className="text-muted text-[10px] block mb-1">
              Connected wallet address
            </span>
            <div className="flex items-center justify-between text-lime font-mono text-xs bg-[#202c25] p-2.5 rounded border border-line">
              <span className="flex items-center gap-2 truncate">
                <Wallet className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="truncate">{displayAddress}</span>
              </span>
              <button
                onClick={handleCopy}
                className="text-lime hover:text-ink p-1"
                title="Copy full address"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Profile Details List */}
        <div className="bg-panel border border-line rounded-lg px-6 py-2 divide-y divide-line">
          <div className="py-5 flex justify-between items-center text-xs">
            <span className="text-muted">Wallet status</span>
            <strong className="text-lime font-semibold flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" />
              Connected &amp; verified on-chain
            </strong>
          </div>

          <div className="py-5 flex justify-between items-center text-xs">
            <span className="text-muted">SHARP balance</span>
            <strong className="font-mono text-ink font-semibold">
              {numBalance.toLocaleString('en-IN')} SHARP
            </strong>
          </div>

          <div className="py-5 flex justify-between items-center text-xs">
            <span className="text-muted">Completed On-Chain Orders</span>
            <strong className="font-mono text-ink font-semibold">
              {reputation?.completedTrades || userProfile.ordersCompleted} orders
            </strong>
          </div>

          <div className="py-5 flex justify-between items-center text-xs">
            <span className="text-muted">Reputation Score</span>
            <strong className="text-coral font-semibold">
              ★ {reputation?.averageRating ? reputation.averageRating.toFixed(1) : '4.9'} / 5.0
            </strong>
          </div>

          <div className="py-5 flex justify-between items-center text-xs cursor-pointer group">
            <span className="text-muted group-hover:text-ink transition-colors">
              ERC-4337 Paymaster Gas Sponsorship
            </span>
            <span className="font-mono text-lime font-bold">Enabled (Zero Gas Checkout)</span>
          </div>

          <div className="py-5 flex justify-between items-center text-xs cursor-pointer group">
            <span className="text-muted group-hover:text-ink transition-colors flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-lime" />
              Reputation Contract
            </span>
            <b className="font-mono text-[10px] text-muted group-hover:text-lime truncate max-w-[160px]">
              {CONTRACTS.NodeKartReputationSBT.address.slice(0, 8)}...{CONTRACTS.NodeKartReputationSBT.address.slice(-4)}
            </b>
          </div>
        </div>
      </div>
    </div>
  );
};

