import hardhat from "hardhat";
import { ethers } from "ethers";

async function main() {
  console.log("🌱 Starting NodeKart Testnet & Demo Seeding...");

  const connection = await hardhat.network.connect();
  const provider = new ethers.BrowserProvider(connection.provider);

  const deployer = await provider.getSigner(0);
  const seller = await provider.getSigner(1);
  const buyer = await provider.getSigner(2);

  const deployerAddr = await deployer.getAddress();
  const sellerAddr = await seller.getAddress();
  const buyerAddr = await buyer.getAddress();

  console.log(`Deployer / Admin: ${deployerAddr}`);
  console.log(`Demo Seller:      ${sellerAddr}`);
  console.log(`Demo Buyer:       ${buyerAddr}`);

  // Load deployed contracts
  const sharpArtifact = await hardhat.artifacts.readArtifact("SHARPToken");
  const escrowArtifact = await hardhat.artifacts.readArtifact("NodeKartEscrow");
  const oracleArtifact = await hardhat.artifacts.readArtifact("MockChainlinkOracle");
  const sbtArtifact = await hardhat.artifacts.readArtifact("NodeKartReputationSBT");

  // Re-deploy fresh contracts for deterministic seeding
  const sharp = await (new ethers.ContractFactory(sharpArtifact.abi, sharpArtifact.bytecode, deployer)).deploy(deployerAddr);
  await sharp.waitForDeployment();
  const sharpAddr = await sharp.getAddress();

  const sbt = await (new ethers.ContractFactory(sbtArtifact.abi, sbtArtifact.bytecode, deployer)).deploy(deployerAddr);
  await sbt.waitForDeployment();
  const sbtAddr = await sbt.getAddress();

  const oracle = await (new ethers.ContractFactory(oracleArtifact.abi, oracleArtifact.bytecode, deployer)).deploy(deployerAddr);
  await oracle.waitForDeployment();
  const oracleAddr = await oracle.getAddress();

  const escrow = await (new ethers.ContractFactory(escrowArtifact.abi, escrowArtifact.bytecode, deployer)).deploy(
    sharpAddr,
    sbtAddr,
    oracleAddr,
    deployerAddr
  );
  await escrow.waitForDeployment();
  const escrowAddr = await escrow.getAddress();

  await (await sharp.setMinter(escrowAddr, true)).wait();
  await (await sbt.setAuthorizedUpdater(escrowAddr, true)).wait();

  // Transfer 100,000 SHARP each to Seller and Buyer
  const seedAmount = ethers.parseEther("100000");
  await (await sharp.transfer(sellerAddr, seedAmount)).wait();
  await (await sharp.transfer(buyerAddr, seedAmount)).wait();
  console.log("✅ Transferred 100,000 SHARP each to Seller and Buyer");

  // Buyer & Seller approve Escrow
  const maxApproval = ethers.MaxUint256;
  await (await sharp.connect(seller).approve(escrowAddr, maxApproval)).wait();
  await (await sharp.connect(buyer).approve(escrowAddr, maxApproval)).wait();
  console.log("✅ Approved Escrow contract for SHARP token transfers");

  // Create an initial active sample Escrow for iPhone 15
  const itemPrice = ethers.parseEther("42500");
  const sellerCollateral = ethers.parseEther("4250"); // 10%
  const buyerCollateral = ethers.parseEther("2125");   // 5%

  const createTx = await escrow.connect(buyer).createEscrow(
    sellerAddr,
    itemPrice,
    sellerCollateral,
    buyerCollateral,
    "iphone"
  );
  await createTx.wait();

  // Seller deposits collateral
  await (await escrow.connect(seller).depositSellerCollateral(1)).wait();

  // Buyer deposits purchase price + collateral
  await (await escrow.connect(buyer).depositBuyerFunds(1)).wait();

  // Seller dispatches
  await (await escrow.connect(seller).dispatchOrder(1, "NK9271IN", "BlueDart Logistics")).wait();

  // Oracle logs in-transit status
  await (await oracle.updateCarrierStatus("NK9271IN", "BlueDart Logistics", 1, "Bengaluru Distribution Hub")).wait();

  console.log("✅ Created and seeded sample Order #1 (iPhone 15, Status: Dispatched, Tracking: NK9271IN)");
  console.log("🌱 Seeding complete!\n");
}

main().catch(console.error);
