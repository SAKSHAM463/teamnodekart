// ─────────────────────────────────────────────────────────────
//  src/lib/wallet.ts
//  Pure TypeScript — zero React imports.
//
//  Handles MetaMask (EIP-1193) provider access, account requests,
//  and chain validation. Consumed by src/hooks/useMetaMask.ts.
// ─────────────────────────────────────────────────────────────

/** EIP-1193 provider interface (MetaMask injects this as window.ethereum) */
export interface EIP1193Provider {
  request: (args: { method: string; params?: unknown[] }) => Promise<unknown>;
  on: (event: string, handler: (...args: unknown[]) => void) => void;
  removeListener: (event: string, handler: (...args: unknown[]) => void) => void;
  isMetaMask?: boolean;
}

declare global {
  interface Window {
    ethereum?: EIP1193Provider;
  }
}

// ─── Feature Flag ─────────────────────────────────────────────

/**
 * Returns true for live Web3 MetaMask mode.
 */
export const isMetaMaskEnabled = (): boolean => true;

// ─── Provider Access ──────────────────────────────────────────

/**
 * Returns the injected EIP-1193 provider (window.ethereum).
 * Throws a descriptive error if MetaMask is not installed.
 */
export function getProvider(): EIP1193Provider {
  if (typeof window === 'undefined' || !window.ethereum) {
    throw new Error(
      'MetaMask / Web3 Wallet is not installed. Please install the MetaMask browser extension from https://metamask.io to connect your wallet.'
    );
  }
  return window.ethereum;
}

// ─── Account Management ───────────────────────────────────────

/**
 * Prompts the user to connect their MetaMask wallet.
 * Opens the MetaMask modal and returns connected account addresses.
 *
 * @returns Promise resolving to an array of connected account addresses
 * @throws  If the user rejects the connection request or MetaMask is unavailable
 */
export async function requestAccounts(): Promise<string[]> {
  const provider = getProvider();

  const accounts = (await provider.request({
    method: 'eth_requestAccounts',
    params: [],
  })) as string[];

  if (!accounts || accounts.length === 0) {
    throw new Error('No accounts returned. The user may have rejected the connection request.');
  }

  return accounts;
}

/**
 * Returns already-connected accounts without triggering the MetaMask modal.
 * Returns an empty array if no accounts are connected.
 */
export async function getConnectedAccounts(): Promise<string[]> {
  if (typeof window === 'undefined' || !window.ethereum) {
    return [];
  }
  return (await window.ethereum.request({ method: 'eth_accounts' })) as string[];
}

// ─── Chain Management ─────────────────────────────────────────

/**
 * Returns the current network chain ID as a decimal number.
 * e.g. 1 for Mainnet, 11155111 for Sepolia.
 */
export async function getChainId(): Promise<number> {
  const provider = getProvider();
  const hexChainId = (await provider.request({ method: 'eth_chainId' })) as string;
  return parseInt(hexChainId, 16);
}

/**
 * Requests MetaMask to switch to the network specified in VITE_CHAIN_ID.
 * If the user rejects or the network isn't added, this will throw.
 */
export async function switchToConfiguredChain(): Promise<void> {
  const targetChainId = Number(import.meta.env.VITE_CHAIN_ID ?? 11155111);
  const provider = getProvider();

  try {
    await provider.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: `0x${targetChainId.toString(16)}` }],
    });
  } catch (err: unknown) {
    // If the network is not yet added to user's wallet, handle gracefully
    console.warn('Network switch prompt:', err);
  }
}

// ─── Address Utilities ────────────────────────────────────────

/**
 * Truncates a full Ethereum address for display.
 * e.g.  "0xA3f4...9b2E"
 *
 * @param address Full 42-character Ethereum address
 * @param chars   Number of characters to show on each side (default: 4)
 */
export function truncateAddress(address: string, chars = 4): string {
  if (!address || address.length < 10) return address;
  return `${address.slice(0, chars + 2)}...${address.slice(-chars)}`;
}
