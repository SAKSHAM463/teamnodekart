import React from 'react';
import { LockKeyhole, ArrowUpRight, Trash2, ShoppingBag, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatMoney } from '../mockData';

export const CartPage: React.FC = () => {
  const { cart, updateCartQuantity, removeFromCart, clearCart, navigate } = useApp();

  const totalItems        = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal          = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const expectedCashback  = Math.round(subtotal * 0.05);

  if (cart.length === 0) {
    return (
      <div className="max-w-[1200px] mx-auto px-[5%] py-20 text-center animate-rise">
        <ShoppingBag className="w-12 h-12 text-muted/60 mx-auto mb-4" />
        <h2 className="font-display font-semibold text-2xl text-ink mb-2">
          Your basket is empty
        </h2>
        <p className="text-muted text-xs max-w-sm mx-auto mb-6">
          Explore the community marketplace to find authentic products backed by SHARP escrow.
        </p>
        <button
          onClick={() => navigate('market')}
          className="bg-lime hover:bg-[#b8df5d] text-[#122016] py-3 px-6 rounded-[5px] font-extrabold text-xs inline-flex items-center gap-2 transition-colors shadow-lg"
        >
          <span>Explore marketplace</span>
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-[1200px] mx-auto px-[5%] py-10 sm:py-14 animate-rise">
      {/* Page Heading */}
      <div className="flex justify-between items-end mb-8 pb-4 border-b border-line">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-widest text-lime mb-1">
            Your basket
          </p>
          <h1 className="font-display font-semibold text-3xl sm:text-5xl text-ink">
            Ready when <em className="font-serif font-normal text-lime">you are.</em>
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <span className="font-mono text-xs text-muted">
            {totalItems} {totalItems === 1 ? 'item' : 'items'}
          </span>
          <button
            onClick={clearCart}
            className="text-muted hover:text-coral text-xs inline-flex items-center gap-1 transition-colors border border-line hover:border-coral/40 rounded px-2.5 py-1.5"
            title="Clear entire basket"
          >
            <X className="w-3 h-3" />
            <span>Clear all</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1.4fr_0.8fr] gap-10 lg:gap-14 items-start">
        {/* Cart Items List */}
        <div>
          <div className="divide-y divide-line">
            {cart.map(({ product, quantity }) => (
              <div
                key={product.id}
                className="py-5 flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-6"
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-20 h-20 object-cover rounded-md bg-[#202923] border border-line flex-shrink-0 cursor-pointer hover:opacity-80 transition-opacity"
                  onClick={() => navigate('product', product)}
                />

                <div className="flex-1 min-w-0">
                  <h3
                    onClick={() => navigate('product', product)}
                    className="font-display font-semibold text-base text-ink cursor-pointer hover:text-lime transition-colors truncate"
                  >
                    {product.name}
                  </h3>
                  <p className="text-muted text-xs mt-0.5 mb-1">
                    Sold by {product.seller}
                  </p>
                  <span className="font-mono text-[10px] text-lime bg-lime/10 border border-lime/20 rounded px-1.5 py-0.5">
                    {product.tag}
                  </span>
                  <strong className="font-mono text-xs text-lime block mt-2">
                    {formatMoney(product.price * quantity)}
                  </strong>
                </div>

                {/* Quantity Controls & Remove */}
                <div className="flex items-center gap-4 self-end sm:self-center">
                  <div className="flex items-center border border-line rounded bg-[#141b17]">
                    <button
                      onClick={() => updateCartQuantity(product.id, -1)}
                      className="w-7 h-8 text-muted hover:text-ink font-mono text-xs"
                    >
                      −
                    </button>
                    <span className="font-mono text-xs min-w-[20px] text-center text-ink font-bold">
                      {quantity}
                    </span>
                    <button
                      onClick={() => updateCartQuantity(product.id, 1)}
                      className="w-7 h-8 text-muted hover:text-ink font-mono text-xs"
                    >
                      +
                    </button>
                  </div>

                  <button
                    onClick={() => removeFromCart(product.id)}
                    className="p-1.5 text-muted hover:text-coral transition-colors"
                    title="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Continue Shopping */}
          <button
            onClick={() => navigate('market')}
            className="mt-4 text-muted hover:text-lime text-xs inline-flex items-center gap-1.5 transition-colors"
          >
            <ArrowUpRight className="w-3.5 h-3.5 rotate-[225deg]" />
            <span>Continue shopping</span>
          </button>

          {/* Escrow Note */}
          <div className="flex items-start gap-3 text-lime bg-[#16211a] border border-[#2c3d31] p-4 rounded-lg mt-6">
            <LockKeyhole className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <div>
              <b className="text-xs font-semibold block text-ink">
                Protected by Smart Escrow
              </b>
              <span className="text-muted text-[11px] block mt-0.5">
                Funds are only released to sellers after delivery is safely confirmed by you.
                5% cashback is minted automatically upon settlement.
              </span>
            </div>
          </div>
        </div>

        {/* Order Summary Sidebar */}
        <aside className="bg-panel border border-line rounded-lg p-6 sticky top-24 shadow-xl">
          <h3 className="font-display font-semibold text-lg text-ink mb-6">
            Order summary
          </h3>

          <div className="space-y-3.5 text-xs text-muted">
            <div className="flex justify-between items-center">
              <span>Subtotal ({totalItems} {totalItems === 1 ? 'item' : 'items'})</span>
              <b className="font-mono text-ink text-xs">{formatMoney(subtotal)}</b>
            </div>

            <div className="flex justify-between items-center">
              <span>Shipping</span>
              <b className="text-lime font-mono text-xs">Free</b>
            </div>

            <div className="flex justify-between items-center">
              <span>Expected cashback</span>
              <b className="text-lime font-mono text-xs">+{formatMoney(expectedCashback)}</b>
            </div>

            <hr className="border-line my-4" />

            <div className="flex justify-between items-center text-ink text-sm font-semibold">
              <span>Total</span>
              <b className="font-mono text-base text-ink">{formatMoney(subtotal)}</b>
            </div>
          </div>

          <button
            onClick={() => navigate('checkout')}
            className="w-full bg-lime hover:bg-[#b8df5d] text-[#122016] py-3.5 px-4 rounded-[5px] font-extrabold text-xs inline-flex items-center justify-center gap-2 transition-colors mt-6 shadow-lg"
          >
            <span>Proceed to checkout</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>

          <p className="text-muted text-[10px] text-center mt-3 font-mono">
            SHARP escrow · Zero platform fee · On-chain settlement
          </p>
        </aside>
      </div>
    </div>
  );
};
