﻿import React from 'react';
import {
  ArrowUpRight,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  LockKeyhole,
  ScanEye,
  Sparkles,
  WalletCards,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ProductCard } from '../components/ProductCard';

export const HomePage: React.FC = () => {
  const { navigate, connectWallet, openModal, products } = useApp();

  const flowSteps = [
    'Buy',
    'Pay with SHARP',
    'Escrow',
    'Delivery',
    'Settlement',
    'Cashback',
  ];

  return (
    <div className="animate-rise">
      {/* Hero Section */}
      <section className="min-h-[580px] lg:min-h-[640px] px-[6%] lg:px-[8%] py-16 lg:py-20 grid grid-cols-1 lg:grid-cols-[1.1fr_0.9fr] gap-12 lg:gap-16 items-center bg-[radial-gradient(circle_at_82%_34%,#1f3b2b_0,transparent_38%),linear-gradient(120deg,#101512,#131b16)]">
        {/* Left Copy */}
        <div>
          <p className="font-mono text-[10px] uppercase tracking-widest text-lime mb-5 flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-coral shadow-[0_0_0_4px_rgba(255,139,106,0.2)] animate-pulse" />
            The marketplace with a proof layer
          </p>

          <h1 className="font-display font-semibold text-4xl sm:text-5xl lg:text-7xl leading-[0.96] tracking-tighter text-ink">
            Buy directly.<br />
            <em className="font-serif font-normal text-lime tracking-normal">Pay securely.</em><br />
            Own your transaction.
          </h1>

          <p className="text-muted text-sm sm:text-base leading-relaxed max-w-[440px] my-7">
            A better way to buy from real people. SHARP payments stay protected in escrow until the exchange is complete.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => navigate('market')}
              className="bg-lime hover:bg-[#b8df5d] text-[#122016] py-3 px-5 rounded-[5px] font-extrabold text-xs inline-flex items-center gap-2.5 transition-colors shadow-lg shadow-lime/10"
            >
              <span>Explore marketplace</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>

            <button
              onClick={connectWallet}
              className="bg-transparent hover:border-lime border border-line text-ink py-3 px-4 rounded-[5px] text-xs font-semibold inline-flex items-center gap-2.5 transition-colors"
            >
              <WalletCards className="w-4 h-4 text-lime" />
              <span>Connect wallet</span>
            </button>
          </div>

          <div className="flex items-center gap-2.5 mt-10 text-xs text-ink">
            <ShieldCheck className="w-5 h-5 text-lime flex-shrink-0" />
            <div>
              <b className="font-semibold block text-xs">Protected by escrow</b>
              <small className="font-mono text-[9px] text-muted block">
                Transparent settlement when it matters.
              </small>
            </div>
          </div>
        </div>

        {/* Right Visual */}
        <div className="relative max-w-[480px] w-full mx-auto">
          <div className="h-[340px] sm:h-[400px] relative rounded-xl overflow-hidden border border-white/10 shadow-[18px_18px_0_#213d2d]">
            <img
              src="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=1200&q=90"
              alt="NodeKart protected order delivery"
              className="w-full h-full object-cover saturate-[0.7] contrast-[1.05]"
            />

            {/* Floating Order Card */}
            <div className="absolute bottom-5 left-5 right-5 sm:right-auto bg-[#f0f3eb] text-[#18221c] p-3.5 flex items-center gap-3 rounded-md shadow-2xl min-w-[210px]">
              <CheckCircle2 className="w-5 h-5 text-green flex-shrink-0" />
              <div>
                <small className="block text-muted text-[9px]">Order secured</small>
                <b className="block text-xs font-display font-bold">42,500 SHARP</b>
              </div>
              <span className="ml-auto bg-[#daf49a] text-[#315927] py-1 px-2 font-mono text-[9px] font-bold rounded">
                Escrow
              </span>
            </div>
          </div>

          {/* Floating Stats */}
          <div className="absolute -top-4 -right-4 sm:-right-6 bg-lime text-[#19231b] py-2.5 px-3.5 rounded-[5px] flex items-center gap-2 shadow-xl">
            <b className="font-display font-bold text-xl leading-none">98%</b>
            <span className="text-[10px] leading-tight font-medium">
              successful<br />deliveries
            </span>
          </div>

          <div className="absolute -bottom-4 -left-4 sm:-left-6 bg-[#202c25] border border-line text-ink py-2.5 px-3.5 rounded-[5px] flex items-center gap-2 shadow-xl">
            <span className="text-lime text-xs">●</span>
            <span className="text-[10px] leading-tight">
              Settlement<br />you can verify
            </span>
          </div>
        </div>
      </section>

      {/* Flow Section */}
      <section className="py-7 px-[6%] lg:px-[8%] border-y border-line bg-[#141b17]">
        <div className="max-w-[1200px] mx-auto flex flex-col md:flex-row items-start md:items-center gap-5 md:gap-10">
          <span className="font-mono text-[10px] uppercase tracking-widest text-lime whitespace-nowrap">
            How a NodeKart order works
          </span>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 w-full">
            {flowSteps.map((step, idx) => (
              <div
                key={idx}
                className="flex items-center gap-2 text-[11px] text-ink font-medium bg-[#1a231e]/70 p-2 rounded border border-line/40"
              >
                <span className="font-mono text-[9px] text-lime font-bold">
                  0{idx + 1}
                </span>
                <b className="truncate text-[11px] font-medium">{step}</b>
                {idx < 5 && (
                  <ArrowRight className="w-3 h-3 text-[#617068] ml-auto hidden lg:block" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Value Proposition Section */}
      <section className="max-w-[1200px] mx-auto py-16 sm:py-24 px-[5%]">
        <div className="mb-12">
          <p className="font-mono text-[10px] uppercase tracking-widest text-lime mb-2">
            Commerce, with less uncertainty
          </p>
          <h2 className="font-display font-semibold text-3xl sm:text-5xl tracking-tighter text-ink">
            The useful parts of<br />
            <em className="font-serif font-normal text-lime">blockchain, quietly.</em>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Card 1: Lime */}
          <div className="p-7 bg-lime text-[#162019] rounded-lg flex flex-col justify-between min-h-[260px] shadow-lg">
            <LockKeyhole className="w-6 h-6 text-[#162019]" />
            <div>
              <h3 className="font-display font-semibold text-xl mt-10 mb-2">
                Secure escrow
              </h3>
              <p className="text-[#50634b] text-xs leading-relaxed max-w-[260px]">
                Funds remain protected until predefined delivery conditions are met.
              </p>
            </div>
            <button
              onClick={() => navigate('orders')}
              className="inline-flex items-center gap-1.5 font-bold text-xs mt-4 hover:underline text-left"
            >
              <span>See the journey</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 2: Dark */}
          <div className="p-7 bg-[#1b2720] border border-line text-ink rounded-lg flex flex-col justify-between min-h-[260px]">
            <ScanEye className="w-6 h-6 text-lime" />
            <div>
              <h3 className="font-display font-semibold text-xl mt-10 mb-2 text-ink">
                Transparent transactions
              </h3>
              <p className="text-muted text-xs leading-relaxed max-w-[260px]">
                Important payment, escrow and settlement events stay verifiable.
              </p>
            </div>
            <button
              onClick={() => openModal('proof')}
              className="inline-flex items-center gap-1.5 font-bold text-xs mt-4 text-lime hover:text-ink transition-colors text-left"
            >
              <span>View a proof</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 3: Neutral Panel */}
          <div className="p-7 bg-[#1a231e] border border-line text-ink rounded-lg flex flex-col justify-between min-h-[260px]">
            <Sparkles className="w-6 h-6 text-lime" />
            <div>
              <h3 className="font-display font-semibold text-xl mt-10 mb-2 text-ink">
                Earn SHARP
              </h3>
              <p className="text-muted text-xs leading-relaxed max-w-[260px]">
                Get cashback from completed orders and earn through referrals.
              </p>
            </div>
            <button
              onClick={() => navigate('rewards')}
              className="inline-flex items-center gap-1.5 font-bold text-xs mt-4 text-lime hover:text-ink transition-colors text-left"
            >
              <span>Explore rewards</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* Market Preview */}
      <section className="max-w-[1200px] mx-auto pb-24 px-[5%]">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 mb-8">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-widest text-lime mb-1">
              Fresh from the community
            </p>
            <h2 className="font-display font-semibold text-3xl sm:text-4xl tracking-tight text-ink">
              Good things, <em className="font-serif font-normal text-lime">well sourced.</em>
            </h2>
          </div>

          <button
            onClick={() => navigate('market')}
            className="border border-line hover:border-lime text-ink text-xs font-semibold py-2.5 px-4 rounded-[5px] inline-flex items-center gap-2 transition-colors"
          >
            <span>View all products</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-lime" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {products.slice(0, 4).map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>
    </div>
  );
};
