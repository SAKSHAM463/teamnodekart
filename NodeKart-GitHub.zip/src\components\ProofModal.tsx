import React from 'react';
import { X, ShieldCheck, CheckCircle2, Copy, Check, Radio, ExternalLink } from 'lucide-react';
import { CONTRACTS } from '../contracts/deployed';
import { useApp } from '../context/AppContext';

export const ProofModal: React.FC = () => {
  const { activeModal, closeModal, showToast, orderState, getExplorerUrl } = useApp();

  if (activeModal !== 'proof') return null;

  const txHash = orderState.escrowTxHash || '0x7a3f9d82e1c94b2a8d4f019b8417c8e92d71fa9109b837e24817a8e291fd01bc';

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard?.writeText(text);
    showToast(`${label} copied to clipboard`);
  };

  const events = [
    { name: 'Dual-Deposit Initialized', status: 'Seller 10% Collateral Locked' },
    { name: 'Buyer Deposit Locked', status: 'Item Price + 5% Collateral' },
    { name: 'Carrier Tracking Registered', status: `Dispatched · ${orderState.trackingNumber}` },
    { name: 'Chainlink DON Consensus', status: orderState.delivered ? 'Delivery Verified' : 'Awaiting Delivery' },
    { name: '5% SHARP Cashback Minted', status: orderState.settled ? '+1,250 SHARP Minted' : 'Pending Settlement' },
    { name: 'ERC-5192 Soulbound Updated', status: orderState.settled ? 'Reputation SBT Issued' : 'Pending Settlement' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-[#050806]/85 backdrop-blur-sm grid place-items-center p-4">
      <div className="relative w-full max-w-[560px] bg-[#17211b] border border-[#3d5542] rounded-lg p-6 sm:p-7 shadow-[0_25px_80px_rgba(0,0,0,0.6)] animate-rise text-ink max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={closeModal}
          className="absolute top-5 right-5 text-muted hover:text-ink transition-colors p-1"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 pr-8">
          <div className="w-[42px] h-[42px] rounded-full bg-lime text-[#172219] grid place-items-center flex-shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <p className="font-mono text-[10px] text-lime uppercase tracking-widest mb-0.5">
              Settlement record
            </p>
            <h2 className="font-display font-semibold text-2xl text-ink">
              Blockchain proof
            </h2>
          </div>
          <span className="ml-auto flex items-center gap-1 text-lime font-mono text-[9px] bg-[#233626] border border-[#47653d] px-2 py-1 rounded">
            <CheckCircle2 className="w-3 h-3" /> Confirmed
          </span>
        </div>

        <p className="text-muted text-[10px] leading-relaxed my-4">
          On-chain verification record for NodeKart Smart Contracts. Every step is cryptographically attested and enforced via Solidity smart contracts.
        </p>

        {/* Tx Hash Row */}
        <div className="bg-[#202c25] p-3 rounded flex items-center justify-between gap-2 border border-line mb-3">
          <span className="text-muted text-[9px]">Transaction hash</span>
          <b className="font-mono text-[10px] text-ink truncate max-w-[240px]">
            {txHash}
          </b>
          <div className="flex items-center gap-1">
            <button
              onClick={() => handleCopy(txHash, 'Transaction hash')}
              className="text-lime hover:text-ink transition-colors p-1"
              title="Copy transaction hash"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>
            <a
              href={getExplorerUrl(txHash)}
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted hover:text-lime transition-colors p-1"
              title="View on Explorer"
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Contract Addresses Grid */}
        <div className="grid grid-cols-2 gap-3 py-3 border-y border-line text-[10px]">
          <div>
            <span className="text-muted text-[9px] block">NodeKartEscrow</span>
            <b className="font-mono text-[9px] text-lime truncate block mt-0.5" title={CONTRACTS.NodeKartEscrow.address}>
              {CONTRACTS.NodeKartEscrow.address.slice(0, 10)}...{CONTRACTS.NodeKartEscrow.address.slice(-6)}
            </b>
          </div>
          <div>
            <span className="text-muted text-[9px] block">SHARPToken (ERC-20)</span>
            <b className="font-mono text-[9px] text-lime truncate block mt-0.5" title={CONTRACTS.SHARPToken.address}>
              {CONTRACTS.SHARPToken.address.slice(0, 10)}...{CONTRACTS.SHARPToken.address.slice(-6)}
            </b>
          </div>
          <div>
            <span className="text-muted text-[9px] block">Reputation SBT (ERC-5192)</span>
            <b className="font-mono text-[9px] text-lime truncate block mt-0.5" title={CONTRACTS.NodeKartReputationSBT.address}>
              {CONTRACTS.NodeKartReputationSBT.address.slice(0, 10)}...{CONTRACTS.NodeKartReputationSBT.address.slice(-6)}
            </b>
          </div>
          <div>
            <span className="text-muted text-[9px] block">Chainlink DON Oracle</span>
            <b className="font-mono text-[9px] text-lime truncate block mt-0.5" title={CONTRACTS.MockChainlinkOracle.address}>
              {CONTRACTS.MockChainlinkOracle.address.slice(0, 10)}...{CONTRACTS.MockChainlinkOracle.address.slice(-6)}
            </b>
          </div>
        </div>

        {/* Events List */}
        <h3 className="font-display font-semibold text-[13px] mt-4 mb-2.5 text-ink">
          Verifiable State Transitions
        </h3>
        <div className="grid gap-2 text-[10px]">
          {events.map((evt, idx) => (
            <div
              key={idx}
              className="flex items-center gap-2 bg-[#141b17] p-2 rounded border border-line/60"
            >
              <Check className="w-3.5 h-3.5 text-lime flex-shrink-0" />
              <b className="font-medium text-ink">{evt.name}</b>
              <small className="text-muted ml-auto font-mono text-[9px]">
                {evt.status}
              </small>
            </div>
          ))}
        </div>

        {/* Network Proof Footer */}
        <div className="bg-[#233626] text-lime p-3 rounded mt-4 text-[10px] flex items-start gap-2 border border-[#47653d]">
          <Radio className="w-4 h-4 flex-shrink-0 mt-0.5" />
          <div>
            <b>Verified on EVM Network (Chain ID: 31337 / L2 Ready)</b>
            <small className="block text-[#9cb39b] text-[8px] mt-0.5">
              Dual-deposit collateral secured · Chainlink delivery attestation · ERC-5192 Soulbound verified
            </small>
          </div>
        </div>
      </div>
    </div>
  );
};
