import hardhat from "hardhat";

async function main() {
  const connection = await hardhat.network.connect();
  console.log("connection keys:", Object.keys(connection));
  console.log("connection provider:", connection.provider);
}

main().catch(console.error);
