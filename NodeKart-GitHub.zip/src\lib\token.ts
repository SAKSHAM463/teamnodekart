// ─────────────────────────────────────────────────────────────
//  src/lib/token.ts
//  Interactions with the native ERC-20 SHARPToken contract.
// ─────────────────────────────────────────────────────────────

import { BrowserProvider, Contract, formatEther, parseEther, type Eip1193Provider } from 'ethers';
import { getProvider } from './wallet';
import { CONTRACTS } from '../contracts/deployed';
import type { TxResult } from '../contracts/escrow.types';

export const SHARP_TOKEN_ADDRESS = CONTRACTS.SHARPToken.address;

async function getSignerAndContract() {
  const provider = getProvider();
  const ethersProvider = new BrowserProvider(provider as unknown as Eip1193Provider);
  const signer = await ethersProvider.getSigner();
  const contract = new Contract(SHARP_TOKEN_ADDRESS, CONTRACTS.SHARPToken.abi, signer);
  return { signer, contract, ethersProvider };
}

/**
 * Gets SHARP token balance for any address in human-readable format
 */
export async function getSharpBalance(userAddress: string): Promise<string> {
  try {
    const provider = getProvider();
    const ethersProvider = new BrowserProvider(provider as unknown as Eip1193Provider);
    const contract = new Contract(SHARP_TOKEN_ADDRESS, CONTRACTS.SHARPToken.abi, ethersProvider);
    const bal = await contract['balanceOf'](userAddress);
    return formatEther(bal);
  } catch (err) {
    console.warn('Could not fetch on-chain SHARP balance:', err);
    return '0';
  }
}

/**
 * Checks current SHARP allowance for a spender (e.g. NodeKartEscrow)
 */
export async function getSharpAllowance(owner: string, spender: string): Promise<bigint> {
  try {
    const provider = getProvider();
    const ethersProvider = new BrowserProvider(provider as unknown as Eip1193Provider);
    const contract = new Contract(SHARP_TOKEN_ADDRESS, CONTRACTS.SHARPToken.abi, ethersProvider);
    return await contract['allowance'](owner, spender);
  } catch (err) {
    console.warn('Could not fetch SHARP allowance:', err);
    return 0n;
  }
}

/**
 * Approves a spender (NodeKartEscrow) to transfer SHARP tokens
 */
export async function approveSharp(spenderAddress: string, amountFormatted?: string): Promise<TxResult> {
  const { contract } = await getSignerAndContract();
  const amount = amountFormatted ? parseEther(amountFormatted) : parseEther('1000000000'); // Max default
  const tx = await contract['approve'](spenderAddress, amount);
  const receipt = await tx.wait(1);
  return {
    txHash: receipt.hash,
    blockNumber: receipt.blockNumber,
  };
}

/**
 * Requests testnet SHARP tokens from the contract faucet
 */
export async function claimFaucet(recipientAddress: string, amountFormatted = '10000'): Promise<TxResult> {
  const { contract } = await getSignerAndContract();
  const amount = parseEther(amountFormatted);
  const tx = await contract['mintFaucet'](recipientAddress, amount);
  const receipt = await tx.wait(1);
  return {
    txHash: receipt.hash,
    blockNumber: receipt.blockNumber,
  };
}
