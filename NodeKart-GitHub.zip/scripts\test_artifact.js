import hardhat from "hardhat";
import { ethers } from "ethers";

async function main() {
  console.log("Reading artifact for SHARPToken...");
  const sharpArtifact = await hardhat.artifacts.readArtifact("SHARPToken");
  console.log("SHARPToken artifact loaded with", sharpArtifact.abi.length, "ABI items.");
}

main().catch(console.error);
