// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

/**
 * @title SHARPToken
 * @notice The native ERC-20 utility and settlement token for the NodeKart decentralized marketplace.
 * Powers peer-to-peer escrow payments, collateral deposits, and programmatic 5% cashback rewards.
 */
contract SHARPToken is ERC20, ERC20Burnable, Ownable {

    /// @notice Addresses authorized to mint programmatic cashback rewards (e.g. NodeKartEscrow)
    mapping(address => bool) public isMinter;

    /// @notice Maximum allowed faucet mint per request on testnets (50,000 SHARP)
    uint256 public constant FAUCET_LIMIT = 50_000 * 10**18;

    event MinterUpdated(address indexed minter, bool authorized);
    event CashbackMinted(address indexed recipient, uint256 amount);
    event FaucetMinted(address indexed recipient, uint256 amount);

    modifier onlyMinter() {
        require(isMinter[msg.sender] || msg.sender == owner(), "SHARPToken: caller is not an authorized minter");
        _;
    }

    /**
     * @param initialOwner Address of the platform treasury / initial owner
     */
    constructor(address initialOwner) ERC20("SHARP Token", "SHARP") Ownable(initialOwner) {
        // Mint initial supply of 10,000,000 SHARP to the platform treasury
        _mint(initialOwner, 10_000_000 * 10**decimals());
    }

    /**
     * @notice Grants or revokes permission for a smart contract (e.g., NodeKartEscrow) to mint cashback
     */
    function setMinter(address minter, bool authorized) external onlyOwner {
        require(minter != address(0), "SHARPToken: zero address");
        isMinter[minter] = authorized;
        emit MinterUpdated(minter, authorized);
    }

    /**
     * @notice Programmatically mints 5% cashback to the buyer upon verified escrow settlement
     */
    function mintCashback(address to, uint256 amount) external onlyMinter {
        require(to != address(0), "SHARPToken: cannot mint to zero address");
        _mint(to, amount);
        emit CashbackMinted(to, amount);
    }

    /**
     * @notice Testnet faucet function enabling seamless onboarding for testing
     */
    function mintFaucet(address to, uint256 amount) external {
        require(to != address(0), "SHARPToken: cannot mint to zero address");
        require(amount <= FAUCET_LIMIT, "SHARPToken: amount exceeds faucet limit");
        _mint(to, amount);
        emit FaucetMinted(to, amount);
    }
}
