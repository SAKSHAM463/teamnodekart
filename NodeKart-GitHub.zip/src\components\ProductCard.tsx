import React, { useState } from 'react';
import { BadgeCheck, ShieldCheck, Heart, ArrowUpRight, FileText } from 'lucide-react';
import { Product, formatMoney, formatINR } from '../mockData';
import { useApp } from '../context/AppContext';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { navigate, showToast } = useApp();
  const [isLiked, setIsLiked] = useState(false);

  const handleHeartClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsLiked(!isLiked);
    showToast(isLiked ? 'Removed from saved items' : 'Saved to wishlist');
  };

  return (
    <article className="min-w-0 flex flex-col group animate-rise">
      {/* Product Image Container */}
      <div
        onClick={() => navigate('product', product)}
        className="h-[245px] w-full bg-[#252d28] relative overflow-hidden rounded-[7px] cursor-pointer border border-line/40 group-hover:border-lime/40 transition-colors"
      >
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 saturate-[0.82]"
          loading="lazy"
        />

        {/* Product Tag */}
        <span className="absolute left-2.5 top-2.5 bg-lime text-[#142118] py-1 px-2 font-mono text-[9px] font-bold rounded-[3px] shadow-sm">
          {product.tag}
        </span>

        {/* NEW badge for freshly listed products */}
        {product.id.startsWith('item-') && (
          <span className="absolute left-2.5 top-8 mt-1.5 bg-coral text-white py-0.5 px-2 font-mono text-[8px] font-bold rounded-[3px] shadow-sm">
            NEW
          </span>
        )}

        {/* Heart Bookmark */}
        <button
          onClick={handleHeartClick}
          className={`absolute right-2.5 top-2.5 w-[27px] h-[27px] rounded-full grid place-items-center transition-all ${
            isLiked
              ? 'bg-coral text-white scale-110 shadow-md'
              : 'bg-[#f3f5ed] text-[#162019] hover:scale-105'
          }`}
          aria-label="Wishlist item"
        >
          <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-current' : ''}`} />
        </button>
      </div>

      {/* Product Info */}
      <div className="py-3 px-0.5 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-center text-muted font-mono text-[9px] uppercase tracking-wider">
            <span>{product.category}</span>
            <span className="text-coral font-medium">★ {product.rating}</span>
          </div>

          <h3
            onClick={() => navigate('product', product)}
            className="font-display font-semibold text-[14px] text-ink mt-2 mb-1.5 line-clamp-1 cursor-pointer hover:text-lime transition-colors"
          >
            {product.name}
          </h3>

          <p className="text-muted text-[10px] flex items-center gap-1">
            <span>{product.seller}</span>
            <BadgeCheck className="w-3 h-3 text-lime" />
          </p>
        </div>

        <div>
          {/* Price & Action */}
          <div className="border-t border-line mt-3.5 pt-2.5 flex justify-between items-end gap-1.5">
            <div>
              <strong className="font-display font-semibold text-[12px] text-ink block">
                {formatMoney(product.price)}
              </strong>
              <small className="font-mono text-[9px] text-muted block mt-0.5">
                {formatINR(product.price)}
              </small>
            </div>

            <button
              onClick={() => navigate('product', product)}
              className="text-lime hover:text-ink text-[10px] font-bold inline-flex items-center gap-1 transition-colors whitespace-nowrap"
            >
              <span>View item</span>
              <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>

          {/* Badges */}
          <div className="flex flex-wrap gap-1.5 mt-2.5">
            <span className="text-[#839087] border border-line py-0.5 px-1.5 font-mono text-[8px] flex items-center gap-1 rounded-[3px] bg-[#141b17]">
              <BadgeCheck className="w-2.5 h-2.5 text-lime" />
              Verified seller
            </span>

            {product.blockchain && (
              <span className="text-[#839087] border border-line py-0.5 px-1.5 font-mono text-[8px] flex items-center gap-1 rounded-[3px] bg-[#141b17]">
                <ShieldCheck className="w-2.5 h-2.5 text-lime" />
                Proof available
              </span>
            )}

            {product.billUrl && (
              <span className="text-[#839087] border border-lime/30 py-0.5 px-1.5 font-mono text-[8px] flex items-center gap-1 rounded-[3px] bg-lime/5">
                <FileText className="w-2.5 h-2.5 text-lime" />
                Verified bill
              </span>
            )}
          </div>
        </div>
      </div>
    </article>
  );
};
