﻿import React from 'react';
import { Copy, Sparkles, Users, TrendingUp, ArrowUpRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { INITIAL_USER, HOW_REFERRALS_WORK } from '../mockData';

export const ReferralsPage: React.FC = () => {
  const { navigate, showToast } = useApp();

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(`https://${INITIAL_USER.referralLink}`);
    showToast('Referral link copied to clipboard');
  };

  return (
    <div className="max-w-[1200px] mx-auto px-[5%] py-10 sm:py-14 animate-rise">
      {/* Page Heading */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-6 mb-10 pb-6 border-b border-line">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-widest text-lime mb-2">
            NodeKart referrals
          </p>
          <h1 className="font-display font-semibold text-3xl sm:text-5xl text-ink">
            Invite. Shop. Earn.<br />
            <em className="font-serif font-normal text-lime">with your circle.</em>
          </h1>
          <p className="text-muted text-xs sm:text-sm mt-2 max-w-[480px]">
            Bring your community to a peer-to-peer marketplace built on verifiable escrow and shared rewards.
          </p>
        </div>

        <div className="border-l-2 border-line pl-6">
          <span className="font-mono text-[9px] uppercase tracking-widest text-muted block mb-1">
            Your referral link
          </span>
          <strong className="font-display font-bold text-lg sm:text-xl text-ink block mb-3 font-mono">
            {INITIAL_USER.referralLink}
          </strong>
          <button
            onClick={handleCopyLink}
            className="bg-lime hover:bg-[#b8df5d] text-[#122016] font-bold text-xs py-2 px-3.5 rounded inline-flex items-center gap-1.5 transition-colors shadow"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>Copy link</span>
          </button>
        </div>
      </div>

      {/* Metric Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10">
        <div className="border border-line rounded-lg p-5 bg-panel">
          <span className="text-muted text-xs flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-lime" />
            Total referral income
          </span>
          <strong className="font-display font-bold text-2xl text-ink block my-3">
            1,250 SHARP
          </strong>
          <small className="text-muted text-[11px] block">
            Across 5 successful purchases
          </small>
        </div>

        <div className="border border-line rounded-lg p-5 bg-panel">
          <span className="text-muted text-xs flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-lime" />
            Active referrals
          </span>
          <strong className="font-display font-bold text-2xl text-ink block my-3">
            8 friends
          </strong>
          <small className="text-muted text-[11px] block">
            3 registered, 5 purchased
          </small>
        </div>

        <div className="border border-line rounded-lg p-5 bg-panel">
          <span className="text-muted text-xs flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-lime" />
            Conversion rate
          </span>
          <strong className="font-display font-bold text-2xl text-lime block my-3">
            62.5%
          </strong>
          <small className="text-muted text-[11px] block">
            High quality peer network
          </small>
        </div>
      </div>

      {/* Split Section */}
      <div className="grid grid-cols-1 lg:grid-cols-[1.2fr_0.8fr] gap-6">
        {/* How It Works */}
        <div className="border border-line rounded-lg p-6 bg-panel">
          <h2 className="font-display font-semibold text-xl text-ink mb-4">
            How it works
          </h2>
          <div className="divide-y divide-line">
            {HOW_REFERRALS_WORK.map((text, idx) => (
              <div key={idx} className="py-3.5 flex items-center gap-3">
                <span className="font-mono text-xs text-lime font-bold w-6">
                  0{idx + 1}
                </span>
                <div className="flex-1 min-w-0">
                  <b className="text-xs font-semibold text-ink block">
                    {text}
                  </b>
                  <small className="text-[10px] text-muted block mt-0.5">
                    Rewards arrive instantly as each transaction settles.
                  </small>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Activity Summary */}
        <div className="bg-[#21372a] border border-[#3d5940] rounded-lg p-7 flex flex-col justify-between">
          <div>
            <span className="font-mono text-[9px] uppercase tracking-widest text-lime block">
              Referral status
            </span>
            <h2 className="font-display font-semibold text-2xl sm:text-3xl text-ink mt-3 mb-2">
              8 friends joined.
            </h2>
            <p className="text-[#b6c7b5] text-xs sm:text-sm leading-relaxed mt-3">
              When your referred contacts complete their purchase with smart escrow, you both earn SHARP tokens automatically.
            </p>
          </div>

          <button
            onClick={() => navigate('market')}
            className="border border-[#506e50] hover:border-lime text-ink text-xs font-bold py-3 px-4 rounded inline-flex items-center justify-center gap-2 transition-colors mt-8 bg-[#182a20]"
          >
            <span>Explore marketplace</span>
            <ArrowUpRight className="w-4 h-4 text-lime" />
          </button>
        </div>
      </div>
    </div>
  );
};
