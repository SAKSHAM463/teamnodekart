import hardhat from "hardhat";
import { ethers } from "ethers";

async function main() {
  const connection = await hardhat.network.connect();
  const provider = new ethers.BrowserProvider(connection.provider);
  const signer = await provider.getSigner(0);
  const ownerAddress = await signer.getAddress();
  console.log("Deployer address:", ownerAddress);

  // Read artifact
  const sharpArtifact = await hardhat.artifacts.readArtifact("SHARPToken");
  const factory = new ethers.ContractFactory(sharpArtifact.abi, sharpArtifact.bytecode, signer);
  const sharpToken = await factory.deploy(ownerAddress);
  await sharpToken.waitForDeployment();
  const tokenAddress = await sharpToken.getAddress();
  console.log("SHARPToken deployed at:", tokenAddress);

  const name = await sharpToken.name();
  const symbol = await sharpToken.symbol();
  const balance = await sharpToken.balanceOf(ownerAddress);
  console.log(`Token: ${name} (${symbol})`);
  console.log(`Owner balance: ${ethers.formatEther(balance)} SHARP`);
}

main().catch(console.error);
