// ─────────────────────────────────────────────────────────────
//  src/components/Header.tsx
// ─────────────────────────────────────────────────────────────

import React from 'react';
import { Menu, X, WalletCards, ShoppingBag } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Header: React.FC = () => {
  const {
    page,
    navigate,
    walletBalance,
    walletAddress,
    isWalletConnected,
    isWalletLoading,
    connectWallet,
    truncateAddress,
    cart,
    activeModal,
    openModal,
    closeModal,
  } = useApp();

  const isMarketActive  = ['market', 'product'].includes(page);
  const totalCartCount  = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Show truncated real address when connected, generic label otherwise
  const walletLabel = isWalletConnected && walletAddress
    ? truncateAddress(walletAddress)
    : 'Connect wallet';

  return (
    <>
      <header className="h-[78px] border-b border-line flex items-center justify-between px-[5.5%] sticky top-0 z-40 bg-[#101512]/95 backdrop-blur-md">
        {/* Brand */}
        <button
          onClick={() => navigate('home')}
          className="flex items-center gap-2 font-display font-bold text-[19px] tracking-tight text-ink hover:opacity-90 transition-opacity"
        >
          <span className="grid place-items-center w-[29px] h-[29px] rounded-[9px] bg-lime text-[#102016] font-serif font-bold text-[18px]">
            N
          </span>
          <span>
            node<span className="text-lime">.</span>kart
          </span>
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6 md:gap-7 ml-[4%] text-muted text-xs font-medium">
          <button
            onClick={() => navigate('market')}
            className={`py-6 relative transition-colors ${
              isMarketActive ? 'text-ink font-semibold' : 'hover:text-ink'
            }`}
          >
            Marketplace
            {isMarketActive && (
              <span className="h-[3px] w-[3px] rounded-full bg-lime absolute bottom-4 left-1/2 -translate-x-1/2" />
            )}
          </button>

          <button
            onClick={() => { navigate('market'); }}
            className="py-6 hover:text-ink transition-colors"
          >
            Categories
          </button>

          <button
            onClick={() => navigate('list')}
            className={`py-6 relative transition-colors ${
              page === 'list' ? 'text-ink font-semibold' : 'hover:text-ink'
            }`}
          >
            List item
            {page === 'list' && (
              <span className="h-[3px] w-[3px] rounded-full bg-lime absolute bottom-4 left-1/2 -translate-x-1/2" />
            )}
          </button>

          <button
            onClick={() => navigate('orders')}
            className={`py-6 relative transition-colors ${
              page === 'orders' ? 'text-ink font-semibold' : 'hover:text-ink'
            }`}
          >
            Orders
            {page === 'orders' && (
              <span className="h-[3px] w-[3px] rounded-full bg-lime absolute bottom-4 left-1/2 -translate-x-1/2" />
            )}
          </button>

          <button
            onClick={() => navigate('rewards')}
            className={`py-6 relative transition-colors ${
              page === 'rewards' ? 'text-ink font-semibold' : 'hover:text-ink'
            }`}
          >
            Rewards
            {page === 'rewards' && (
              <span className="h-[3px] w-[3px] rounded-full bg-lime absolute bottom-4 left-1/2 -translate-x-1/2" />
            )}
          </button>

          <button
            onClick={() => navigate('referrals')}
            className={`py-6 relative transition-colors ${
              page === 'referrals' ? 'text-ink font-semibold' : 'hover:text-ink'
            }`}
          >
            Referrals
            {page === 'referrals' && (
              <span className="h-[3px] w-[3px] rounded-full bg-lime absolute bottom-4 left-1/2 -translate-x-1/2" />
            )}
          </button>

          <button
            onClick={() => navigate('seller')}
            className={`py-6 relative transition-colors ${
              page === 'seller' ? 'text-ink font-semibold' : 'hover:text-ink'
            }`}
          >
            Sell
            {page === 'seller' && (
              <span className="h-[3px] w-[3px] rounded-full bg-lime absolute bottom-4 left-1/2 -translate-x-1/2" />
            )}
          </button>
        </nav>

        {/* Right Section */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          {/* Cart Icon */}
          <button
            onClick={() => navigate('cart')}
            className="relative p-2 text-muted hover:text-ink transition-colors"
            title="View Basket"
          >
            <ShoppingBag className="w-4 h-4" />
            {totalCartCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-lime text-[#102016] text-[9px] font-mono font-bold rounded-full grid place-items-center">
                {totalCartCount}
              </span>
            )}
          </button>

          {/* Balance Chip */}
          <button
            onClick={() => navigate('wallet')}
            className="hidden sm:flex items-center gap-1.5 bg-transparent border-r border-line pr-3 py-1.5 text-[11px] text-ink hover:text-lime transition-colors"
          >
            <span className="grid place-items-center w-5 h-5 bg-lime rounded-full text-[#102016] font-display font-bold text-[11px]">
              S
            </span>
            <b className="font-display font-semibold">{walletBalance.toLocaleString('en-IN')}</b>
            <small className="font-mono text-[9px] text-muted">SHARP</small>
          </button>

          {/* Wallet Button — shows connected address or connect prompt */}
          <button
            onClick={connectWallet}
            disabled={isWalletLoading}
            className={`hidden sm:inline-flex items-center gap-2 text-[11px] font-semibold py-2 px-3.5 rounded-[5px] border transition-colors disabled:opacity-60 ${
              isWalletConnected
                ? 'bg-[#1e2d22] border-lime text-lime hover:bg-[#253829]'
                : 'bg-[#202b25] hover:bg-[#283830] text-ink border-line hover:border-lime'
            }`}
          >
            {/* Green connected dot */}
            {isWalletConnected && (
              <span className="w-1.5 h-1.5 rounded-full bg-lime animate-pulse" />
            )}
            {!isWalletConnected && <WalletCards className="w-3.5 h-3.5 text-lime" />}
            <span>
              {isWalletLoading ? 'Connecting…' : walletLabel}
            </span>
          </button>

          {/* Profile Avatar */}
          <button
            onClick={() => navigate('profile')}
            className="w-[31px] h-[31px] rounded-full bg-[#d8c5a8] text-[#28251f] text-[10px] font-extrabold grid place-items-center hover:opacity-90 transition-opacity"
            title="Saksham Profile"
          >
            S
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => openModal('mobileMenu')}
            className="md:hidden p-2 text-muted hover:text-ink transition-colors"
            aria-label="Open navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Mobile Menu Drawer */}
      {activeModal === 'mobileMenu' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm md:hidden animate-rise">
          <div className="bg-panel border-b border-line p-6 flex flex-col gap-4">
            <div className="flex items-center justify-between pb-4 border-b border-line">
              <span className="font-display font-bold text-lg text-ink">Navigation</span>
              <button
                onClick={closeModal}
                className="p-1.5 text-muted hover:text-ink"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex flex-col gap-2 text-sm text-muted">
              {[
                { label: 'Home',                   page: 'home'      as const },
                { label: 'Marketplace',             page: 'market'    as const },
                { label: 'Sell an item',             page: 'list'      as const },
                { label: 'Orders & Escrow',          page: 'orders'    as const },
                { label: `Wallet (${walletBalance.toLocaleString('en-IN')} SHARP)`, page: 'wallet' as const },
                { label: 'Seller Dashboard',         page: 'seller'    as const },
                { label: 'Rewards & Cashback',       page: 'rewards'   as const },
                { label: 'Referrals',                page: 'referrals' as const },
                { label: 'Profile & Security',       page: 'profile'   as const },
              ].map(({ label, page: target }) => (
                <button
                  key={target}
                  onClick={() => navigate(target)}
                  className={`text-left py-2.5 px-3 rounded hover:bg-[#202b25] hover:text-ink ${
                    page === target ? 'text-lime font-bold bg-[#202b25]' : ''
                  }`}
                >
                  {label}
                </button>
              ))}

              {/* Wallet connect in mobile menu */}
              <button
                onClick={() => { connectWallet(); closeModal(); }}
                disabled={isWalletLoading}
                className={`text-left py-2.5 px-3 rounded border mt-2 flex items-center gap-2 text-xs font-semibold transition-colors disabled:opacity-60 ${
                  isWalletConnected
                    ? 'border-lime text-lime bg-[#1e2d22]'
                    : 'border-line hover:border-lime text-ink hover:bg-[#202b25]'
                }`}
              >
                {isWalletConnected && <span className="w-1.5 h-1.5 rounded-full bg-lime" />}
                {!isWalletConnected && <WalletCards className="w-3.5 h-3.5 text-lime" />}
                <span>{isWalletLoading ? 'Connecting…' : walletLabel}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
