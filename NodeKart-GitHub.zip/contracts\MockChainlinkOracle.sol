// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/Ownable.sol";

interface INodeKartEscrowOracleCallback {
    function oracleDeliveryFulfillment(uint256 escrowId, string calldata trackingNumber) external;
}

/**
 * @title MockChainlinkOracle
 * @notice Simulates a Chainlink Decentralized Oracle Network (DON) that queries
 * real-world carrier APIs (FedEx, DHL, UPS, BlueDart) to verify physical package delivery.
 */
contract MockChainlinkOracle is Ownable {

    enum CarrierStatus {
        NotFound,       // 0
        InTransit,      // 1
        OutForDelivery, // 2
        Delivered,      // 3
        Exception       // 4
    }

    struct TrackingRecord {
        CarrierStatus status;
        string carrier;
        uint256 lastUpdated;
        uint256 deliveredAt;
        string location;
    }

    /// @notice Mapping from keccak256(trackingNumber) to tracking record
    mapping(bytes32 => TrackingRecord) public trackingRecords;

    event CarrierStatusUpdated(string indexed trackingNumber, CarrierStatus status, string location, uint256 timestamp);
    event OracleFulfillmentDispatched(address indexed escrowContract, uint256 escrowId, string trackingNumber);

    constructor(address initialOwner) Ownable(initialOwner) {}

    /**
     * @notice Simulates carrier logistics update received via Chainlink DON consensus
     */
    function updateCarrierStatus(
        string calldata trackingNumber,
        string calldata carrier,
        CarrierStatus status,
        string calldata location
    ) external {
        bytes32 key = keccak256(abi.encodePacked(trackingNumber));
        TrackingRecord storage record = trackingRecords[key];
        record.carrier = carrier;
        record.status = status;
        record.lastUpdated = block.timestamp;
        record.location = location;

        if (status == CarrierStatus.Delivered && record.deliveredAt == 0) {
            record.deliveredAt = block.timestamp;
        }

        emit CarrierStatusUpdated(trackingNumber, status, location, block.timestamp);
    }

    /**
     * @notice Reads verified delivery status for a tracking number
     */
    function getDeliveryStatus(string calldata trackingNumber) external view returns (
        CarrierStatus status,
        string memory carrier,
        uint256 lastUpdated,
        uint256 deliveredAt,
        string memory location
    ) {
        bytes32 key = keccak256(abi.encodePacked(trackingNumber));
        TrackingRecord memory record = trackingRecords[key];
        return (record.status, record.carrier, record.lastUpdated, record.deliveredAt, record.location);
    }

    /**
     * @notice Checks if the package is verified as delivered
     */
    function isDelivered(string calldata trackingNumber) external view returns (bool, uint256) {
        bytes32 key = keccak256(abi.encodePacked(trackingNumber));
        TrackingRecord memory record = trackingRecords[key];
        return (record.status == CarrierStatus.Delivered, record.deliveredAt);
    }

    /**
     * @notice Simulates the Chainlink DON triggering the Escrow contract's programmatic callback directly
     */
    function triggerEscrowCallback(
        address escrowContract,
        uint256 escrowId,
        string calldata trackingNumber
    ) external {
        bytes32 key = keccak256(abi.encodePacked(trackingNumber));
        TrackingRecord storage record = trackingRecords[key];
        record.status = CarrierStatus.Delivered;
        record.deliveredAt = block.timestamp;
        record.lastUpdated = block.timestamp;

        INodeKartEscrowOracleCallback(escrowContract).oracleDeliveryFulfillment(escrowId, trackingNumber);
        emit OracleFulfillmentDispatched(escrowContract, escrowId, trackingNumber);
    }
}
