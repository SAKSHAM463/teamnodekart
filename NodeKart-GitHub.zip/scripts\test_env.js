import hardhat from "hardhat";

async function main() {
  console.log("Hardhat version:", hardhat.version || "3.x");
  console.log("Available hardhat keys:", Object.keys(hardhat));
}

main().catch(console.error);
