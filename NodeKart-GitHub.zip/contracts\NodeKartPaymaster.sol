// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import "@openzeppelin/contracts/utils/cryptography/MessageHashUtils.sol";

/**
 * @title NodeKartPaymaster
 * @notice ERC-4337 compliant Verifying Paymaster that sponsors gas fees for retail buyers.
 * Eliminates the "60-Second Onboarding Trap" by enabling completely gasless checkout.
 */
contract NodeKartPaymaster is Ownable {
    using ECDSA for bytes32;
    using MessageHashUtils for bytes32;

    address public verifyingSigner;
    address public immutable targetEscrow;

    /// @notice Tracks sponsored transaction count
    uint256 public totalSponsoredOps;

    event GasSponsored(address indexed sender, address indexed target, uint256 validUntil);
    event SignerUpdated(address indexed oldSigner, address indexed newSigner);

    constructor(address _verifyingSigner, address _targetEscrow, address initialOwner) Ownable(initialOwner) {
        require(_verifyingSigner != address(0), "NodeKartPaymaster: zero signer address");
        verifyingSigner = _verifyingSigner;
        targetEscrow = _targetEscrow;
    }

    function setVerifyingSigner(address _newSigner) external onlyOwner {
        require(_newSigner != address(0), "NodeKartPaymaster: zero address");
        emit SignerUpdated(verifyingSigner, _newSigner);
        verifyingSigner = _newSigner;
    }

    /**
     * @notice Validates whether a UserOperation is cryptographically authorized for gas sponsorship
     */
    function validatePaymasterUserOp(
        address sender,
        address target,
        uint256 validUntil,
        uint256 validAfter,
        bytes calldata signature
    ) external view returns (bool) {
        require(block.timestamp >= validAfter, "NodeKartPaymaster: op not yet valid");
        require(block.timestamp <= validUntil, "NodeKartPaymaster: op expired");
        require(target == targetEscrow || targetEscrow == address(0), "NodeKartPaymaster: unauthorized target");

        bytes32 hash = keccak256(abi.encodePacked(sender, target, validUntil, validAfter, block.chainid));
        bytes32 ethHash = hash.toEthSignedMessageHash();
        address recovered = ethHash.recover(signature);

        return recovered == verifyingSigner;
    }

    /**
     * @notice Records sponsored gas execution
     */
    function recordSponsoredOp(address sender, address target, uint256 validUntil) external onlyOwner {
        totalSponsoredOps++;
        emit GasSponsored(sender, target, validUntil);
    }
}
