// ─────────────────────────────────────────────────────────────
//  src/lib/escrow.ts
//  Interactions with the NodeKartEscrow smart contract.
// ─────────────────────────────────────────────────────────────

import { BrowserProvider, Contract, parseEther, type Eip1193Provider } from 'ethers';
import { getProvider } from './wallet';
import { CONTRACTS } from '../contracts/deployed';
import { approveSharp, getSharpAllowance } from './token';
import type { EscrowState, OrderEscrowStruct, TxResult } from '../contracts/escrow.types';

export const ESCROW_CONTRACT_ADDRESS: string = CONTRACTS.NodeKartEscrow.address;

const STATE_NAMES: EscrowState[] = [
  'AwaitingSellerCollateral',
  'AwaitingBuyerDeposit',
  'Funded',
  'Dispatched',
  'Delivered',
  'Settled',
  'Disputed',
  'Cancelled',
];

async function getSignedEscrowContract(): Promise<{ contract: Contract; signerAddress: string }> {
  const provider = getProvider();
  const ethersProvider = new BrowserProvider(provider as unknown as Eip1193Provider);
  const signer = await ethersProvider.getSigner();
  const signerAddress = await signer.getAddress();
  const contract = new Contract(ESCROW_CONTRACT_ADDRESS, CONTRACTS.NodeKartEscrow.abi, signer);
  return { contract, signerAddress };
}

function getReadOnlyEscrowContract(): Contract {
  const provider = getProvider();
  const ethersProvider = new BrowserProvider(provider as unknown as Eip1193Provider);
  return new Contract(ESCROW_CONTRACT_ADDRESS, CONTRACTS.NodeKartEscrow.abi, ethersProvider);
}

/**
 * Creates and funds an escrow in a streamlined single transaction for the buyer
 */
export async function createAndFundEscrow(
  sellerAddress: string,
  itemPriceSharp: string,
  sellerCollateralSharp: string,
  buyerCollateralSharp: string,
  productRefId: string
): Promise<{ escrowId: number; txResult: TxResult }> {
  const { contract, signerAddress } = await getSignedEscrowContract();

  const priceWei = parseEther(itemPriceSharp);
  const sellerColWei = parseEther(sellerCollateralSharp);
  const buyerColWei = parseEther(buyerCollateralSharp);
  const totalBuyerRequired = priceWei + buyerColWei;

  // Check and grant SHARP token allowance if needed
  const currentAllowance = await getSharpAllowance(signerAddress, ESCROW_CONTRACT_ADDRESS);
  if (currentAllowance < totalBuyerRequired) {
    await approveSharp(ESCROW_CONTRACT_ADDRESS, '1000000000');
  }

  const tx = await contract['createAndFundEscrow'](
    sellerAddress,
    priceWei,
    sellerColWei,
    buyerColWei,
    productRefId
  );
  const receipt = await tx.wait(1);

  // Parse EscrowCreated event to extract escrow ID
  let escrowId = 1;
  if (receipt.logs) {
    for (const log of receipt.logs) {
      try {
        const parsed = contract.interface.parseLog(log);
        if (parsed && parsed.name === 'EscrowCreated') {
          escrowId = Number(parsed.args[0]);
          break;
        }
      } catch {}
    }
  }

  return {
    escrowId,
    txResult: {
      txHash: receipt.hash,
      blockNumber: receipt.blockNumber,
      from: signerAddress,
      to: ESCROW_CONTRACT_ADDRESS,
    },
  };
}

/**
 * Merchant marks package dispatched with carrier tracking
 */
export async function dispatchOrder(
  escrowId: number,
  trackingNumber: string,
  carrier: string
): Promise<TxResult> {
  const { contract } = await getSignedEscrowContract();
  const tx = await contract['dispatchOrder'](escrowId, trackingNumber, carrier);
  const receipt = await tx.wait(1);
  return {
    txHash: receipt.hash,
    blockNumber: receipt.blockNumber,
  };
}

/**
 * Synchronizes verified delivery status reported by Chainlink DON
 */
export async function syncDeliveryWithOracle(escrowId: number): Promise<TxResult> {
  const { contract } = await getSignedEscrowContract();
  const tx = await contract['syncDeliveryWithOracle'](escrowId);
  const receipt = await tx.wait(1);
  return {
    txHash: receipt.hash,
    blockNumber: receipt.blockNumber,
  };
}

/**
 * Buyer manually confirms delivery; instantly releases merchant payout,
 * refunds deposits, mints 5% SHARP cashback, and upgrades SBT reputation.
 */
export async function confirmDeliveryAndSettle(escrowId: number): Promise<TxResult> {
  const { contract } = await getSignedEscrowContract();
  const tx = await contract['confirmDeliveryAndSettle'](escrowId);
  const receipt = await tx.wait(1);
  return {
    txHash: receipt.hash,
    blockNumber: receipt.blockNumber,
  };
}

/**
 * Claims automated release after the 48-hour delivery timelock has passed
 */
export async function claimAutomatedSettlement(escrowId: number): Promise<TxResult> {
  const { contract } = await getSignedEscrowContract();
  const tx = await contract['claimAutomatedSettlement'](escrowId);
  const receipt = await tx.wait(1);
  return {
    txHash: receipt.hash,
    blockNumber: receipt.blockNumber,
  };
}

/**
 * Buyer raises a dispute within the 48-hour window
 */
export async function raiseDispute(escrowId: number, reason: string): Promise<TxResult> {
  const { contract } = await getSignedEscrowContract();
  const tx = await contract['raiseDispute'](escrowId, reason);
  const receipt = await tx.wait(1);
  return {
    txHash: receipt.hash,
    blockNumber: receipt.blockNumber,
  };
}

/**
 * Fetches on-chain escrow details
 */
export async function getEscrowDetails(escrowId: number): Promise<OrderEscrowStruct | null> {
  try {
    const contract = getReadOnlyEscrowContract();
    const data = await contract['getEscrow'](escrowId);
    return data as OrderEscrowStruct;
  } catch (err) {
    console.warn(`Could not fetch on-chain escrow #${escrowId}:`, err);
    return null;
  }
}

/**
 * Converts state index (0-7) to human-readable EscrowState
 */
export function formatEscrowState(stateIndex: number): EscrowState {
  return STATE_NAMES[stateIndex] ?? 'AwaitingBuyerDeposit';
}

/**
 * Returns block explorer URL for a given transaction hash
 */
export function getExplorerUrl(txHash: string): string {
  const chainId = Number(import.meta.env.VITE_CHAIN_ID ?? 31337);
  const explorers: Record<number, string> = {
    1: 'https://etherscan.io/tx/',
    11155111: 'https://sepolia.etherscan.io/tx/',
    84532: 'https://sepolia.basescan.org/tx/',
    421614: 'https://sepolia.arbiscan.io/tx/',
    31337: 'http://127.0.0.1:8545/tx/',
  };
  const base = explorers[chainId] ?? 'https://sepolia.basescan.org/tx/';
  return `${base}${txHash}`;
}
