import hardhat from "hardhat";
import { ethers } from "ethers";

async function runTestSuite() {
  console.log("══════════════════════════════════════════════════════════");
  console.log("🧪 Running NodeKart Comprehensive Test Suite");
  console.log("══════════════════════════════════════════════════════════\n");

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  ✅ [PASS] ${message}`);
      passed++;
    } else {
      console.error(`  ❌ [FAIL] ${message}`);
      failed++;
    }
  }

  const connection = await hardhat.network.connect();
  const provider = new ethers.BrowserProvider(connection.provider);

  const [deployer, seller, buyer, thirdParty] = [
    await provider.getSigner(0),
    await provider.getSigner(1),
    await provider.getSigner(2),
    await provider.getSigner(3),
  ];

  const deployerAddr = await deployer.getAddress();
  const sellerAddr = await seller.getAddress();
  const buyerAddr = await buyer.getAddress();
  const thirdPartyAddr = await thirdParty.getAddress();

  // Load contract artifacts
  const sharpArtifact = await hardhat.artifacts.readArtifact("SHARPToken");
  const sbtArtifact = await hardhat.artifacts.readArtifact("NodeKartReputationSBT");
  const oracleArtifact = await hardhat.artifacts.readArtifact("MockChainlinkOracle");
  const escrowArtifact = await hardhat.artifacts.readArtifact("NodeKartEscrow");
  const paymasterArtifact = await hardhat.artifacts.readArtifact("NodeKartPaymaster");

  console.log("--- 1. SHARP Token (ERC-20 & Programmatic Cashback) ---");
  const sharp = await (new ethers.ContractFactory(sharpArtifact.abi, sharpArtifact.bytecode, deployer)).deploy(deployerAddr);
  await sharp.waitForDeployment();
  const sharpAddr = await sharp.getAddress();

  assert((await sharp.name()) === "SHARP Token", "Token name is 'SHARP Token'");
  assert((await sharp.symbol()) === "SHARP", "Token symbol is 'SHARP'");
  assert((await sharp.balanceOf(deployerAddr)) === ethers.parseEther("10000000"), "Deployer has initial 10,000,000 SHARP supply");

  // Test faucet
  await (await sharp.connect(buyer).mintFaucet(buyerAddr, ethers.parseEther("1000"))).wait();
  assert((await sharp.balanceOf(buyerAddr)) === ethers.parseEther("1000"), "Buyer received 1,000 SHARP from testnet faucet");

  // Non-minter cannot mint cashback
  let unauthorizedCashback = false;
  try {
    await (await sharp.connect(thirdParty).mintCashback(thirdPartyAddr, ethers.parseEther("500"))).wait();
  } catch (e) {
    unauthorizedCashback = true;
  }
  assert(unauthorizedCashback, "Unauthorized caller cannot call mintCashback");

  console.log("\n--- 2. NodeKartReputationSBT (ERC-5192 Soulbound Tokens) ---");
  const sbt = await (new ethers.ContractFactory(sbtArtifact.abi, sbtArtifact.bytecode, deployer)).deploy(deployerAddr);
  await sbt.waitForDeployment();
  const sbtAddr = await sbt.getAddress();

  // Mint reputation to seller
  await (await sbt.setAuthorizedUpdater(deployerAddr, true)).wait();
  await (await sbt.recordSettlement(sellerAddr, ethers.parseEther("25000"), 50)).wait();

  const sellerTokenId = await sbt.userToTokenId(sellerAddr);
  assert(sellerTokenId > 0n, "Soulbound Token minted to seller upon settlement");
  assert(await sbt.locked(sellerTokenId), "ERC-5192 locked() returns true for Soulbound token");

  // Soulbound non-transferability check
  let transferBlocked = false;
  try {
    await (await sbt.connect(seller).transferFrom(sellerAddr, thirdPartyAddr, sellerTokenId)).wait();
  } catch (e) {
    transferBlocked = true;
  }
  assert(transferBlocked, "Peer-to-peer transfer is strictly blocked (Soulbound enforcement)");

  const rep = await sbt.getReputationByUser(sellerAddr);
  assert(rep.completedTrades === 1n, "Reputation tracks 1 completed trade");
  assert(rep.totalVolume === ethers.parseEther("25000"), "Reputation tracks 25,000 SHARP volume");

  console.log("\n--- 3. MockChainlinkOracle (Logistics Delivery Verification) ---");
  const oracle = await (new ethers.ContractFactory(oracleArtifact.abi, oracleArtifact.bytecode, deployer)).deploy(deployerAddr);
  await oracle.waitForDeployment();
  const oracleAddr = await oracle.getAddress();

  await (await oracle.updateCarrierStatus("NK9271IN", "BlueDart Logistics", 1, "Hub")).wait();
  let statusResult = await oracle.isDelivered("NK9271IN");
  assert(!statusResult[0], "In-transit package is not delivered yet");

  await (await oracle.updateCarrierStatus("NK9271IN", "BlueDart Logistics", 3, "Destination Doorstep")).wait();
  statusResult = await oracle.isDelivered("NK9271IN");
  assert(statusResult[0], "Chainlink DON reports verified delivery status");

  console.log("\n--- 4. NodeKartEscrow (Dual-Deposit Nash Equilibrium Happy Path) ---");
  const escrow = await (new ethers.ContractFactory(escrowArtifact.abi, escrowArtifact.bytecode, deployer)).deploy(
    sharpAddr,
    sbtAddr,
    oracleAddr,
    deployerAddr
  );
  await escrow.waitForDeployment();
  const escrowAddr = await escrow.getAddress();

  await (await sharp.setMinter(escrowAddr, true)).wait();
  await (await sbt.setAuthorizedUpdater(escrowAddr, true)).wait();

  // Fund accounts
  await (await sharp.transfer(sellerAddr, ethers.parseEther("50000"))).wait();
  await (await sharp.transfer(buyerAddr, ethers.parseEther("50000"))).wait();
  await (await sharp.connect(seller).approve(escrowAddr, ethers.MaxUint256)).wait();
  await (await sharp.connect(buyer).approve(escrowAddr, ethers.MaxUint256)).wait();

  const itemPrice = ethers.parseEther("10000");
  const sellerDeposit = ethers.parseEther("1000"); // 10%
  const buyerDeposit = ethers.parseEther("500");   // 5%

  // Create Escrow
  await (await escrow.connect(buyer).createEscrow(sellerAddr, itemPrice, sellerDeposit, buyerDeposit, "camera")).wait();
  let orderData = await escrow.getEscrow(1);
  assert(orderData.state === 0n, "Order #1 state is AwaitingSellerCollateral");

  // Seller locks collateral
  await (await escrow.connect(seller).depositSellerCollateral(1)).wait();
  orderData = await escrow.getEscrow(1);
  assert(orderData.state === 1n, "Order #1 state is AwaitingBuyerDeposit");

  // Buyer locks funds (price + buyer collateral)
  const buyerBalBefore = await sharp.balanceOf(buyerAddr);
  await (await escrow.connect(buyer).depositBuyerFunds(1)).wait();
  orderData = await escrow.getEscrow(1);
  assert(orderData.state === 2n, "Order #1 state is Funded");

  // Seller dispatches
  await (await escrow.connect(seller).dispatchOrder(1, "CAM-8899-TRK", "FedEx")).wait();
  orderData = await escrow.getEscrow(1);
  assert(orderData.state === 3n, "Order #1 state is Dispatched");

  // Buyer confirms delivery (Instant Happy Path)
  const sellerBalBefore = await sharp.balanceOf(sellerAddr);
  await (await escrow.connect(buyer).confirmDeliveryAndSettle(1)).wait();
  orderData = await escrow.getEscrow(1);
  assert(orderData.state === 5n, "Order #1 state is Settled");

  const sellerBalAfter = await sharp.balanceOf(sellerAddr);
  const buyerBalAfter = await sharp.balanceOf(buyerAddr);

  // Seller should receive item price + deposit refunded = 11,000 SHARP
  assert(sellerBalAfter - sellerBalBefore === ethers.parseEther("11000"), "Seller received itemPrice (10,000) + refunded collateral (1,000)");

  // Buyer should receive deposit refund (500) + 5% cashback (500) = net -9,500 from before purchase
  const expectedCashback = ethers.parseEther("500"); // 5% of 10,000
  assert(buyerBalAfter - (buyerBalBefore - itemPrice - buyerDeposit) === (buyerDeposit + expectedCashback), "Buyer received collateral refund + 500 SHARP (5% cashback)");

  console.log("\n--- 5. NodeKartEscrow (Oracle Automated Delivery & 48h Timelock) ---");
  await (await escrow.connect(buyer).createEscrow(sellerAddr, itemPrice, sellerDeposit, buyerDeposit, "headphones")).wait();
  await (await escrow.connect(seller).depositSellerCollateral(2)).wait();
  await (await escrow.connect(buyer).depositBuyerFunds(2)).wait();
  await (await escrow.connect(seller).dispatchOrder(2, "HD-4422-TRK", "DHL Express")).wait();

  // Oracle triggers callback
  await (await oracle.triggerEscrowCallback(escrowAddr, 2, "HD-4422-TRK")).wait();
  orderData = await escrow.getEscrow(2);
  assert(orderData.state === 4n, "Order #2 state moved to Delivered via Chainlink DON callback");

  // Fast forward time by 48 hours + 1 second
  await connection.provider.send("evm_increaseTime", [48 * 3600 + 1]);
  await connection.provider.send("evm_mine", []);

  // Anyone can trigger automated settlement
  await (await escrow.connect(thirdParty).claimAutomatedSettlement(2)).wait();
  orderData = await escrow.getEscrow(2);
  assert(orderData.state === 5n, "Order #2 settled automatically after 48h timelock");

  console.log("\n--- 6. NodeKartEscrow (Nash Equilibrium Dispute Slashing) ---");
  // Test case: Seller at fault (fraudulent delivery) -> Seller collateral slashed to buyer
  await (await escrow.connect(buyer).createEscrow(sellerAddr, itemPrice, sellerDeposit, buyerDeposit, "watch")).wait();
  await (await escrow.connect(seller).depositSellerCollateral(3)).wait();
  await (await escrow.connect(buyer).depositBuyerFunds(3)).wait();
  await (await escrow.connect(seller).dispatchOrder(3, "FAKE-TRK-99", "Unknown")).wait();

  // Buyer raises dispute
  await (await escrow.connect(buyer).raiseDispute(3, "Item not received / fake tracking number")).wait();
  orderData = await escrow.getEscrow(3);
  assert(orderData.state === 6n, "Order #3 state is Disputed");

  const buyerBalPreSlash = await sharp.balanceOf(buyerAddr);
  // Resolve dispute: Seller at fault
  await (await escrow.connect(deployer).resolveDisputeNash(3, true, false)).wait();

  const buyerBalPostSlash = await sharp.balanceOf(buyerAddr);
  // Buyer gets itemPrice (10,000) + buyerDeposit (500) + sellerCollateral (1,000) = 11,500 SHARP
  assert(buyerBalPostSlash - buyerBalPreSlash === ethers.parseEther("11500"), "Seller collateral slashed: Buyer received full refund + seller deposit as compensation");

  console.log("\n--- 7. NodeKartPaymaster (ERC-4337 Gasless Verification) ---");
  const paymaster = await (new ethers.ContractFactory(paymasterArtifact.abi, paymasterArtifact.bytecode, deployer)).deploy(
    deployerAddr,
    escrowAddr,
    deployerAddr
  );
  await paymaster.waitForDeployment();

  const currentBlock = await provider.getBlock("latest");
  const currentTimestamp = currentBlock.timestamp;
  const validUntil = currentTimestamp + 3600;
  const validAfter = currentTimestamp - 60;
  const chainId = 31337;

  // Construct UserOp digest and sign
  const hash = ethers.solidityPackedKeccak256(
    ["address", "address", "uint256", "uint256", "uint256"],
    [buyerAddr, escrowAddr, validUntil, validAfter, chainId]
  );
  const signature = await deployer.signMessage(ethers.getBytes(hash));

  const isValid = await paymaster.validatePaymasterUserOp(buyerAddr, escrowAddr, validUntil, validAfter, signature);
  assert(isValid, "ERC-4337 Paymaster cryptographically validated gasless UserOperation");

  console.log("\n══════════════════════════════════════════════════════════");
  console.log(`📊 Test Results: ${passed} PASSED, ${failed} FAILED`);
  console.log("══════════════════════════════════════════════════════════\n");

  if (failed > 0) {
    throw new Error(`${failed} tests failed!`);
  }
}

runTestSuite().catch((err) => {
  console.error("Test Suite Error:", err);
  process.exit(1);
});
