﻿import React from 'react';
import { Sparkles, Users, TrendingUp, ArrowUpRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { REWARD_LOGS } from '../mockData';

export const RewardsPage: React.FC = () => {
  const { navigate } = useApp();

  return (
    <div className="max-w-[1200px] mx-auto px-[5%] py-10 sm:py-14 animate-rise">
      {/* Page Heading */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-6 mb-10 pb-6 border-b border-line">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-widest text-lime mb-2">
            NodeKart rewards
          </p>
          <h1 className="font-display font-semibold text-3xl sm:text-5xl text-ink">
            Your rewards<br />
            <em className="font-serif font-normal text-lime">that keep coming back.</em>
          </h1>
          <p className="text-muted text-xs sm:text-sm mt-2 max-w-[480px]">
            A transparent value mechanism for every completed exchange on NodeKart.
          </p>
        </div>

        <div className="border-l-2 border-line pl-6">
          <span className="font-mono text-[9px] uppercase tracking-widest text-muted block">
            Lifetime earned
          </span>
          <strong className="font-display font-bold text-2xl sm:text-3xl text-ink block my-1">
            2,450 SHARP
          </strong>
        </div>
      </div>

      {/* Metric Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10">
        <div className="border border-line rounded-lg p-5 bg-panel">
          <span className="text-muted text-xs flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-lime" />
            Cashback earned
          </span>
          <strong className="font-display font-bold text-2xl text-ink block my-3">
            1,950 SHARP
          </strong>
          <small className="text-muted text-[11px] block">
            Across 6 completed orders
          </small>
        </div>

        <div className="border border-line rounded-lg p-5 bg-panel">
          <span className="text-muted text-xs flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-lime" />
            Referral rewards
          </span>
          <strong className="font-display font-bold text-2xl text-ink block my-3">
            500 SHARP
          </strong>
          <small className="text-muted text-[11px] block">
            From 5 successful purchases
          </small>
        </div>

        <div className="border border-line rounded-lg p-5 bg-panel">
          <span className="text-muted text-xs flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-lime" />
            Growth rate
          </span>
          <strong className="font-display font-bold text-2xl text-lime block my-3">
            +18.4%
          </strong>
          <small className="text-muted text-[11px] block">
            Compared to last month
          </small>
        </div>
      </div>

      {/* Split Section */}
      <div className="grid grid-cols-1 lg:grid-cols-[1.2fr_0.8fr] gap-6">
        {/* Recent Cashback */}
        <div className="border border-line rounded-lg p-6 bg-panel">
          <h2 className="font-display font-semibold text-xl text-ink mb-4">
            Recent cashback events
          </h2>
          <div className="divide-y divide-line">
            {REWARD_LOGS.map(log => (
              <div key={log.id} className="py-3.5 flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-[#28372b] grid place-items-center text-lime flex-shrink-0">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <b className="text-xs font-semibold text-ink block truncate">
                    {log.title}
                  </b>
                  <small className="text-[10px] text-muted block mt-0.5">
                    Settled on-chain · {log.date}
                  </small>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Reward Mechanism Info */}
        <div className="bg-[#21372a] border border-[#3d5940] rounded-lg p-7 flex flex-col justify-between">
          <div>
            <span className="font-mono text-[9px] uppercase tracking-widest text-lime block">
              Reward mechanism
            </span>
            <h2 className="font-display font-semibold text-2xl sm:text-3xl text-ink mt-3 mb-2">
              Rewards that follow the exchange.
            </h2>
            <p className="text-[#b6c7b5] text-xs sm:text-sm leading-relaxed mt-3">
              Cashback in SHARP is generated through NodeKart's automated settlement protocol upon successful order confirmation, rather than superficial discounts.
            </p>
          </div>

          <button
            onClick={() => navigate('market')}
            className="border border-[#506e50] hover:border-lime text-ink text-xs font-bold py-3 px-4 rounded inline-flex items-center justify-center gap-2 transition-colors mt-8 bg-[#182a20]"
          >
            <span>Keep shopping</span>
            <ArrowUpRight className="w-4 h-4 text-lime" />
          </button>
        </div>
      </div>
    </div>
  );
};
