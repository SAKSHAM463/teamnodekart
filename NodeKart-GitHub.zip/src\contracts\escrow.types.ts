// ─────────────────────────────────────────────────────────────
//  src/contracts/escrow.types.ts
//  Shared TypeScript types for NodeKart Web3 contract interactions.
// ─────────────────────────────────────────────────────────────

/** Mirrors Solidity enum EscrowState in NodeKartEscrow.sol */
export type EscrowState =
  | 'AwaitingSellerCollateral' // 0
  | 'AwaitingBuyerDeposit'     // 1
  | 'Funded'                   // 2
  | 'Dispatched'               // 3
  | 'Delivered'                // 4
  | 'Settled'                  // 5
  | 'Disputed'                 // 6
  | 'Cancelled';               // 7

export interface OrderEscrowStruct {
  id: bigint;
  seller: string;
  buyer: string;
  itemPrice: bigint;
  sellerCollateral: bigint;
  buyerCollateral: bigint;
  trackingNumber: string;
  carrier: string;
  deliveryTimestamp: bigint;
  disputeDeadline: bigint;
  state: number; // 0-7
  productRefId: string;
}

export interface ReputationData {
  tokenId: number;
  completedTrades: number;
  totalVolume: string; // Formatted SHARP
  disputeFreeStreak: number;
  averageRating: number; // e.g. 4.9
  slashedCount: number;
}

export interface CarrierTrackingInfo {
  status: 'NotFound' | 'InTransit' | 'OutForDelivery' | 'Delivered' | 'Exception';
  carrier: string;
  lastUpdated: string;
  deliveredAt: string | null;
  location: string;
}

/** Return shape of a confirmed on-chain transaction */
export interface TxResult {
  txHash: string;
  blockNumber: number;
  from?: string;
  to?: string;
}
