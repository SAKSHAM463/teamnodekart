export const DemoPill = () => null;
