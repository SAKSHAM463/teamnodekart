import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Toast } from './components/Toast';
import { ProofModal } from './components/ProofModal';
import { PaymentModal } from './components/PaymentModal';

import { HomePage } from './pages/HomePage';
import { MarketplacePage } from './pages/MarketplacePage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrdersPage } from './pages/OrdersPage';
import { WalletPage } from './pages/WalletPage';
import { SellerDashboardPage } from './pages/SellerDashboardPage';
import { RewardsPage } from './pages/RewardsPage';
import { ReferralsPage } from './pages/ReferralsPage';
import { ProfilePage } from './pages/ProfilePage';
import { SellProductPage } from './pages/SellProductPage';

const AppContent: React.FC = () => {
  const { page } = useApp();

  const renderCurrentPage = () => {
    switch (page) {
      case 'home':
        return <HomePage />;
      case 'market':
        return <MarketplacePage />;
      case 'product':
        return <ProductDetailPage />;
      case 'cart':
        return <CartPage />;
      case 'checkout':
        return <CheckoutPage />;
      case 'orders':
        return <OrdersPage />;
      case 'wallet':
        return <WalletPage />;
      case 'seller':
        return <SellerDashboardPage />;
      case 'rewards':
        return <RewardsPage />;
      case 'referrals':
        return <ReferralsPage />;
      case 'profile':
        return <ProfilePage />;
      case 'list':
        return <SellProductPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-bg text-ink flex flex-col font-sans selection:bg-lime selection:text-[#102016]">
      <Header />
      <main className="flex-1">
        {renderCurrentPage()}
      </main>
      <Footer />
      <Toast />
      <ProofModal />
      <PaymentModal />
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;
